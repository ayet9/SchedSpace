<?php

use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\AuditLogController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BuildingController;
use App\Http\Controllers\Api\CampusMapController;
use App\Http\Controllers\Api\ClassroomController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\DepartmentController;
use App\Http\Controllers\Api\ExportController;
use App\Http\Controllers\Api\PasswordController;
use App\Http\Controllers\Api\RolePermissionController;
use App\Http\Controllers\Api\ScheduleController;
use App\Http\Controllers\Api\StudentController;
use App\Http\Controllers\Api\StudentSubjectController;
use App\Http\Controllers\Api\SubjectController;
use App\Http\Controllers\Api\TeacherController;
use App\Http\Controllers\Api\UserManagementController;
use App\Http\Controllers\Api\UserProfileController;
use App\Http\Middleware\NoStore;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// PUBLIC AUTHENTICATION
Route::post('/login', [AuthController::class, 'login']);

// AUTHENTICATED ROUTES
Route::middleware(['auth:sanctum', NoStore::class])->group(function () {

    // AUTHENTICATION
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/password/change', [PasswordController::class, 'change']);

    // SELF-SERVICE PROFILE - available to every authenticated account.
    Route::get('/profile', [UserProfileController::class, 'show']);
    Route::put('/profile', [UserProfileController::class, 'update']);
    Route::patch('/profile', [UserProfileController::class, 'update']);
    Route::delete('/profile', [UserProfileController::class, 'destroy']);

    Route::get('/user', function (Request $request) {
        // Re-query the authenticated account so role changes made by an admin
        // are reflected immediately instead of relying on a possibly stale
        // in-memory relationship instance.
        $user = $request->user()->fresh();
        $user->load(['role.permissions', 'permissions', 'teacher']);

        return response()->json($user);
    });

    // DASHBOARD
    // One compact request keeps the login -> dashboard transition responsive.
    Route::get('/dashboard', [DashboardController::class, 'index'])
        ->middleware('permission:view_dashboard');

    // SUPER ADMIN ACCOUNT AND ACCESS MANAGEMENT
    Route::get('/users', [UserManagementController::class, 'index'])->middleware('permission:manage_users');
    Route::put('/users/{user}', [UserManagementController::class, 'update'])->middleware('permission:manage_users');
    Route::patch('/users/{user}', [UserManagementController::class, 'update'])->middleware('permission:manage_users');
    Route::delete('/users/{user}', [UserManagementController::class, 'destroy'])->middleware('permission:manage_users');
    Route::post('/users/{user}/role', [UserManagementController::class, 'updateRole'])->middleware('permission:manage_users');
    Route::put('/users/{user}/role', [UserManagementController::class, 'updateRole'])->middleware('permission:manage_users');

    Route::get('/roles', [RolePermissionController::class, 'index'])->middleware('permission:manage_roles_permissions');
    Route::get('/permissions', [RolePermissionController::class, 'permissions'])->middleware('permission:manage_roles_permissions');
    Route::get('/permissions/matrix', [RolePermissionController::class, 'matrix'])->middleware('permission:manage_roles_permissions');
    Route::put('/permissions/matrix', [RolePermissionController::class, 'updateMatrix'])->middleware('permission:manage_roles_permissions');
    Route::put('/roles/{role}/permissions', [RolePermissionController::class, 'updateRolePermissions'])->middleware('permission:manage_roles_permissions');
    Route::put('/users/{user}/permissions', [RolePermissionController::class, 'updateUserPermissions'])->middleware('permission:manage_roles_permissions');

    // DEPARTMENTS AND AUDIT LOGS
    Route::get('/departments', [DepartmentController::class, 'index'])->middleware('permission:view_departments');
    Route::post('/departments', [DepartmentController::class, 'store'])->middleware('permission:manage_departments');
    Route::put('/departments/{department}', [DepartmentController::class, 'update'])->middleware('permission:manage_departments');
    Route::delete('/departments/{department}', [DepartmentController::class, 'destroy'])->middleware('permission:manage_departments');
    Route::get('/audit-logs', [AuditLogController::class, 'index'])->middleware('permission:view_audit_logs');

    // BUILDINGS AND FLOORS
    Route::get('/buildings', [BuildingController::class, 'index'])->middleware('permission:view_classrooms');
    Route::get('/campus-map', [CampusMapController::class, 'show'])->middleware('permission:view_classrooms');
    Route::put('/campus-map', [CampusMapController::class, 'update'])->middleware('permission:manage_classrooms');
    Route::post('/buildings', [BuildingController::class, 'store'])->middleware('permission:manage_classrooms');
    Route::put('/buildings/{building}/position', [BuildingController::class, 'updatePosition'])->middleware('permission:manage_classrooms');
    Route::put('/buildings/{building}', [BuildingController::class, 'update'])->middleware('permission:manage_classrooms');
    Route::delete('/buildings/{building}', [BuildingController::class, 'destroy'])->middleware('permission:manage_classrooms');
    Route::put('/buildings/{building}/floors/{floor}/walkways', [BuildingController::class, 'updateWalkways'])
        ->whereNumber('floor')->middleware('permission:manage_classrooms');

    // CLASSROOMS
    Route::get('/classroom-layout-types', [ClassroomController::class, 'layoutTypes'])
        ->middleware('permission:view_classrooms');

    Route::get('/classrooms', [ClassroomController::class, 'index'])
        ->middleware('permission:view_classrooms');

    Route::get('/classrooms/{classroom}', [ClassroomController::class, 'show'])
        ->middleware('permission:view_classrooms');

    Route::post('/classrooms', [ClassroomController::class, 'store'])
        ->middleware('permission:manage_classrooms');

    Route::put('/classrooms/positions', [ClassroomController::class, 'reposition'])
        ->middleware('permission:manage_classrooms');

    Route::put('/classrooms/{classroom}', [ClassroomController::class, 'update'])
        ->middleware('permission:manage_classrooms');

    Route::put('/classrooms/{classroom}/plan', [ClassroomController::class, 'updatePlan'])
        ->middleware('permission:manage_classrooms');

    Route::post('/classrooms/{classroom}/deactivate', [ClassroomController::class, 'deactivate'])
        ->middleware('permission:manage_classrooms');

    Route::post('/classrooms/{classroom}/reactivate', [ClassroomController::class, 'reactivate'])
        ->middleware('permission:manage_classrooms');

    Route::delete('/classrooms/{classroom}', [ClassroomController::class, 'destroy'])
        ->middleware('permission:manage_classrooms');

    // TEACHERS
    Route::get('/teachers', [TeacherController::class, 'index'])
        ->middleware('permission:view_teachers');

    Route::get('/teachers/{teacher}', [TeacherController::class, 'show'])
        ->middleware('permission:view_teachers');

    Route::post('/teachers', [TeacherController::class, 'store'])
        ->middleware('permission:manage_teachers');

    Route::put('/teachers/{teacher}', [TeacherController::class, 'update'])
        ->middleware('permission:manage_teachers');

    Route::post('/teachers/{teacher}/reset-password', [TeacherController::class, 'resetPassword'])
        ->middleware('permission:manage_teachers');

    Route::post('/teachers/{teacher}/deactivate', [TeacherController::class, 'deactivate'])
        ->middleware('permission:manage_teachers');

    Route::post('/teachers/{teacher}/reactivate', [TeacherController::class, 'reactivate'])
        ->middleware('permission:manage_teachers');

    Route::delete('/teachers/{teacher}', [TeacherController::class, 'destroy'])
        ->middleware('permission:manage_teachers');

    // STUDENTS
    Route::apiResource('students', StudentController::class)
        ->middleware('permission:manage_students');

    // SUBJECTS
    Route::get('/subjects', [SubjectController::class, 'index'])
        ->middleware('permission:view_subjects');

    Route::get('/subjects/{subject}', [SubjectController::class, 'show'])
        ->middleware('permission:view_subjects');

    Route::post('/subjects', [SubjectController::class, 'store'])
        ->middleware('permission:manage_subjects');

    Route::put('/subjects/{subject}', [SubjectController::class, 'update'])
        ->middleware('permission:manage_subjects');

    Route::patch('/subjects/{subject}', [SubjectController::class, 'update'])
        ->middleware('permission:manage_subjects');

    Route::delete('/subjects/{subject}', [SubjectController::class, 'destroy'])
        ->middleware('permission:manage_subjects');

    // STUDENT-SUBJECT ASSIGNMENTS
    Route::get('/student-subjects/my-students', [
        StudentSubjectController::class,
        'myStudents',
    ])->middleware('permission:view_assigned_student_lists');

    Route::get('/student-subjects', [
        StudentSubjectController::class,
        'index',
    ])->middleware('permission:manage_students');

    Route::post('/student-subjects/import-excel', [
        StudentSubjectController::class,
        'importExcel',
    ])->middleware('permission:manage_students');

    Route::post('/student-subjects/import-csv', [
        StudentSubjectController::class,
        'importCsv',
    ])->middleware('permission:manage_students');

    Route::post('/student-subjects', [
        StudentSubjectController::class,
        'store',
    ])->middleware('permission:manage_students');

    Route::get('/student-subjects/student/{student}', [
        StudentSubjectController::class,
        'show',
    ])->middleware('permission:manage_students');

    Route::delete('/student-subjects/{studentSubject}', [
        StudentSubjectController::class,
        'destroy',
    ])->middleware('permission:manage_students');

    // SCHEDULES
    Route::get('/schedules/my-schedule', [
        ScheduleController::class,
        'mySchedule',
    ])->middleware('permission:view_own_schedule');

    Route::get('/schedules', [ScheduleController::class, 'index'])
        ->middleware('permission:view_schedules');

    Route::get('/schedules/other-teachers', [ScheduleController::class, 'index'])
        ->middleware('permission:view_other_teacher_schedules');

    Route::get('/schedules/dates', [ScheduleController::class, 'dates'])
        ->middleware('permission:view_schedules');

    Route::get('/schedules/{schedule}', [ScheduleController::class, 'show'])
        ->middleware('permission:view_schedules');

    Route::post('/schedules', [ScheduleController::class, 'store'])
        ->middleware('permission:manage_schedules');

    Route::put('/schedules/{schedule}', [ScheduleController::class, 'update'])
        ->middleware('permission:manage_schedules');

    Route::delete('/schedules/{schedule}', [ScheduleController::class, 'destroy'])
        ->middleware('permission:manage_schedules');

    // TEACHER ATTENDANCE
    Route::get('/attendance/my-attendance', [
        AttendanceController::class,
        'myAttendance',
    ])->middleware('permission:record_attendance');

    Route::get('/attendance/my-status', [
        AttendanceController::class,
        'myStatus',
    ])->middleware('permission:record_attendance');

    Route::post('/attendance/time-in', [
        AttendanceController::class,
        'timeIn',
    ])->middleware('permission:record_attendance');

    Route::post('/attendance/time-out', [
        AttendanceController::class,
        'timeOut',
    ])->middleware('permission:record_attendance');

    Route::post('/attendance/capture-token/{action}', [AttendanceController::class, 'captureToken'])
        ->middleware('permission:record_attendance');

    Route::get('/attendance/dates', [AttendanceController::class, 'dates'])
        ->middleware('permission:view_attendance');

    Route::patch('/attendance/{attendance}/correct', [AttendanceController::class, 'correct'])
        ->middleware('permission:view_attendance');

    Route::patch('/attendance/{attendance}/verification', [AttendanceController::class, 'verify'])
        ->middleware('permission:view_attendance');

    Route::get('/attendance/{attendance}/photo/{side}', [AttendanceController::class, 'photo'])
        ->name('attendance.photo');

    // ADMIN AND ROOT ADMIN: VIEW ATTENDANCE RECORDS
    Route::get('/attendance', [
        AttendanceController::class,
        'index',
    ])->middleware('permission:view_attendance');

    // Excel exports/imports
    Route::get('/exports/attendance.xlsx', [ExportController::class, 'attendance'])
        ->middleware('permission:export_reports');
    Route::get('/exports/attendance.csv', [ExportController::class, 'attendanceCsv'])
        ->middleware('permission:export_reports');
    Route::get('/exports/schedules.xlsx', [ExportController::class, 'schedules'])
        ->middleware('permission:export_reports');
    Route::get('/exports/schedules.csv', [ExportController::class, 'schedulesCsv'])
        ->middleware('permission:export_reports');
    Route::get('/exports/teacher-schedules.xlsx', [ExportController::class, 'teacherSchedules'])
        ->middleware('permission:export_reports');
    Route::get('/exports/teacher-schedules.csv', [ExportController::class, 'teacherSchedulesCsv'])
        ->middleware('permission:export_reports');
    Route::get('/exports/teachers.xlsx', [ExportController::class, 'teachers'])->middleware('permission:export_reports');
    Route::get('/exports/students.xlsx', [ExportController::class, 'students'])->middleware('permission:export_reports');
    Route::get('/exports/subjects.xlsx', [ExportController::class, 'subjects'])->middleware('permission:export_reports');
    Route::get('/exports/template/{module}.xlsx', [ExportController::class, 'template'])->middleware('permission:export_reports');

});
