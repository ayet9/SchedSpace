<?php

// No attendance auto-timeout scheduler. Attendance closes only by teacher Time Out
// or an explicit administrator correction.
