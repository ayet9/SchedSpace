# SchedSpace Database Schema

## Core
- `users` -> `roles`: one role per user. `is_active` and `must_change_password` control account lifecycle.
- `roles` <-> `permissions`: role permissions are fixed by the application seeder; privileged role transfer is not a UI workflow.
- `teachers` -> `users`: one teacher profile per teacher account.

## Academic
- `students` <-> `subjects` through `student_subjects`.
- `teachers` <-> `subjects` through `teacher_subjects`.
- `schedules` -> teacher, subject and classroom, with a concrete `schedule_date` for new records.
- `classrooms` -> `classroom_layout_types`.

## Attendance
- `attendances` -> teacher, one row per teacher/date.
- `time_in_at` and `time_out_at` are UTC timestamps; legacy display time fields are retained for compatibility.
- Attendance photos are stored on private storage and exposed only through an authorization-checked route.
- `attendance_capture_tokens` are short-lived, single-use camera action tokens.
- `attendance_idempotency_keys` make Time In/Out safe against retries and double clicks.

## Delete behavior
- Join tables cascade from their parent records.
- Classroom, subject and teacher records with history are deactivated/archived instead of being hard deleted.
- Schedule history is preserved and past schedules are read-only.

## 2026-11-17 additions
- `departments` stores the active department catalog; `teachers.department_id` references it and legacy `teachers.department` is synchronized for compatibility.
- `audit_logs` stores the actor, action, entity and JSON metadata for administrative changes and attendance corrections.
- Teacher hard deletion is permitted only when there are no schedules or attendance records. Department deletion is blocked while teachers are assigned.
- The final Super Admin account cannot self-delete.
