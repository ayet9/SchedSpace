<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('departments')) {
            Schema::create('departments', function (Blueprint $t) {
                $t->id();
                $t->string('name')->unique();
                $t->boolean('is_active')->default(true)->index();
                $t->timestamps();
            });
        }

        if (! Schema::hasColumn('teachers', 'department_id')) {
            Schema::table('teachers', function (Blueprint $t) {
                $t->foreignId('department_id')
                    ->nullable()
                    ->after('user_id')
                    ->constrained('departments')
                    ->restrictOnDelete();
                $t->index(['department_id', 'employment_status']);
            });
        }

        DB::table('teachers')
            ->whereNotNull('department')
            ->whereNull('department_id')
            ->orderBy('id')
            ->get()
            ->each(function ($teacher) {
                $name = trim((string) $teacher->department);
                if ($name === '') {
                    return;
                }

                $dept = DB::table('departments')
                    ->whereRaw('LOWER(name) = ?', [strtolower($name)])
                    ->first();

                $id = $dept?->id;

                if (! $id) {
                    $id = DB::table('departments')->insertGetId([
                        'name' => $name,
                        'is_active' => 1,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                DB::table('teachers')
                    ->where('id', $teacher->id)
                    ->update(['department_id' => $id]);
            });

        if (! Schema::hasTable('audit_logs')) {
            Schema::create('audit_logs', function (Blueprint $t) {
                $t->id();
                $t->foreignId('actor_id')->nullable()->constrained('users')->nullOnDelete();
                $t->string('action', 50);
                $t->string('entity_type', 80);
                $t->unsignedBigInteger('entity_id')->nullable();
                $t->json('metadata')->nullable();
                $t->timestamps();
                $t->index(['entity_type', 'entity_id']);
                $t->index(['actor_id', 'created_at']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');

        if (Schema::hasColumn('teachers', 'department_id')) {
            Schema::table('teachers', function (Blueprint $t) {
                $t->dropForeign(['department_id']);
                $t->dropIndex(['department_id', 'employment_status']);
                $t->dropColumn('department_id');
            });
        }

        Schema::dropIfExists('departments');
    }
};
