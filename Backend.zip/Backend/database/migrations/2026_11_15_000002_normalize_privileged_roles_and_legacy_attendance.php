<?php

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $super = Role::query()->whereIn('slug', ['super_admin', 'root-admin', 'super-admin'])->orderBy('id')->first();
        $admin = Role::query()->where('slug', 'admin')->orderBy('id')->first();
        $teacher = Role::query()->where('slug', 'teacher')->orderBy('id')->first();

        if ($super) {
            DB::table('roles')->where('id', $super->id)->update(['slug' => 'super_admin', 'name' => 'Super Admin']);
            User::query()->where('role_id', $super->id)->orderBy('id')->get()->each(function (User $user, int $index): void {
                if ($index > 0) {
                    $user->forceFill(['role_id' => null, 'is_active' => false])->saveQuietly();
                }
            });
        }

        if ($admin) {
            DB::table('roles')->where('id', $admin->id)->update(['slug' => 'admin', 'name' => 'Admin']);
            User::query()->where('role_id', $admin->id)->orderBy('id')->get()->each(function (User $user, int $index): void {
                if ($index > 0) {
                    $user->forceFill(['role_id' => null, 'is_active' => false])->saveQuietly();
                }
            });
        }

        if ($teacher) {
            DB::table('roles')->where('id', $teacher->id)->update(['slug' => 'teacher', 'name' => 'Teacher']);
        }

        if (DB::getSchemaBuilder()->hasTable('classroom_layout_types') && DB::getSchemaBuilder()->hasTable('classrooms')) {
            $layoutId = DB::table('classroom_layout_types')->where('name', 'Standard rows')->value('id');
            if ($layoutId) DB::table('classrooms')->whereNull('layout_type_id')->update(['layout_type_id' => $layoutId]);
        }

        DB::table('attendances')
            ->whereNotNull('time_out')
            ->where('legacy_auto_timeout', false)
            ->whereNull('photo_out_path')
            ->update(['legacy_auto_timeout' => true, 'status' => 'legacy_auto_timeout']);
    }

    public function down(): void
    {
        // This migration intentionally does not restore duplicate privileged accounts.
    }
};
