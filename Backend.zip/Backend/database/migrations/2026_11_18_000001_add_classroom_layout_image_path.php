<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('classrooms', 'layout_image_path')) {
            Schema::table('classrooms', function (Blueprint $table) {
                $table->string('layout_image_path')->nullable()->after('layout_type_id');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('classrooms', 'layout_image_path')) {
            Schema::table('classrooms', function (Blueprint $table) {
                $table->dropColumn('layout_image_path');
            });
        }
    }
};
