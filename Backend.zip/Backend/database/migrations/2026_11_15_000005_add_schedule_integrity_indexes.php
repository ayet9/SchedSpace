<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('schedules', function (Blueprint $table) {
            $table->index(['schedule_date', 'teacher_id', 'start_time', 'end_time'], 'schedules_teacher_window_idx');
            $table->index(['schedule_date', 'classroom_id', 'start_time', 'end_time'], 'schedules_room_window_idx');
            $table->unique(['schedule_date', 'teacher_id', 'classroom_id', 'subject_id', 'start_time', 'end_time'], 'schedules_exact_unique');
        });
    }

    public function down(): void
    {
        Schema::table('schedules', function (Blueprint $table) {
            $table->dropUnique('schedules_exact_unique');
            $table->dropIndex('schedules_teacher_window_idx');
            $table->dropIndex('schedules_room_window_idx');
        });
    }
};
