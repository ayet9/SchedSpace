<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Older builds briefly used `super-admin` as the stored role slug while
     * the current authorization rules use `root-admin`. Merge the old role
     * into the canonical role so existing user assignments and permissions
     * survive upgrades.
     */
    public function up(): void
    {
        if (!Schema::hasTable('roles') || !Schema::hasColumn('roles', 'slug')) {
            return;
        }

        $canonical = DB::table('roles')->where('slug', 'root-admin')->first();
        $legacyRoles = DB::table('roles')->whereIn('slug', ['super-admin', 'super_admin'])->get();

        foreach ($legacyRoles as $legacyRole) {
            if (!$canonical) {
                DB::table('roles')->where('id', $legacyRole->id)->update([
                    'slug' => 'root-admin',
                    'name' => 'Super Admin',
                    'description' => 'Has full access to every SchedSpace module.',
                ]);

                $canonical = DB::table('roles')->where('slug', 'root-admin')->first();
                continue;
            }

            if (Schema::hasTable('users') && Schema::hasColumn('users', 'role_id')) {
                DB::table('users')->where('role_id', $legacyRole->id)->update([
                    'role_id' => $canonical->id,
                ]);
            }

            if (Schema::hasTable('role_permissions')) {
                $permissionIds = DB::table('role_permissions')
                    ->where('role_id', $legacyRole->id)
                    ->pluck('permission_id');

                foreach ($permissionIds as $permissionId) {
                    DB::table('role_permissions')->insertOrIgnore([
                        'role_id' => $canonical->id,
                        'permission_id' => $permissionId,
                    ]);
                }
            }

            DB::table('roles')->where('id', $legacyRole->id)->delete();
        }

        if ($canonical) {
            DB::table('roles')->where('id', $canonical->id)->update([
                'name' => 'Super Admin',
                'description' => 'Has full access to every SchedSpace module.',
            ]);
        }
    }

    public function down(): void
    {
        // Intentionally do not split or downgrade role assignments. Reverting
        // this data migration could reintroduce duplicate administrator roles.
    }
};
