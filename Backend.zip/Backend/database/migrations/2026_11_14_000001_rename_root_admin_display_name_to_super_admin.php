<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('roles')) {
            DB::table('roles')->where('slug', 'root-admin')->update([
                'name' => 'Super Admin',
                'description' => 'Has full access to every SchedSpace module.',
            ]);
        }
    }

    public function down(): void
    {
        if (Schema::hasTable('roles')) {
            DB::table('roles')->where('slug', 'root-admin')->update([
                'name' => 'Root Admin',
                'description' => 'Manages the entire SchedSpace system.',
            ]);
        }
    }
};
