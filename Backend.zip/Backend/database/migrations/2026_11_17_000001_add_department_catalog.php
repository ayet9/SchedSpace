<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('departments')) {
            Schema::create('departments', function (Blueprint $table) {
                $table->id();
                $table->string('name')->unique();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        if (!Schema::hasColumn('teachers', 'department_id')) {
            Schema::table('teachers', function (Blueprint $table) {
                $table->foreignId('department_id')->nullable()->after('department')->constrained('departments')->nullOnDelete();
            });
        }

        $names = DB::table('teachers')->whereNotNull('department')->pluck('department')->map(
            fn ($name) => preg_replace('/\s+/', ' ', trim((string) $name))
        )->filter()->unique()->values();

        foreach ($names as $name) {
            $departmentId = DB::table('departments')->whereRaw('LOWER(name) = ?', [mb_strtolower($name)])->value('id');
            if (!$departmentId) {
                $departmentId = DB::table('departments')->insertGetId([
                    'name' => $name,
                    'is_active' => true,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
            DB::table('teachers')->where('department', $name)->update(['department_id' => $departmentId]);
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('teachers', 'department_id')) {
            Schema::table('teachers', function (Blueprint $table) {
                $table->dropForeign(['department_id']);
                $table->dropColumn('department_id');
            });
        }
        Schema::dropIfExists('departments');
    }
};
