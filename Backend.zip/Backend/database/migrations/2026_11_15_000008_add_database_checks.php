<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE classrooms ADD CONSTRAINT classrooms_capacity_positive CHECK (capacity IS NULL OR capacity > 0)');
        DB::statement('ALTER TABLE schedules ADD CONSTRAINT schedules_end_after_start CHECK (end_time > start_time)');
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE schedules DROP CHECK schedules_end_after_start');
        DB::statement('ALTER TABLE classrooms DROP CHECK classrooms_capacity_positive');
    }
};

