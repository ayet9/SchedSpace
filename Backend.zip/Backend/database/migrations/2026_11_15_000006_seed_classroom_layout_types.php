<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $now = now();
        $layouts = [
            ['name' => 'Standard rows', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Individual desks in rows facing the front board.', 'features' => json_encode(['individual desks', 'front board', 'teacher desk']), 'image_path' => 'assets/classroom-layouts/standard-rows.svg'],
            ['name' => 'Group tables', 'typical_capacity' => 20, 'min_capacity' => 12, 'max_capacity' => 28, 'description' => 'Collaborative tables arranged in small groups.', 'features' => json_encode(['group tables', 'collaboration space', 'teacher desk']), 'image_path' => 'assets/classroom-layouts/group-tables.svg'],
            ['name' => 'U-shape', 'typical_capacity' => 18, 'min_capacity' => 10, 'max_capacity' => 24, 'description' => 'Tables arranged in a U for discussion and presentations.', 'features' => json_encode(['discussion layout', 'open center', 'front board']), 'image_path' => 'assets/classroom-layouts/u-shape.svg'],
            ['name' => 'Computer lab', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Individual computer stations with a clear instructor area.', 'features' => json_encode(['computer stations', 'monitor space', 'teacher desk']), 'image_path' => 'assets/classroom-layouts/computer-lab.svg'],
            ['name' => 'Science lab', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Lab benches with a front teaching station and safety aisle.', 'features' => json_encode(['lab benches', 'safety aisle', 'teacher station']), 'image_path' => 'assets/classroom-layouts/science-lab.svg'],
        ];
        foreach ($layouts as $layout) {
            DB::table('classroom_layout_types')->updateOrInsert(['name' => $layout['name']], [...$layout, 'created_at' => $now, 'updated_at' => $now]);
        }
        $standardId = DB::table('classroom_layout_types')->where('name', 'Standard rows')->value('id');
        if ($standardId) DB::table('classrooms')->whereNull('layout_type_id')->update(['layout_type_id' => $standardId]);
    }

    public function down(): void
    {
        DB::table('classrooms')->update(['layout_type_id' => null]);
        DB::table('classroom_layout_types')->whereIn('name', ['Standard rows', 'Group tables', 'U-shape', 'Computer lab', 'Science lab'])->delete();
    }
};
