<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $pairs = DB::table('schedules')->select('teacher_id', 'subject_id')->distinct()->get();
        foreach ($pairs as $pair) {
            DB::table('teacher_subjects')->insertOrIgnore([
                'teacher_id' => $pair->teacher_id,
                'subject_id' => $pair->subject_id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }

    public function down(): void
    {
        DB::table('teacher_subjects')->delete();
    }
};
