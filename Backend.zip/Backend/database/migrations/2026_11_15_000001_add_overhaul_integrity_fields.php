<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('is_active')->default(true)->index();
            $table->boolean('must_change_password')->default(false)->index();
        });

        Schema::create('classroom_layout_types', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->unsignedSmallInteger('typical_capacity');
            $table->unsignedSmallInteger('min_capacity');
            $table->unsignedSmallInteger('max_capacity');
            $table->text('description')->nullable();
            $table->json('features')->nullable();
            $table->string('image_path');
            $table->timestamps();
        });

        Schema::table('classrooms', function (Blueprint $table) {
            $table->foreignId('layout_type_id')->nullable()->after('room_number')->constrained('classroom_layout_types')->restrictOnDelete();
            $table->boolean('is_active')->default(true)->after('status')->index();
        });

        Schema::table('schedules', function (Blueprint $table) {
            $table->date('schedule_date')->nullable()->after('id')->index();
        });

        Schema::table('attendances', function (Blueprint $table) {
            $table->string('verification_status')->default('pending')->index();
            $table->string('status')->default('open')->index();
            $table->boolean('legacy_auto_timeout')->default(false)->index();
            $table->timestamp('manual_correction_at')->nullable();
            $table->foreignId('manual_corrected_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('manual_correction_reason')->nullable();
        });

        Schema::create('attendance_capture_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('teacher_id')->constrained()->cascadeOnDelete();
            $table->string('token_hash', 64)->unique();
            $table->string('action', 16);
            $table->timestamp('expires_at')->index();
            $table->timestamp('used_at')->nullable();
            $table->timestamps();
            $table->index(['teacher_id', 'action', 'expires_at']);
        });

        Schema::create('attendance_idempotency_keys', function (Blueprint $table) {
            $table->id();
            $table->foreignId('teacher_id')->constrained()->cascadeOnDelete();
            $table->string('action', 16);
            $table->string('request_key', 128);
            $table->foreignId('attendance_id')->nullable()->constrained('attendances')->nullOnDelete();
            $table->timestamps();
            $table->unique(['teacher_id', 'action', 'request_key']);
        });

        $driver = Schema::getConnection()->getDriverName();
        if ($driver === 'mysql') {
            DB::unprepared(<<<'SQL'
CREATE TRIGGER schedspace_users_singleton_privileged_role
BEFORE INSERT ON users
FOR EACH ROW
BEGIN
    IF NEW.role_id IS NOT NULL THEN
        IF EXISTS (SELECT 1 FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE r.slug = 'super_admin')
           AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.role_id AND r.slug = 'super_admin') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one Super Admin is allowed.';
        END IF;
        IF EXISTS (SELECT 1 FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE r.slug = 'admin')
           AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.role_id AND r.slug = 'admin') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one Admin is allowed.';
        END IF;
    END IF;
END
SQL);

            DB::unprepared(<<<'SQL'
CREATE TRIGGER schedspace_users_singleton_privileged_role_update
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
    IF NEW.role_id IS NOT NULL THEN
        IF EXISTS (SELECT 1 FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.id <> NEW.id AND r.slug = 'super_admin')
           AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.role_id AND r.slug = 'super_admin') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one Super Admin is allowed.';
        END IF;
        IF EXISTS (SELECT 1 FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.id <> NEW.id AND r.slug = 'admin')
           AND EXISTS (SELECT 1 FROM roles r WHERE r.id = NEW.role_id AND r.slug = 'admin') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one Admin is allowed.';
        END IF;
    END IF;
END
SQL);
        } elseif ($driver === 'sqlite') {
            DB::unprepared("CREATE TRIGGER schedspace_users_singleton_privileged_role BEFORE INSERT ON users BEGIN SELECT CASE WHEN NEW.role_id = (SELECT id FROM roles WHERE slug = 'super_admin') AND EXISTS (SELECT 1 FROM users WHERE role_id = NEW.role_id) THEN RAISE(ABORT, 'Only one Super Admin is allowed.') END; SELECT CASE WHEN NEW.role_id = (SELECT id FROM roles WHERE slug = 'admin') AND EXISTS (SELECT 1 FROM users WHERE role_id = NEW.role_id) THEN RAISE(ABORT, 'Only one Admin is allowed.') END; END");
            DB::unprepared("CREATE TRIGGER schedspace_users_singleton_privileged_role_update BEFORE UPDATE ON users BEGIN SELECT CASE WHEN NEW.role_id = (SELECT id FROM roles WHERE slug = 'super_admin') AND EXISTS (SELECT 1 FROM users WHERE role_id = NEW.role_id AND id <> NEW.id) THEN RAISE(ABORT, 'Only one Super Admin is allowed.') END; SELECT CASE WHEN NEW.role_id = (SELECT id FROM roles WHERE slug = 'admin') AND EXISTS (SELECT 1 FROM users WHERE role_id = NEW.role_id AND id <> NEW.id) THEN RAISE(ABORT, 'Only one Admin is allowed.') END; END");
        }
    }

    public function down(): void
    {
        $driver = Schema::getConnection()->getDriverName();
        if ($driver === 'mysql' || $driver === 'sqlite') {
            DB::unprepared('DROP TRIGGER IF EXISTS schedspace_users_singleton_privileged_role');
            DB::unprepared('DROP TRIGGER IF EXISTS schedspace_users_singleton_privileged_role_update');
        }

        Schema::dropIfExists('attendance_idempotency_keys');
        Schema::dropIfExists('attendance_capture_tokens');

        Schema::table('attendances', function (Blueprint $table) {
            $table->dropForeign(['manual_corrected_by']);
            $table->dropColumn([
                'verification_status', 'status', 'legacy_auto_timeout',
                'manual_correction_at', 'manual_corrected_by', 'manual_correction_reason',
            ]);
        });

        Schema::table('schedules', function (Blueprint $table) {
            $table->dropColumn('schedule_date');
        });

        Schema::table('classrooms', function (Blueprint $table) {
            $table->dropForeign(['layout_type_id']);
            $table->dropColumn(['layout_type_id', 'is_active']);
        });

        Schema::dropIfExists('classroom_layout_types');

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['is_active', 'must_change_password']);
        });
    }
};
