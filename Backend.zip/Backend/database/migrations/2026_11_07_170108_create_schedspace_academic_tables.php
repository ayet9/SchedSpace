
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ROLES
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->timestamps();
        });

        // PERMISSIONS
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('key')->unique();
            $table->text('description')->nullable();
            $table->timestamps();
        });

        // ROLE-PERMISSION RELATIONSHIP
        Schema::create('role_permissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('role_id')->constrained()->cascadeOnDelete();
            $table->foreignId('permission_id')->constrained()->cascadeOnDelete();
            $table->unique(['role_id', 'permission_id']);
        });

        // ADD ROLE TO EXISTING USERS
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('role_id')
                ->nullable()
                ->after('id')
                ->constrained('roles')
                ->nullOnDelete();
        });

        // ADDITIONAL USER-SPECIFIC PERMISSIONS
        Schema::create('user_permissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('permission_id')->constrained()->cascadeOnDelete();
            $table->unique(['user_id', 'permission_id']);
        });

        // TEACHERS
        Schema::create('teachers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')
                ->nullable()
                ->unique()
                ->constrained()
                ->nullOnDelete();

            $table->string('employee_number')->nullable()->unique();
            $table->string('department')->nullable();
            $table->string('employment_status')->default('Active');
            $table->timestamps();
        });

        // CLASSROOMS
        Schema::create('classrooms', function (Blueprint $table) {
            $table->id();
            $table->string('room_number')->unique();
            $table->string('building')->nullable();
            $table->string('floor')->nullable();
            $table->string('location_description')->nullable();
            $table->text('layout_description')->nullable();
            $table->unsignedSmallInteger('capacity')->nullable();
            $table->string('status')->default('Available');
            $table->timestamps();
        });

        // STUDENTS
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('student_number')->unique();
            $table->string('first_name');
            $table->string('middle_name')->nullable();
            $table->string('last_name');
            $table->string('program')->nullable();
            $table->string('year_level')->nullable();
            $table->string('section')->nullable();
            $table->string('status')->default('Active');
            $table->timestamps();
        });

        // SUBJECTS
        Schema::create('subjects', function (Blueprint $table) {
            $table->id();
            $table->string('subject_code')->unique();
            $table->string('subject_name');
            $table->text('description')->nullable();
            $table->unsignedSmallInteger('units')->nullable();
            $table->timestamps();
        });

        // STUDENT-SUBJECT ASSIGNMENTS
        Schema::create('student_subjects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();
            $table->foreignId('subject_id')->constrained()->cascadeOnDelete();
            $table->string('school_year');
            $table->string('semester')->nullable();
            $table->timestamps();

            $table->unique([
                'student_id',
                'subject_id',
                'school_year',
                'semester'
            ], 'student_subject_unique');
        });

        // SCHEDULES
        Schema::create('schedules', function (Blueprint $table) {
            $table->id();

            $table->foreignId('teacher_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('classroom_id')
                ->constrained()
                ->restrictOnDelete();

            $table->foreignId('subject_id')
                ->constrained()
                ->restrictOnDelete();

            $table->string('day_of_week');
            $table->time('start_time');
            $table->time('end_time');

            $table->string('school_year');
            $table->string('semester')->nullable();
            $table->string('section')->nullable();

            $table->timestamps();
        });

        // TEACHER ATTENDANCE
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();

            $table->foreignId('teacher_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->date('attendance_date');
            $table->time('time_in')->nullable();
            $table->string('photo_in_path')->nullable();

            $table->time('time_out')->nullable();
            $table->string('photo_out_path')->nullable();

            $table->timestamps();

            $table->unique(
                ['teacher_id', 'attendance_date'],
                'teacher_daily_attendance_unique'
            );
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendances');
        Schema::dropIfExists('schedules');
        Schema::dropIfExists('student_subjects');
        Schema::dropIfExists('subjects');
        Schema::dropIfExists('students');
        Schema::dropIfExists('classrooms');
        Schema::dropIfExists('teachers');

        Schema::dropIfExists('user_permissions');

        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('role_id');
        });

        Schema::dropIfExists('role_permissions');
        Schema::dropIfExists('permissions');
        Schema::dropIfExists('roles');
    }
};
