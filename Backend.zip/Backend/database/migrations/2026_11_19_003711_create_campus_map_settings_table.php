<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('campus_map_settings', function (Blueprint $table) {
            $table->string('map_key', 32)->primary();
            $table->json('walkways');
            $table->timestamps();
        });

        DB::table('campus_map_settings')->insert([
            'map_key' => 'main',
            'walkways' => '[]',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('campus_map_settings');
    }
};
