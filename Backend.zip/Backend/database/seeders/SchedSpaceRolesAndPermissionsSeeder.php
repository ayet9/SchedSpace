<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Permission;
use App\Models\Role;

class SchedSpaceRolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // SYSTEM ROLES
        $roles = [
            [
                'name' => 'Super Admin',
                'slug' => 'root-admin',
                'description' => 'Has full access to every SchedSpace module.'
            ],
            [
                'name' => 'Super Admin',
                'slug' => 'super_admin',
                'description' => 'Has full access to every SchedSpace module.'
            ],
            [
                'name' => 'Admin',
                'slug' => 'admin',
                'description' => 'Manages classrooms, teachers, and schedules.'
            ],
            [
                'name' => 'Teacher',
                'slug' => 'teacher',
                'description' => 'Views teacher schedules and assigned student lists.'
            ],
        ];

        foreach ($roles as $role) {
            Role::updateOrCreate(['slug' => $role['slug']], $role);
        }

        // SYSTEM PERMISSIONS
        $permissions = [
            ['name' => 'View Dashboard', 'key' => 'view_dashboard'],
            ['name' => 'View Classrooms', 'key' => 'view_classrooms'],
            ['name' => 'Manage Classrooms', 'key' => 'manage_classrooms'],
            ['name' => 'View Schedules', 'key' => 'view_schedules'],
            ['name' => 'Manage Schedules', 'key' => 'manage_schedules'],
            ['name' => 'View Own Schedule', 'key' => 'view_own_schedule'],
            ['name' => 'View Other Teacher Schedules', 'key' => 'view_other_teacher_schedules'],
            ['name' => 'Manage Teachers', 'key' => 'manage_teachers'],
            ['name' => 'Reset Teacher Password', 'key' => 'reset_teacher_password'],
            ['name' => 'View Departments', 'key' => 'view_departments'],
            ['name' => 'Manage Departments', 'key' => 'manage_departments'],
            ['name' => 'View Audit Logs', 'key' => 'view_audit_logs'],
            ['name' => 'View Teachers', 'key' => 'view_teachers'],
            ['name' => 'Manage Students', 'key' => 'manage_students'],
            ['name' => 'View Subjects', 'key' => 'view_subjects'],
            ['name' => 'Manage Subjects', 'key' => 'manage_subjects'],
            ['name' => 'View Assigned Student Lists', 'key' => 'view_assigned_student_lists'],
            ['name' => 'View Other Student Lists', 'key' => 'view_other_student_lists'],
            ['name' => 'Manage Users', 'key' => 'manage_users'],
            ['name' => 'Manage Roles and Permissions', 'key' => 'manage_roles_permissions'],
            ['name' => 'Record Attendance', 'key' => 'record_attendance'],
            ['name' => 'View Attendance Records', 'key' => 'view_attendance'],
            ['name' => 'Export Reports', 'key' => 'export_reports'],
        ];

        foreach ($permissions as $permission) {
            Permission::updateOrCreate(['key' => $permission['key']], $permission);
        }

        // Permissions are synchronized so rerunning this seeder also removes stale grants.
        $allPermissionKeys = Permission::query()->pluck('key')->all();

        $rolePermissions = [
            'root-admin' => $allPermissionKeys,
            'super_admin' => $allPermissionKeys,

            'admin' => [
                'view_dashboard',
                'view_classrooms',
                'manage_classrooms',
                'view_schedules',
                'manage_schedules',
                'view_other_teacher_schedules',
                'view_teachers',
                'reset_teacher_password',
                'view_departments',
                'manage_students',
                'view_subjects',
                'manage_subjects',
                'view_attendance',
            ],

            'teacher' => [
                'view_dashboard',
                'view_classrooms',
                'view_teachers',
                'view_own_schedule',
                'view_other_teacher_schedules',
                'view_assigned_student_lists',
                'view_subjects',
                'record_attendance',
            ],
        ];

        foreach ($rolePermissions as $roleSlug => $permissionKeys) {
            $role = Role::where('slug', $roleSlug)->firstOrFail();
            $role->permissions()->sync(
                Permission::whereIn('key', $permissionKeys)->pluck('id')
            );
        }
    }
}
