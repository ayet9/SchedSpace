<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClassroomLayoutTypeSeeder extends Seeder
{
    public function run(): void
    {
        $layouts = [
            ['name' => 'Standard rows', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Individual desks in rows facing the front board.', 'features' => ['individual desks', 'front board', 'teacher desk'], 'image_path' => 'assets/classroom-layouts/standard-rows.svg'],
            ['name' => 'Group tables', 'typical_capacity' => 20, 'min_capacity' => 12, 'max_capacity' => 28, 'description' => 'Collaborative tables arranged in small groups.', 'features' => ['group tables', 'collaboration space', 'teacher desk'], 'image_path' => 'assets/classroom-layouts/group-tables.svg'],
            ['name' => 'U-shape', 'typical_capacity' => 18, 'min_capacity' => 10, 'max_capacity' => 24, 'description' => 'Tables arranged in a U for discussion and presentations.', 'features' => ['discussion layout', 'open center', 'front board'], 'image_path' => 'assets/classroom-layouts/u-shape.svg'],
            ['name' => 'Computer lab', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Individual computer stations with a clear instructor area.', 'features' => ['computer stations', 'monitor space', 'teacher desk'], 'image_path' => 'assets/classroom-layouts/computer-lab.svg'],
            ['name' => 'Science lab', 'typical_capacity' => 24, 'min_capacity' => 16, 'max_capacity' => 32, 'description' => 'Lab benches with a front teaching station and safety aisle.', 'features' => ['lab benches', 'safety aisle', 'teacher station'], 'image_path' => 'assets/classroom-layouts/science-lab.svg'],
        ];

        foreach ($layouts as $layout) {
            DB::table('classroom_layout_types')->updateOrInsert(
                ['name' => $layout['name']],
                [...$layout, 'features' => json_encode($layout['features']), 'updated_at' => now(), 'created_at' => now()]
            );
        }
    }
}
