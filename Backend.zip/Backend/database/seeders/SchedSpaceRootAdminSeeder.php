<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/** Seeds the predictable local/test Super Admin account. */
class SchedSpaceRootAdminSeeder extends Seeder
{
    private const DEFAULT_FIRST_NAME = 'Rafael';
    private const DEFAULT_LAST_NAME = 'Cruz';
    private const DEFAULT_USERNAME = 'rcruz';
    private const DEFAULT_EMAIL = 'rafael.cruz@school.example';
    private const DEFAULT_PASSWORD = 'SchedSpaceDemo!';

    public function run(): void
    {
        $role = Role::query()->where('slug', 'root-admin')->firstOrFail();

        $email = (string) env('SCHEDSPACE_SEED_SUPER_EMAIL', self::DEFAULT_EMAIL);
        $user = User::firstOrNew(['email' => $email]);
        $isNewUser = !$user->exists;

        $user->fill([
            'name' => self::DEFAULT_FIRST_NAME.' '.self::DEFAULT_LAST_NAME,
            'first_name' => self::DEFAULT_FIRST_NAME,
            'middle_name' => null,
            'last_name' => self::DEFAULT_LAST_NAME,
            'username' => self::DEFAULT_USERNAME,
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => false,
            'email_verified_at' => now(),
        ]);

        // Only initialize the password for a newly-created test account.
        // Re-seeding must not reset a password that a tester already changed.
        if ($isNewUser) {
            $user->password = Hash::make(
                (string) env('SCHEDSPACE_SEED_SUPER_PASSWORD', self::DEFAULT_PASSWORD)
            );
            $user->remember_token = Str::random(10);
        }

        $user->save();
        $this->command?->info("Initial Super Admin account available: {$email}");
    }
}
