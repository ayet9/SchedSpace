<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /** Seed the complete baseline SchedSpace data required for a fresh installation. */
    public function run(): void
    {
        $this->call([
            SchedSpaceRolesAndPermissionsSeeder::class,
            ClassroomLayoutTypeSeeder::class,
            SchedSpaceRootAdminSeeder::class,
            SchedSpaceAdminSeeder::class,
        ]);
    }
}
