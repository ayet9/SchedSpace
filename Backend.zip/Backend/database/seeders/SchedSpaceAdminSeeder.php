<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/** Seeds the predictable local/test Admin account. */
class SchedSpaceAdminSeeder extends Seeder
{
    private const DEFAULT_FIRST_NAME = 'System';
    private const DEFAULT_LAST_NAME = 'Admin';
    private const DEFAULT_USERNAME = 'admin';
    private const DEFAULT_EMAIL = 'admin@school.example';
    private const DEFAULT_PASSWORD = 'SchedSpaceDemo!';

    public function run(): void
    {
        $role = Role::query()->where('slug', 'admin')->firstOrFail();
        $email = (string) env('SCHEDSPACE_SEED_ADMIN_EMAIL', self::DEFAULT_EMAIL);
        $user = User::firstOrNew(['email' => $email]);
        $isNewUser = !$user->exists;

        $user->fill([
            'name' => self::DEFAULT_FIRST_NAME.' '.self::DEFAULT_LAST_NAME,
            'first_name' => self::DEFAULT_FIRST_NAME,
            'middle_name' => null,
            'last_name' => self::DEFAULT_LAST_NAME,
            'username' => (string) env('SCHEDSPACE_SEED_ADMIN_USERNAME', self::DEFAULT_USERNAME),
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => false,
            'email_verified_at' => now(),
        ]);

        if ($isNewUser) {
            $user->password = Hash::make(
                (string) env('SCHEDSPACE_SEED_ADMIN_PASSWORD', self::DEFAULT_PASSWORD)
            );
        }

        $user->save();
        $this->command?->info("Initial Admin account available: {$email}");
    }
}
