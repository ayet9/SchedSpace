<?php

namespace Database\Seeders;

use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Role;
use App\Models\Schedule;
use App\Models\Student;
use App\Models\StudentSubject;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class SchedSpaceDemoDataSeeder extends Seeder
{
    private const SCHOOL_YEAR = '2026-2027';
    private const SEMESTER = '1st Semester';

    public function run(): void
    {
        $roles = Role::query()->get()->keyBy('slug');
        $demoPassword = Hash::make('SchedSpaceDemo!');
        // Demo/test accounts use one predictable password and are not forced to change it.

        $accounts = [
            ['Rafael', null, 'Cruz', 'rcruz', 'rafael.cruz@school.example', 'root-admin'],
            ['Elena', 'M.', 'Garcia', 'egarcia', 'elena.garcia@school.example', 'admin'],
        ];
        $teacherProfiles = [
            ['Maria', 'Santos', 'Information Technology'],
            ['Jose', 'Reyes', 'Information Technology'],
            ['Ana', 'Villanueva', 'Information Technology'],
            ['Liza', 'Mendoza', 'General Education'],
            ['Paolo', 'Dizon', 'Information Technology'],
            ['Carlo', 'Ramirez', 'Information Technology'],
        ];

        foreach ($teacherProfiles as $index => [$first, $last, $department]) {
            $accounts[] = [
                $first, null, $last, strtolower($first[0].$last),
                strtolower($first.'.'.$last).'@school.example', 'teacher', $department,
            ];
        }
        $accounts[] = ['Miguel', null, 'Torres', 'mtorres', 'miguel.torres@school.example', null];
        $accounts[] = ['Sofia', 'R.', 'Lim', 'slim', 'sofia.lim@school.example', null];

        $teachers = [];
        foreach ($accounts as $index => $account) {
            [$first, $middle, $last, $username, $email, $roleSlug] = $account;
            $fullName = trim(implode(' ', array_filter([$first, $middle, $last])));
            $user = User::updateOrCreate(
                ['email' => $email],
                [
                    'name' => $fullName,
                    'first_name' => $first,
                    'middle_name' => $middle,
                    'last_name' => $last,
                    'username' => $username,
                    'role_id' => $roleSlug ? $roles[$roleSlug]->id : null,
                    'password' => $demoPassword,
                    'must_change_password' => false,
                    'is_active' => true,
                ]
            );
            if ($roleSlug === 'teacher') {
                $profile = $teacherProfiles[$index - 2];
                $teacher = Teacher::updateOrCreate(
                    ['user_id' => $user->id],
                    [
                        'employee_number' => 'T-'.str_pad((string) ($index - 1), 3, '0', STR_PAD_LEFT),
                        'department' => $profile[2],
                        'employment_status' => 'Active',
                    ]
                );
                $teachers[$index - 2] = $teacher;
            }
        }

        $roomSpecs = [
            ['9', 'Main Building', '2nd floor', 40, ['Whiteboard', 'Projector'], ['col' => 1, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 3, 'door' => 'bottom']],
            ['10', 'Main Building', '2nd floor', 40, ['Whiteboard', 'Projector'], ['col' => 4, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 3, 'door' => 'bottom']],
            ['11', 'Main Building', '2nd floor', 35, ['Whiteboard'], ['col' => 7, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 3, 'door' => 'bottom']],
            ['12', 'Main Building', '2nd floor', 35, ['Whiteboard', 'Projector'], ['col' => 10, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 3, 'door' => 'bottom']],
            ['13', 'Main Building', '2nd floor', 45, ['Whiteboard', 'Projector', 'Air conditioning'], ['col' => 1, 'row' => 5, 'colSpan' => 4, 'rowSpan' => 3, 'door' => 'top']],
            ['14', 'Main Building', '2nd floor', 30, ['30 computers', 'Projector', 'Air conditioning'], ['col' => 5, 'row' => 5, 'colSpan' => 4, 'rowSpan' => 3, 'door' => 'top']],
            ['15', 'Main Building', '2nd floor', 30, ['Whiteboard'], ['col' => 9, 'row' => 5, 'colSpan' => 4, 'rowSpan' => 3, 'door' => 'top']],
        ];
        $rooms = [];
        foreach ($roomSpecs as [$number, $building, $floor, $capacity, $features, $plan]) {
            $rooms[$number] = Classroom::updateOrCreate(
                ['room_number' => $number],
                [
                    'building' => $building,
                    'floor' => $floor,
                    'capacity' => $capacity,
                    'features' => $features,
                    'plan' => $plan,
                    'status' => 'Available',
                ]
            );
        }

        $subjectSpecs = [
            ['IT 101', 'Introduction to Computing'], ['IT 102', 'Programming 1'],
            ['IT 201', 'Data Structures'], ['IT 202', 'Database Systems'],
            ['IT 203', 'Web Systems'], ['IT 301', 'Software Engineering'],
            ['IT 302', 'Computer Networks'], ['GE 101', 'Purposive Communication'],
        ];
        $subjects = [];
        foreach ($subjectSpecs as [$code, $title]) {
            $subjects[$code] = Subject::updateOrCreate(
                ['subject_code' => $code],
                ['subject_name' => $title, 'units' => 3]
            );
        }

        $studentNames = [
            'Angela Bautista', 'Mark Dela Cruz', 'Jasmine Flores', 'Ryan Aquino',
            'Kristine Navarro', 'Daniel Castillo', 'Patricia Ocampo', 'Joshua Soriano',
            'Bianca Domingo', 'Nathan Pascual', 'Chloe Mercado', 'Gabriel Valdez',
            'Hannah Salazar', 'Ethan Robles', 'Isabel Tan', 'Lucas Manalo',
        ];
        $students = [];
        foreach ($studentNames as $index => $fullName) {
            [$first, $last] = explode(' ', $fullName, 2);
            $year = ($index % 3) + 1;
            $students[] = Student::updateOrCreate(
                ['student_number' => '2024-'.str_pad((string) (101 + $index), 4, '0', STR_PAD_LEFT)],
                [
                    'first_name' => $first,
                    'last_name' => $last,
                    'program' => 'BSIT',
                    'year_level' => (string) $year,
                    'section' => 'BSIT-'.$year.'A',
                    'status' => 'Active',
                ]
            );
        }

        $subjectCodesByYear = [
            1 => ['IT 101', 'IT 102', 'GE 101'],
            2 => ['IT 201', 'IT 202', 'IT 203'],
            3 => ['IT 301', 'IT 302', 'IT 203'],
        ];
        foreach ($students as $student) {
            foreach ($subjectCodesByYear[(int) $student->year_level] as $code) {
                StudentSubject::updateOrCreate(
                    [
                        'student_id' => $student->id,
                        'subject_id' => $subjects[$code]->id,
                        'school_year' => self::SCHOOL_YEAR,
                        'semester' => self::SEMESTER,
                    ],
                    []
                );
            }
        }

        $sessionRows = [
            ['IT 102', 0, '9', 1, '07:30', '09:00'], ['IT 101', 1, '10', 1, '07:30', '09:00'], ['IT 203', 2, '14', 1, '09:00', '12:00'],
            ['GE 101', 3, '11', 1, '09:30', '11:00'], ['IT 201', 4, '9', 1, '13:00', '14:30'], ['IT 302', 5, '13', 1, '13:00', '15:00'],
            ['IT 202', 0, '10', 2, '08:00', '10:00'], ['IT 301', 1, '12', 2, '10:00', '12:00'], ['IT 102', 4, '9', 2, '13:00', '14:30'],
            ['GE 101', 3, '15', 2, '14:00', '15:30'],
            ['IT 102', 0, '9', 3, '07:30', '09:00'], ['IT 101', 1, '10', 3, '07:30', '09:00'], ['IT 203', 2, '14', 3, '09:00', '12:00'],
            ['GE 101', 3, '11', 3, '09:30', '11:00'], ['IT 201', 4, '9', 3, '13:00', '14:30'], ['IT 302', 5, '13', 3, '13:00', '15:00'],
            ['IT 202', 0, '12', 3, '15:00', '17:00'],
            ['IT 202', 0, '10', 4, '08:00', '10:00'], ['IT 301', 1, '12', 4, '10:00', '12:00'], ['IT 302', 5, '13', 4, '10:00', '12:00'],
            ['IT 203', 2, '14', 4, '13:00', '16:00'],
            ['IT 201', 4, '9', 5, '08:00', '10:00'], ['IT 101', 1, '11', 5, '10:30', '12:00'], ['IT 102', 0, '15', 5, '13:00', '14:30'],
            ['GE 101', 3, '10', 5, '14:00', '15:30'],
            ['IT 301', 1, '9', 6, '08:00', '11:00'], ['IT 202', 0, '14', 6, '08:00', '10:00'],
        ];
        foreach ($sessionRows as [$code, $teacherIndex, $roomNumber, $weekday, $start, $end]) {
            $day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][$weekday - 1];
            Schedule::updateOrCreate(
                [
                    'teacher_id' => $teachers[$teacherIndex]->id,
                    'classroom_id' => $rooms[$roomNumber]->id,
                    'subject_id' => $subjects[$code]->id,
                    'day_of_week' => $day,
                    'start_time' => $start,
                    'school_year' => self::SCHOOL_YEAR,
                    'semester' => self::SEMESTER,
                    'section' => null,
                ],
                ['end_time' => $end]
            );
        }

        $todayTimes = [
            ['07:24', null], ['07:41', null], ['08:52', null],
            [null, null], ['07:55', '10:05'], [null, null],
        ];
        foreach ($teachers as $index => $teacher) {
            [$timeIn, $timeOut] = $todayTimes[$index];
            Attendance::updateOrCreate(
                ['teacher_id' => $teacher->id, 'attendance_date' => now()->toDateString()],
                ['time_in' => $timeIn, 'time_out' => $timeOut]
            );
        }
    }
}
