<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class SchedSpaceSystemAccountsSeeder extends Seeder
{
    /*
     * Fixed credentials are intentional for local/test seeding.
     * This seeder must never generate a random password because a tester
     * needs predictable credentials after every fresh database seed.
     */
    private const DEFAULT_PASSWORD = 'SchedSpaceDemo!';

    public function run(): void
    {
        $superRole = Role::where('slug', 'super_admin')->firstOrFail();
        $adminRole = Role::where('slug', 'admin')->firstOrFail();

        $superPassword = (string) env('SCHEDSPACE_SEED_SUPER_PASSWORD', self::DEFAULT_PASSWORD);
        $adminPassword = (string) env('SCHEDSPACE_SEED_ADMIN_PASSWORD', self::DEFAULT_PASSWORD);

        $this->ensureAccount(
            role: $superRole,
            firstName: (string) env('SCHEDSPACE_SEED_SUPER_FIRST_NAME', 'System'),
            lastName: (string) env('SCHEDSPACE_SEED_SUPER_LAST_NAME', 'Administrator'),
            username: (string) env('SCHEDSPACE_SEED_SUPER_USERNAME', 'superadmin'),
            email: (string) env('SCHEDSPACE_SEED_SUPER_EMAIL', 'superadmin@school.example'),
            password: $superPassword,
        );

        $this->ensureAccount(
            role: $adminRole,
            firstName: (string) env('SCHEDSPACE_SEED_ADMIN_FIRST_NAME', 'System'),
            lastName: (string) env('SCHEDSPACE_SEED_ADMIN_LAST_NAME', 'Admin'),
            username: (string) env('SCHEDSPACE_SEED_ADMIN_USERNAME', 'admin'),
            email: (string) env('SCHEDSPACE_SEED_ADMIN_EMAIL', 'admin@school.example'),
            password: $adminPassword,
        );

        $this->command?->info('Seeded the test Super Admin and Admin accounts with fixed credentials.');
        $this->command?->line('Super Admin: superadmin@school.example / '.$superPassword);
        $this->command?->line('Admin: admin@school.example / '.$adminPassword);
    }

    private function ensureAccount(
        Role $role,
        string $firstName,
        string $lastName,
        string $username,
        string $email,
        string $password,
    ): void {
        $existing = User::where('email', $email)->first();

        if ($existing) {
            // Seeding must not unexpectedly replace a password that a tester
            // has already changed. Keep existing credentials intact.
            return;
        }

        User::create([
            'name' => trim("{$firstName} {$lastName}"),
            'first_name' => trim($firstName),
            'middle_name' => null,
            'last_name' => trim($lastName),
            'username' => trim($username),
            'email' => trim($email),
            'password' => Hash::make($password),
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => false,
            'email_verified_at' => now(),
            'remember_token' => Str::random(10),
        ]);
    }
}
