<?php

namespace Tests\Feature;

use App\Models\Building;
use App\Models\Classroom;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class BuildingManagementTest extends TestCase
{
    use RefreshDatabase;

    private function superAdmin(): User
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $role = Role::where('slug', 'super_admin')->firstOrFail();

        return User::create([
            'name' => 'Super Admin', 'first_name' => 'Super', 'last_name' => 'Admin',
            'username' => 'superadmin', 'email' => 'super@example.test', 'password' => Hash::make('Password123'),
            'role_id' => $role->id, 'is_active' => true, 'must_change_password' => false,
        ]);
    }

    public function test_buildings_floors_room_positions_and_walkways_are_saved(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');
        $building = $this->postJson('/api/buildings', ['name' => ' Main Building ', 'floor_count' => 2])
            ->assertCreated()
            ->assertJsonPath('building.name', 'Main Building')
            ->assertJsonPath('building.floor_count', 2)
            ->json('building');

        $this->putJson("/api/buildings/{$building['id']}/position", ['map_x' => 36, 'map_y' => 62])
            ->assertOk()->assertJsonPath('building.map_x', 36)->assertJsonPath('building.map_y', 62);
        $this->assertDatabaseHas('buildings', ['id' => $building['id'], 'map_x' => 36, 'map_y' => 62]);

        $room = Classroom::create([
            'room_number' => '101', 'building' => 'Main Building', 'floor' => '1', 'capacity' => 30,
            'status' => 'Available', 'is_active' => true,
            'plan' => ['col' => 1, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom'],
        ]);

        $this->putJson("/api/buildings/{$building['id']}/floors/1/walkways", [
            'cells' => [['col' => 4, 'row' => 1], ['col' => 5, 'row' => 1]],
        ])->assertOk()->assertJsonPath('building.walkways.1.0.col', 4);

        $this->getJson('/api/buildings')
            ->assertOk()
            ->assertJsonPath('0.room_count', 1)
            ->assertJsonPath('0.floors.0.room_count', 1);

        $this->putJson("/api/classrooms/{$room->id}/plan", [
            'plan' => ['col' => 4, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom'],
        ])->assertStatus(422)->assertJsonPath('message', 'Move the walkway marker before placing a classroom here.');

        $this->putJson("/api/buildings/{$building['id']}", ['name' => 'Science Building', 'floor_count' => 2])
            ->assertOk()->assertJsonPath('building.name', 'Science Building');
        $this->assertDatabaseHas('classrooms', ['id' => $room->id, 'building' => 'Science Building']);
        $this->deleteJson("/api/buildings/{$building['id']}")->assertStatus(409);
    }

    public function test_building_floor_count_cannot_exclude_assigned_classrooms(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');
        $building = Building::create(['name' => 'North Wing', 'floor_count' => 3]);
        Classroom::create(['room_number' => '301', 'building' => 'North Wing', 'floor' => '3', 'capacity' => 24, 'status' => 'Available', 'is_active' => true]);

        $this->putJson("/api/buildings/{$building->id}", ['name' => 'North Wing', 'floor_count' => 2])
            ->assertStatus(409);
    }

    public function test_new_building_cannot_hide_legacy_rooms_above_its_floor_count(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');
        Classroom::create(['room_number' => '401', 'building' => 'Legacy Hall', 'floor' => '4', 'capacity' => 24, 'status' => 'Available', 'is_active' => true]);

        $this->postJson('/api/buildings', ['name' => 'Legacy Hall', 'floor_count' => 2])
            ->assertStatus(409)
            ->assertJsonPath('message', 'This building already has classrooms on floor 4. Set the floor count to at least 4.');
    }

    public function test_classroom_positions_can_be_swapped_atomically(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');
        Classroom::create(['room_number' => '101', 'building' => 'Main', 'floor' => '1', 'capacity' => 24, 'status' => 'Available', 'is_active' => true,
            'plan' => ['col' => 1, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom']]);
        Classroom::create(['room_number' => '102', 'building' => 'Main', 'floor' => '1', 'capacity' => 24, 'status' => 'Available', 'is_active' => true,
            'plan' => ['col' => 4, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom']]);
        $rooms = Classroom::orderBy('room_number')->get();

        $this->putJson('/api/classrooms/positions', ['placements' => [
            ['id' => $rooms[0]->id, 'plan' => ['col' => 4, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom']],
            ['id' => $rooms[1]->id, 'plan' => ['col' => 1, 'row' => 1, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'bottom']],
        ]])->assertOk()->assertJsonCount(2, 'classrooms');

        $this->assertSame(4, Classroom::findOrFail($rooms[0]->id)->plan['col']);
        $this->assertSame(1, Classroom::findOrFail($rooms[1]->id)->plan['col']);
    }
}
