<?php
namespace Tests\Feature;
use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;
class PasswordChangeRequiredTest extends TestCase
{
 use RefreshDatabase;
 private function user(): User { $role=Role::create(['name'=>'Teacher','slug'=>'teacher','description'=>'']); return User::create(['name'=>'Temp User','first_name'=>'Temp','last_name'=>'User','username'=>'tempuser','email'=>'temp@example.test','password'=>Hash::make('Temporary123'),'role_id'=>$role->id,'is_active'=>true,'must_change_password'=>true]); }
 public function test_new_teacher_account_can_login_with_issued_temporary_password_and_change_it():void{$this->seed();$superAdmin=User::where('email','rafael.cruz@school.example')->firstOrFail();$created=$this->actingAs($superAdmin,'sanctum')->postJson('/api/teachers',['first_name'=>'Temporary','last_name'=>'Teacher','username'=>'temporary.teacher','email'=>'temporary.teacher@example.test'])->assertCreated();$this->assertTrue((bool)$created->json('teacher.user.must_change_password'));$temporaryPassword=$created->json('temporary_password');$this->assertIsString($temporaryPassword);Auth::forgetGuards();$login=$this->postJson('/api/login',['email'=>'temporary.teacher@example.test','password'=>$temporaryPassword])->assertOk()->assertJsonStructure(['token','user'=>['id','role'=>['slug']]])->assertJsonPath('must_change_password',true)->assertJsonPath('user.role.slug','teacher');$this->withToken($login->json('token'))->postJson('/api/password/change',['current_password'=>$temporaryPassword,'password'=>'NewTeacherPassword123','password_confirmation'=>'NewTeacherPassword123'])->assertOk()->assertJsonPath('must_change_password',false);}
 public function test_required_flag_blocks_dashboard_but_allows_password_change():void{$u=$this->user();$this->actingAs($u,'sanctum')->getJson('/api/dashboard')->assertStatus(403)->assertJsonPath('code','password_change_required');$this->actingAs($u,'sanctum')->postJson('/api/password/change',['current_password'=>'Temporary123','password'=>'NewPassword123','password_confirmation'=>'NewPassword123'])->assertOk()->assertJsonPath('must_change_password',false);$this->assertFalse((bool)$u->fresh()->must_change_password);}
 public function test_new_password_must_differ_from_current():void{$u=$this->user();$this->actingAs($u,'sanctum')->postJson('/api/password/change',['current_password'=>'Temporary123','password'=>'Temporary123','password_confirmation'=>'Temporary123'])->assertStatus(422);}
}
