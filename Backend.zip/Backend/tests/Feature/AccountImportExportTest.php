<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Role;
use App\Models\Schedule;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AccountImportExportTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_any_authenticated_user_can_update_their_profile_and_password(): void
    {
        $user = $this->createUser('teacher.profile@school.example', 'teacher');
        Teacher::create(['user_id' => $user->id, 'employee_number' => 'T-001', 'department' => 'IT']);

        $this->actingAs($user, 'sanctum')->putJson('/api/profile', [
            'first_name' => 'Updated',
            'middle_name' => 'Profile',
            'last_name' => 'Teacher',
            'username' => 'updatedteacher',
            'email' => 'updated.teacher@school.example',
            'employee_number' => 'T-002',
            'department' => 'Computer Studies',
            'current_password' => 'SchedSpaceTest!123',
            'password' => 'NewTeacherPassword!123',
            'password_confirmation' => 'NewTeacherPassword!123',
        ])->assertOk()
            ->assertJsonPath('user.name', 'Updated Profile Teacher')
            ->assertJsonPath('user.teacher.employee_number', 'T-002');

        $this->assertTrue(Hash::check('NewTeacherPassword!123', $user->fresh()->password));
        $this->assertDatabaseHas('users', ['id' => $user->id, 'email' => 'updated.teacher@school.example']);
    }

    public function test_profile_password_change_requires_the_current_password(): void
    {
        $user = $this->createUser('teacher.wrong-password@school.example', 'teacher');

        $this->actingAs($user, 'sanctum')->putJson('/api/profile', [
            'password' => 'NewTeacherPassword!123',
            'password_confirmation' => 'NewTeacherPassword!123',
            'current_password' => 'not-the-password',
        ])->assertUnprocessable()
            ->assertJsonPath('message', 'Your current password is incorrect.');

        $this->assertTrue(Hash::check('SchedSpaceTest!123', $user->fresh()->password));
    }

    public function test_super_admin_can_edit_and_delete_other_user_accounts(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $target = $this->createUser('account.target@school.example', 'admin');

        $this->actingAs($root, 'sanctum')->putJson("/api/users/{$target->id}", [
            'first_name' => 'Edited',
            'last_name' => 'Account',
            'username' => 'editedaccount',
            'email' => 'edited.account@school.example',
        ])->assertOk()
            ->assertJsonPath('user.name', 'Edited Account');

        $this->actingAs($root, 'sanctum')->deleteJson("/api/users/{$target->id}")
            ->assertOk()->assertJsonPath('deleted_self', false);

        $this->assertDatabaseMissing('users', ['id' => $target->id]);
    }

    public function test_super_admin_can_update_and_delete_their_own_account_with_password_confirmation(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $this->createUser('backup.root@school.example', 'root-admin');

        $this->actingAs($root, 'sanctum')->putJson("/api/users/{$root->id}", [
            'first_name' => 'Rafael',
            'last_name' => 'Updated',
            'username' => 'rafaelupdated',
            'email' => 'rafael.updated@school.example',
            'password' => 'NewSuperPassword!123',
            'password_confirmation' => 'NewSuperPassword!123',
            'current_password' => 'SchedSpaceDemo!',
        ])->assertOk()->assertJsonPath('user.email', 'rafael.updated@school.example');

        $this->assertTrue(Hash::check('NewSuperPassword!123', $root->fresh()->password));

        $this->actingAs($root, 'sanctum')->deleteJson("/api/users/{$root->id}", [
            'current_password' => 'NewSuperPassword!123',
        ])->assertOk()->assertJsonPath('deleted_self', true);

        $this->assertDatabaseMissing('users', ['id' => $root->id]);
    }

    public function test_the_only_super_admin_cannot_delete_their_own_account(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();

        $this->actingAs($root, 'sanctum')->deleteJson('/api/profile', [
            'current_password' => 'SchedSpaceDemo!',
        ])->assertConflict()
            ->assertJsonPath('message', 'The only Super Admin account cannot be deleted. Assign another Super Admin first.');

        $this->assertDatabaseHas('users', ['id' => $root->id]);
    }

    public function test_student_csv_import_creates_students_and_enrolls_them_in_the_selected_subject(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $subject = Subject::create([
            'subject_code' => 'IT-CSV',
            'subject_name' => 'CSV Import Testing',
            'units' => 3,
        ]);
        $existing = Student::create([
            'student_number' => '2026-0001',
            'first_name' => 'Existing',
            'last_name' => 'Student',
        ]);
        $csv = "\xEF\xBB\xBFstudent_number,first_name,middle_name,last_name,program,year_level,section,status\n"
            . "2026-0001,Existing,Old,Student,BSIT,2,A,Active\n"
            . "2026-0002,Juan,,Dela Cruz,BSIT,2,A,Active\n"
            . "2026-0002,Duplicate,,Student,BSIT,2,A,Active\n";

        $file = UploadedFile::fake()->createWithContent('students.csv', $csv);

        $this->actingAs($root, 'sanctum')->post('/api/student-subjects/import-csv', [
            'file' => $file,
            'subject_id' => $subject->id,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ])->assertCreated()
            ->assertJsonPath('studentsCreated', 1)
            ->assertJsonPath('studentsExisting', 1)
            ->assertJsonPath('enrollmentsCreated', 2)
            ->assertJsonPath('enrollmentsSkipped', 1);

        $this->assertDatabaseCount('students', 2);
        $this->assertDatabaseCount('student_subjects', 2);
        $this->assertDatabaseHas('student_subjects', [
            'student_id' => $existing->id,
            'subject_id' => $subject->id,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ]);
        $this->assertDatabaseHas('students', ['student_number' => '2026-0002', 'first_name' => 'Juan']);
    }

    public function test_invalid_student_csv_is_rejected_without_partial_import_or_enrollment(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $subject = Subject::create([
            'subject_code' => 'IT-CSV-INVALID',
            'subject_name' => 'Invalid CSV Testing',
            'units' => 3,
        ]);
        $csv = "student_number,first_name,middle_name,last_name,program,year_level,section,status\n"
            . "2026-0001,Juan,,Dela Cruz,BSIT,2,A,Active\n"
            . "2026-0002,,,Missing Name,BSIT,2,A,Active\n";
        $file = UploadedFile::fake()->createWithContent('students.csv', $csv);

        $this->actingAs($root, 'sanctum')->post('/api/student-subjects/import-csv', [
            'file' => $file,
            'subject_id' => $subject->id,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ])->assertUnprocessable()
            ->assertJsonPath('message', 'No students were imported because the CSV contains invalid rows.');

        $this->assertDatabaseCount('students', 0);
        $this->assertDatabaseCount('student_subjects', 0);
    }

    public function test_student_csv_import_requires_the_exact_template_headers(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $subject = Subject::create([
            'subject_code' => 'IT-CSV-HEADER',
            'subject_name' => 'CSV Header Testing',
            'units' => 3,
        ]);
        $csv = "student_number,name,last_name\n2026-0001,Juan,Dela Cruz\n";
        $file = UploadedFile::fake()->createWithContent('students.csv', $csv);

        $this->actingAs($root, 'sanctum')->post('/api/student-subjects/import-csv', [
            'file' => $file,
            'subject_id' => $subject->id,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ])->assertUnprocessable()
            ->assertJsonPath('message', 'The CSV headers must exactly match the SchedSpace student template.');

        $this->assertDatabaseCount('students', 0);
        $this->assertDatabaseCount('student_subjects', 0);
    }

    public function test_teacher_cannot_import_student_rosters(): void
    {
        $teacher = $this->createUser('teacher.csv@school.example', 'teacher');
        $subject = Subject::create([
            'subject_code' => 'IT-CSV-SECURE',
            'subject_name' => 'CSV Permission Testing',
            'units' => 3,
        ]);
        $file = UploadedFile::fake()->createWithContent(
            'students.csv',
            "student_number,first_name,middle_name,last_name,program,year_level,section,status\n"
        );

        $this->actingAs($teacher, 'sanctum')->post('/api/student-subjects/import-csv', [
            'file' => $file,
            'subject_id' => $subject->id,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ])->assertForbidden();
    }

    public function test_super_admin_can_export_attendance_schedules_and_teacher_schedules_as_csv(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $teacherUser = $this->createUser('teacher.export@school.example', 'teacher');
        $teacher = Teacher::create([
            'user_id' => $teacherUser->id,
            'employee_number' => 'T-EXPORT-1',
            'department' => 'Information Technology',
        ]);
        $room = Classroom::create(['room_number' => 'E-101', 'building' => 'East', 'floor' => '1st Floor', 'capacity' => 30]);
        $subject = Subject::create(['subject_code' => 'IT-EXPORT', 'subject_name' => 'Export Testing', 'units' => 3]);
        Schedule::create([
            'teacher_id' => $teacher->id, 'classroom_id' => $room->id, 'subject_id' => $subject->id,
            'day_of_week' => 'Monday', 'start_time' => '08:00', 'end_time' => '09:30',
            'school_year' => '2026-2027', 'semester' => '1st Semester', 'section' => '2A',
        ]);
        Attendance::create([
            'teacher_id' => $teacher->id, 'attendance_date' => '2026-11-16',
            'time_in' => '08:02:00', 'time_out' => '09:30:00',
        ]);

        $this->actingAs($root, 'sanctum')->get('/api/exports/attendance.csv?from=2026-11-16&to=2026-11-16')
            ->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
        $this->actingAs($root, 'sanctum')->get('/api/exports/schedules.csv')
            ->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
        $this->actingAs($root, 'sanctum')->get('/api/exports/teacher-schedules.csv')
            ->assertOk()->assertHeader('content-type', 'text/csv; charset=UTF-8');
    }

    public function test_non_super_admin_cannot_export_reports(): void
    {
        $admin = $this->createUser('admin.export@school.example', 'admin');
        $this->actingAs($admin, 'sanctum')->get('/api/exports/schedules.csv')->assertForbidden();
    }

    private function createUser(string $email, string $roleSlug): User
    {
        $role = Role::where('slug', $roleSlug)->firstOrFail();
        $name = $roleSlug === 'teacher' ? 'Teacher' : 'Admin';

        return User::create([
            'name' => $name . ' Tester',
            'first_name' => $name,
            'middle_name' => null,
            'last_name' => 'Tester',
            'username' => str_replace(['@', '.'], '', $email),
            'email' => $email,
            'role_id' => $role->id,
            'password' => 'SchedSpaceTest!123',
        ]);
    }
}
