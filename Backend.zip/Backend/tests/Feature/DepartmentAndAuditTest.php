<?php
namespace Tests\Feature;
use App\Models\Role;
use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;
class DepartmentAndAuditTest extends TestCase
{
 use RefreshDatabase;
 private function super():User{$this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);$r=Role::where('slug','super_admin')->firstOrFail();return User::create(['name'=>'Super Admin','first_name'=>'Super','last_name'=>'Admin','username'=>'superadmin','email'=>'super@example.test','password'=>Hash::make('Password123'),'role_id'=>$r->id,'is_active'=>true,'must_change_password'=>false]);}
 public function test_department_crud_and_audit():void{$u=$this->super();$this->actingAs($u,'sanctum');$created=$this->postJson('/api/departments',['name'=>'Information Technology'])->assertCreated()->json('department');$this->putJson('/api/departments/'.$created['id'],['name'=>'IT'])->assertOk();$this->getJson('/api/audit-logs')->assertOk()->assertJsonCount(2,'data');$this->getJson('/api/audit-logs?action=updated&entity_type=department&search=IT')->assertOk()->assertJsonCount(1,'data')->assertJsonPath('data.0.action','edited');$this->deleteJson('/api/departments/'.$created['id'])->assertOk();}

 public function test_audit_filters_search_and_server_page_size_are_applied():void{$actor=$this->super();$this->actingAs($actor,'sanctum');for($i=1;$i<=25;$i++){AuditLog::create(['actor_id'=>$actor->id,'action'=>$i%2?'updated':'created','entity_type'=>$i%2?'building':'classroom','entity_id'=>$i,'metadata'=>['name'=>'Campus room '.$i]]);} $this->getJson('/api/audit-logs?per_page=100&page=1')->assertOk()->assertJsonCount(20,'data')->assertJsonPath('per_page',20)->assertJsonPath('last_page',2);$this->getJson('/api/audit-logs?per_page=100&page=2')->assertOk()->assertJsonCount(5,'data');$this->getJson('/api/audit-logs?search=Campus%20room%207&action=updated&entity_type=building')->assertOk()->assertJsonCount(1,'data')->assertJsonPath('data.0.entity_id',7);}
}
