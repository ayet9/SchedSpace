<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthAndUserManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_default_seeders_create_only_the_super_admin_account(): void
    {
        $this->assertDatabaseCount('users', 1);
        $this->assertDatabaseCount('classrooms', 0);
        $this->assertDatabaseCount('teachers', 0);
        $this->assertDatabaseCount('students', 0);
        $this->assertDatabaseCount('subjects', 0);
        $this->assertDatabaseCount('schedules', 0);
        $this->assertDatabaseCount('student_subjects', 0);
        $this->assertDatabaseCount('attendances', 0);
        $this->assertDatabaseHas('roles', ['slug' => 'root-admin', 'name' => 'Super Admin']);
        $this->assertDatabaseHas('roles', ['slug' => 'admin', 'name' => 'Admin']);
        $this->assertDatabaseHas('roles', ['slug' => 'teacher', 'name' => 'Teacher']);
    }

    public function test_reseeding_does_not_duplicate_the_super_admin_or_reset_a_changed_password(): void
    {
        $user = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $user->password = 'MyUpdatedPassword!123';
        $user->save();

        $this->seed(\Database\Seeders\SchedSpaceRootAdminSeeder::class);

        $this->assertDatabaseCount('users', 1);
        $this->assertTrue(Hash::check('MyUpdatedPassword!123', $user->fresh()->password));
    }

    public function test_initial_super_admin_can_login_fetch_profile_and_logout(): void
    {
        $login = $this->postJson('/api/login', [
            'email' => 'rafael.cruz@school.example',
            'password' => 'SchedSpaceDemo!',
        ])->assertOk()
            ->assertJsonPath('user.email', 'rafael.cruz@school.example')
            ->assertJsonPath('user.role.slug', 'root-admin')
            ->assertJsonPath('user.role.name', 'Super Admin');

        $token = $login->json('token');
        $this->withToken($token)->getJson('/api/user')
            ->assertOk()
            ->assertJsonPath('role.slug', 'root-admin')
            ->assertJsonPath('role.name', 'Super Admin');

        $this->withToken($token)->postJson('/api/logout')->assertOk();
        $this->assertDatabaseCount('personal_access_tokens', 0);
        Auth::forgetGuards();
        $this->withToken($token)->getJson('/api/user')->assertUnauthorized();
    }

    public function test_public_registration_endpoint_is_removed(): void
    {
        $this->postJson('/api/register', [])->assertNotFound();
    }

    public function test_super_admin_can_list_users_and_assign_or_remove_a_role(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $unassigned = $this->createUser('unassigned.tester@school.example', null);
        $teacherRole = Role::where('slug', 'teacher')->firstOrFail();

        $this->actingAs($root, 'sanctum')->getJson('/api/users')
            ->assertOk()
            ->assertJsonFragment(['email' => 'unassigned.tester@school.example'])
            ->assertJsonFragment(['created_at' => $unassigned->created_at->toJSON()]);

        $this->actingAs($root, 'sanctum')
            ->postJson("/api/users/{$unassigned->id}/role", ['role' => 'teacher'])
            ->assertOk()
            ->assertJsonPath('role.slug', 'teacher');

        $this->assertDatabaseHas('users', [
            'id' => $unassigned->id,
            'role_id' => $teacherRole->id,
        ]);
        $this->assertDatabaseHas('teachers', [
            'user_id' => $unassigned->id,
            'employment_status' => 'Active',
        ]);

        $this->actingAs($root, 'sanctum')
            ->putJson("/api/users/{$unassigned->id}/role", ['role' => null])
            ->assertOk()
            ->assertJsonPath('role', null);
    }


    public function test_assigned_super_admin_role_is_included_and_persists_after_a_new_login(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $target = $this->createUser('new.superadmin@school.example', null);
        $rootRole = Role::where('slug', 'root-admin')->firstOrFail();

        $this->actingAs($root, 'sanctum')
            ->putJson("/api/users/{$target->id}/role", ['role' => 'super-admin'])
            ->assertOk()
            ->assertJsonPath('role.slug', 'root-admin')
            ->assertJsonPath('role.name', 'Super Admin');

        $this->assertDatabaseHas('users', [
            'id' => $target->id,
            'role_id' => $rootRole->id,
        ]);

        $login = $this->postJson('/api/login', [
            'email' => 'new.superadmin@school.example',
            'password' => 'SchedSpaceTest!123',
        ])->assertOk()
            ->assertJsonPath('user.role.slug', 'root-admin')
            ->assertJsonPath('user.role.name', 'Super Admin');

        $this->withToken($login->json('token'))->getJson('/api/user')
            ->assertOk()
            ->assertJsonPath('role.slug', 'root-admin')
            ->assertJsonPath('role.name', 'Super Admin');
    }

    public function test_last_super_admin_cannot_be_unassigned_or_demoted(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();

        $this->actingAs($root, 'sanctum')
            ->putJson("/api/users/{$root->id}/role", ['role' => null])
            ->assertStatus(409);

        $this->assertDatabaseHas('users', [
            'id' => $root->id,
            'role_id' => $root->role_id,
        ]);
    }

    public function test_non_root_roles_cannot_manage_users(): void
    {
        $admin = $this->createUser('admin.tester@school.example', 'admin');
        $target = $this->createUser('target.tester@school.example', null);

        $this->actingAs($admin, 'sanctum')->getJson('/api/users')->assertForbidden();
        $this->actingAs($admin, 'sanctum')
            ->putJson("/api/users/{$target->id}/role", ['role' => 'admin'])
            ->assertForbidden();
    }

    private function createUser(string $email, ?string $roleSlug): User
    {
        $role = $roleSlug ? Role::where('slug', $roleSlug)->firstOrFail() : null;
        $name = $roleSlug === 'admin' ? 'Admin Tester' : 'Unassigned Tester';

        return User::create([
            'name' => $name,
            'first_name' => $roleSlug === 'admin' ? 'Admin' : 'Unassigned',
            'middle_name' => null,
            'last_name' => 'Tester',
            'username' => $roleSlug === 'admin' ? 'admintest' : 'unassigned',
            'email' => $email,
            'role_id' => $role?->id,
            'password' => 'SchedSpaceTest!123',
        ]);
    }
}
