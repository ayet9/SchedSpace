<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Database\Seeders\SchedSpaceRolesAndPermissionsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class CampusMapControllerTest extends TestCase
{
    use RefreshDatabase;

    private function superAdmin(): User
    {
        $this->seed(SchedSpaceRolesAndPermissionsSeeder::class);
        $role = Role::where('slug', 'super_admin')->firstOrFail();

        return User::create([
            'name' => 'Super Admin',
            'first_name' => 'Super',
            'last_name' => 'Admin',
            'username' => 'superadmin',
            'email' => 'super@example.test',
            'password' => Hash::make('Password123'),
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => false,
        ]);
    }

    public function test_super_admin_can_save_campus_walkways_for_all_users(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');
        $walkways = [[['x' => 12.25, 'y' => 40], ['x' => 40, 'y' => 42]]];

        $this->getJson('/api/campus-map')->assertOk()->assertExactJson(['walkways' => []]);
        $this->putJson('/api/campus-map', ['walkways' => $walkways])
            ->assertOk()
            ->assertJsonPath('walkways.0.0.x', 12.25)
            ->assertJsonPath('walkways.0.1.y', 42);

        $stored = DB::table('campus_map_settings')->where('map_key', 'main')->value('walkways');
        $this->assertSame($walkways, json_decode($stored, true));
        $this->getJson('/api/campus-map')->assertOk()->assertJsonPath('walkways.0.1.x', 40);
    }

    public function test_campus_walkway_points_outside_the_map_are_rejected_without_saving(): void
    {
        $this->actingAs($this->superAdmin(), 'sanctum');

        $this->putJson('/api/campus-map', ['walkways' => [[
            ['x' => 101, 'y' => 20], ['x' => 40, 'y' => 42],
        ]]])
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['walkways.0.0.x']);

        $stored = DB::table('campus_map_settings')->where('map_key', 'main')->value('walkways');
        $this->assertSame([], json_decode($stored, true));
    }

    public function test_unauthenticated_user_cannot_read_the_campus_map(): void
    {
        $this->getJson('/api/campus-map')->assertUnauthorized();
    }

    public function test_teacher_cannot_change_campus_walkways(): void
    {
        $this->seed(SchedSpaceRolesAndPermissionsSeeder::class);
        $role = Role::where('slug', 'teacher')->firstOrFail();
        $teacher = User::create([
            'name' => 'Teacher User',
            'first_name' => 'Teacher',
            'last_name' => 'User',
            'username' => 'teacheruser',
            'email' => 'teacher@example.test',
            'password' => Hash::make('Password123'),
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => false,
        ]);
        $this->actingAs($teacher, 'sanctum');

        $this->putJson('/api/campus-map', ['walkways' => []])->assertForbidden();

        $stored = DB::table('campus_map_settings')->where('map_key', 'main')->value('walkways');
        $this->assertSame([], json_decode($stored, true));
    }
}
