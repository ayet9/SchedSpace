<?php

namespace Tests\Feature;

use App\Models\Role;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class ExcelImportExportTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_registration_endpoint_is_removed(): void
    {
        $this->postJson('/api/register', [])->assertNotFound();
    }

    public function test_login_rejects_inactive_accounts(): void
    {
        $role = Role::create(['name' => 'Teacher', 'slug' => 'teacher']);
        $user = User::create([
            'name' => 'Inactive Teacher', 'first_name' => 'Inactive', 'last_name' => 'Teacher',
            'username' => 'inactive-teacher', 'email' => 'inactive@example.test', 'password' => Hash::make('password123'),
            'role_id' => $role->id, 'is_active' => false,
        ]);

        $this->postJson('/api/login', ['email' => $user->email, 'password' => 'password123'])
            ->assertUnauthorized();
    }

    public function test_excel_upload_rejects_non_excel_files(): void
    {
        $role = Role::create(['name' => 'Super Admin', 'slug' => 'super_admin']);
        $user = User::create([
            'name' => 'Super Admin', 'first_name' => 'Super', 'last_name' => 'Admin',
            'username' => 'super-admin', 'email' => 'super@example.test', 'password' => Hash::make('password123'),
            'role_id' => $role->id, 'is_active' => true,
        ]);

        $file = UploadedFile::fake()->create('students.txt', 10, 'text/plain');
        $this->actingAs($user, 'sanctum')->post('/api/student-subjects/import-excel', ['file' => $file])
            ->assertUnprocessable();
    }
}
