<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Role;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RolePermissionApiTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_permission_matrix_route_is_registered_and_root_access_is_locked(): void
    {
        $root = User::where('email', 'rafael.cruz@school.example')->firstOrFail();
        $matrix = $this->actingAs($root, 'sanctum')->getJson('/api/permissions/matrix')
            ->assertOk()
            ->json();

        $this->assertTrue($matrix['subjects']['root-admin']);
        $this->assertTrue($matrix['subjects']['admin']);
        $this->assertTrue($matrix['subjects']['teacher']);

        $matrix['student-subjects']['teacher'] = false;
        $this->actingAs($root, 'sanctum')->putJson('/api/permissions/matrix', ['matrix' => $matrix])
            ->assertOk()
            ->assertJsonPath('student-subjects.teacher', false);

        $matrix['users']['root-admin'] = false;
        $this->actingAs($root, 'sanctum')->putJson('/api/permissions/matrix', ['matrix' => $matrix])
            ->assertUnprocessable();

        $this->actingAs($root, 'sanctum')->getJson('/api/roles')->assertOk();
    }

    public function test_admin_cannot_change_role_permissions(): void
    {
        $adminRole = Role::where('slug', 'admin')->firstOrFail();
        $admin = User::create([
            'name' => 'Admin Tester', 'first_name' => 'Admin', 'middle_name' => null,
            'last_name' => 'Tester', 'username' => 'admintest', 'email' => 'admin.tester@school.example',
            'role_id' => $adminRole->id, 'password' => 'SchedSpaceTest!123',
        ]);

        $this->actingAs($admin, 'sanctum')->getJson('/api/permissions/matrix')->assertForbidden();
        $this->actingAs($admin, 'sanctum')->getJson('/api/roles')->assertForbidden();
    }
}
