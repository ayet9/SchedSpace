<?php

namespace Tests\Feature;

use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Role;
use App\Models\Schedule;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Tests\TestCase;

class AcademicApiTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_admin_and_teacher_can_access_only_their_allowed_academic_routes(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.tester@school.example');
        $admin = $this->createUser('admin.tester@school.example', 'admin');

        $this->actingAs($teacherUser, 'sanctum')->getJson('/api/teachers')->assertOk();
        $this->actingAs($teacherUser, 'sanctum')->getJson('/api/schedules/my-schedule')->assertOk();
        $this->actingAs($teacherUser, 'sanctum')->getJson('/api/schedules/other-teachers')->assertOk();
        $this->actingAs($teacherUser, 'sanctum')->getJson('/api/student-subjects/my-students')->assertOk();
        $this->actingAs($teacherUser, 'sanctum')->getJson('/api/schedules')->assertForbidden();

        $this->actingAs($admin, 'sanctum')->getJson('/api/classrooms')->assertOk();
        $this->actingAs($admin, 'sanctum')->getJson('/api/schedules')->assertOk();
        $this->actingAs($admin, 'sanctum')->getJson('/api/attendance')->assertOk();
        $this->assertDatabaseHas('teachers', ['id' => $teacher->id, 'user_id' => $teacherUser->id]);
    }

    public function test_teacher_can_view_other_teacher_schedules_and_classrooms_without_manage_access(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.viewer@school.example');
        [, $otherTeacher] = $this->createTeacherUser('teacher.other@school.example', 'teacherother');
        $this->createSchedule($teacher, 'Monday', '08:00', '09:30', 'A-101');
        $otherSchedule = $this->createSchedule($otherTeacher, 'Tuesday', '10:00', '11:00', 'B-102');

        $response = $this->actingAs($teacherUser, 'sanctum')
            ->getJson('/api/schedules/other-teachers')
            ->assertOk();

        $this->assertTrue(collect($response->json('data'))->contains(
            fn (array $schedule): bool => $schedule['teacher_id'] === $otherTeacher->id
                && $schedule['classroom_id'] === $otherSchedule->classroom_id
        ));

        $this->actingAs($teacherUser, 'sanctum')
            ->postJson('/api/schedules', [])
            ->assertForbidden();
    }

    public function test_admin_schedule_creation_rejects_room_and_teacher_conflicts(): void
    {
        $admin = $this->createUser('admin.tester@school.example', 'admin');
        [, $teacher] = $this->createTeacherUser('teacher.tester@school.example');
        $room = Classroom::create(['room_number' => 'A-101', 'building' => 'Main', 'floor' => '1st', 'capacity' => 30]);
        $subjectA = Subject::create(['subject_code' => 'IT 101', 'subject_name' => 'Computing', 'units' => 3]);
        $subjectB = Subject::create(['subject_code' => 'IT 102', 'subject_name' => 'Programming', 'units' => 3]);
        $existing = Schedule::create([
            'teacher_id' => $teacher->id,
            'classroom_id' => $room->id,
            'subject_id' => $subjectA->id,
            'day_of_week' => 'Monday',
            'start_time' => '08:00',
            'end_time' => '09:30',
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ]);

        $this->actingAs($admin, 'sanctum')->postJson('/api/schedules', [
            'teacher_id' => $existing->teacher_id,
            'classroom_id' => $existing->classroom_id,
            'subject_id' => $subjectB->id,
            'day_of_week' => $existing->day_of_week,
            'start_time' => '08:30',
            'end_time' => '10:00',
            'school_year' => $existing->school_year,
            'semester' => $existing->semester,
        ])->assertConflict();
    }

    public function test_schedule_date_sets_day_of_week_when_creating_a_dated_schedule(): void
    {
        $admin = $this->createUser('admin.dated-schedule@school.example', 'admin');
        [, $teacher] = $this->createTeacherUser('teacher.dated-schedule@school.example');
        $room = Classroom::create(['room_number' => 'D-101', 'building' => 'Main', 'floor' => '1st', 'capacity' => 30]);
        $subject = Subject::create(['subject_code' => 'IT 201', 'subject_name' => 'Web Systems', 'units' => 3]);
        $date = Carbon::now(config('app.timezone'))->addDay();
        $currentYear = Carbon::now(config('app.timezone'))->year;

        $this->actingAs($admin, 'sanctum')
            ->postJson('/api/schedules', [
                'schedule_date' => $date->toDateString(),
                'start_time' => '12:00',
                'end_time' => '13:00',
                'teacher_id' => $teacher->id,
                'subject_id' => $subject->id,
                'classroom_id' => $room->id,
            ])
            ->assertUnprocessable();

        $this->actingAs($admin, 'sanctum')
            ->postJson('/api/schedules', [
                'schedule_date' => $date->toDateString(),
                'start_time' => '10:00',
                'end_time' => '11:00',
                'teacher_id' => $teacher->id,
                'subject_id' => $subject->id,
                'classroom_id' => $room->id,
            ])
            ->assertCreated()
            ->assertJsonPath('schedule.day_of_week', $date->englishDayOfWeek)
            ->assertJsonPath('schedule.school_year', $currentYear . '-' . ($currentYear + 1));
    }

    public function test_teacher_can_time_in_only_during_an_active_scheduled_class_and_time_out_afterward(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.tester@school.example');
        $this->createSchedule($teacher, 'Monday', '08:00', '09:30');
        Carbon::setTestNow(Carbon::parse('2026-11-16 08:20:00', 'Asia/Manila'));

        try {
            $this->actingAs($teacherUser, 'sanctum')
                ->getJson('/api/attendance/my-status')
                ->assertOk()
                ->assertJsonPath('has_class_today', true)
                ->assertJsonPath('can_time_in', true)
                ->assertJsonPath('can_time_out', false);

            $this->actingAs($teacherUser, 'sanctum')
                ->postJson('/api/attendance/time-in', ['time' => '01:00'])
                ->assertCreated()
                ->assertJsonPath('attendance.time_in', '08:20:00');

            $this->actingAs($teacherUser, 'sanctum')
                ->postJson('/api/attendance/time-in')
                ->assertConflict();

            Carbon::setTestNow(Carbon::parse('2026-11-16 09:20:00', 'Asia/Manila'));
            $this->actingAs($teacherUser, 'sanctum')
                ->postJson('/api/attendance/time-out', ['time' => '00:01'])
                ->assertOk()
                ->assertJsonPath('attendance.time_out', '09:20:00');
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_teacher_can_time_in_again_for_a_second_scheduled_class(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.second-class@school.example');
        $this->createSchedule($teacher, 'Monday', '10:00', '10:30');
        $this->createSchedule($teacher, 'Monday', '11:00', '11:30');

        try {
            Carbon::setTestNow(Carbon::parse('2026-11-16 10:10:00', 'Asia/Manila'));
            $this->actingAs($teacherUser, 'sanctum')->postJson('/api/attendance/time-in')->assertCreated();
            Carbon::setTestNow(Carbon::parse('2026-11-16 10:30:00', 'Asia/Manila'));
            $this->actingAs($teacherUser, 'sanctum')->postJson('/api/attendance/time-out')->assertOk();

            Carbon::setTestNow(Carbon::parse('2026-11-16 11:10:00', 'Asia/Manila'));
            $this->actingAs($teacherUser, 'sanctum')
                ->getJson('/api/attendance/my-status')
                ->assertOk()
                ->assertJsonPath('can_time_in', true);
            $this->actingAs($teacherUser, 'sanctum')->postJson('/api/attendance/time-in')->assertCreated();
            $this->assertDatabaseHas('attendances', [
                'teacher_id' => $teacher->id,
                'time_in' => '11:10:00',
                'time_out' => null,
                'status' => 'open',
            ]);
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_teacher_cannot_time_in_when_no_class_is_active_and_cannot_time_out_without_time_in(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.no-class@school.example');
        $this->createSchedule($teacher, 'Monday', '08:00', '09:30');
        Carbon::setTestNow(Carbon::parse('2026-11-16 07:45:00', 'Asia/Manila'));

        try {
            $this->actingAs($teacherUser, 'sanctum')
                ->postJson('/api/attendance/time-in')
                ->assertUnprocessable()
                ->assertJsonPath('message', 'Time-in is only allowed while one of your scheduled classes is currently in progress.');

            $this->actingAs($teacherUser, 'sanctum')
                ->postJson('/api/attendance/time-out')
                ->assertNotFound();
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_open_attendance_is_automatically_timed_out_at_the_last_class_end(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.auto-out@school.example');
        $this->createSchedule($teacher, 'Monday', '08:00', '09:30');
        $this->createSchedule($teacher, 'Monday', '15:00', '16:30', 'B-102');
        Carbon::setTestNow(Carbon::parse('2026-11-16 08:15:00', 'Asia/Manila'));

        try {
            $this->actingAs($teacherUser, 'sanctum')->postJson('/api/attendance/time-in')->assertCreated();

            Carbon::setTestNow(Carbon::parse('2026-11-16 16:45:00', 'Asia/Manila'));
            $this->actingAs($teacherUser, 'sanctum')
                ->getJson('/api/attendance/my-status')
                ->assertOk()
                ->assertJsonPath('can_time_out', false)
                ->assertJsonPath('attendance.time_out', '16:30:00');

            $this->assertDatabaseHas('attendances', [
                'teacher_id' => $teacher->id,
                'time_out' => '16:30:00',
            ]);
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_auto_time_out_reconciles_an_open_record_after_midnight_scheduler_downtime(): void
    {
        [$teacherUser, $teacher] = $this->createTeacherUser('teacher.past-due@school.example');
        $this->createSchedule($teacher, 'Monday', '08:00', '09:30');
        $attendance = Attendance::create([
            'teacher_id' => $teacher->id,
            'attendance_date' => '2026-11-16',
            'time_in' => '08:10:00',
        ]);
        Carbon::setTestNow(Carbon::parse('2026-11-17 07:00:00', 'Asia/Manila'));

        try {
            $this->actingAs($teacherUser, 'sanctum')->getJson('/api/attendance/my-status')->assertOk();
            $this->assertDatabaseHas('attendances', [
                'id' => $attendance->id,
                'time_out' => '09:30:00',
            ]);
        } finally {
            Carbon::setTestNow();
        }
    }

    public function test_super_admin_can_create_subjects_and_classroom_layouts(): void
    {
        $superAdmin = User::where('email', 'rafael.cruz@school.example')->firstOrFail();

        $this->actingAs($superAdmin, 'sanctum')->postJson('/api/subjects', [
            'subject_code' => 'IT 201',
            'subject_name' => 'Web Systems',
            'description' => 'Web application development.',
            'units' => 3,
        ])->assertCreated()->assertJsonPath('subject.subject_code', 'IT 201');

        $this->actingAs($superAdmin, 'sanctum')->postJson('/api/classrooms', [
            'room_number' => 'A-201',
            'building' => 'Main Building',
            'floor' => '2nd Floor',
            'capacity' => 35,
            'features' => ['Projector'],
            'plan' => ['col' => 1, 'row' => 5, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'top'],
        ])->assertCreated()->assertJsonPath('classroom.room_number', 'A-201');

        $this->actingAs($superAdmin, 'sanctum')->postJson('/api/classrooms', [
            'room_number' => 'A-202',
            'building' => 'Main Building',
            'floor' => '2nd Floor',
            'capacity' => 25,
            'plan' => ['col' => 1, 'row' => 5, 'colSpan' => 3, 'rowSpan' => 1, 'door' => 'top'],
        ])->assertUnprocessable()
            ->assertJsonPath('message', 'That floor-plan position is already occupied in this building and floor.');
    }

    public function test_admin_and_teacher_routes_reject_the_wrong_role(): void
    {
        $admin = $this->createUser('admin.tester@school.example', 'admin');
        [$teacherUser] = $this->createTeacherUser('teacher.tester@school.example');

        $this->actingAs($admin, 'sanctum')->postJson('/api/attendance/time-in')->assertForbidden();
        $this->actingAs($teacherUser, 'sanctum')->postJson('/api/classrooms', [
            'room_number' => '99',
            'capacity' => 20,
        ])->assertForbidden();
    }

    private function createUser(string $email, string $roleSlug, ?string $username = null): User
    {
        $role = Role::where('slug', $roleSlug)->firstOrFail();
        $first = $roleSlug === 'admin' ? 'Admin' : 'Teacher';

        return User::create([
            'name' => $first.' Tester',
            'first_name' => $first,
            'middle_name' => null,
            'last_name' => 'Tester',
            'username' => $username ?? strtolower($first).'test',
            'email' => $email,
            'role_id' => $role->id,
            'password' => 'SchedSpaceTest!123',
        ]);
    }

    private function createSchedule(Teacher $teacher, string $day, string $start, string $end, string $roomNumber = 'A-101'): Schedule
    {
        $room = Classroom::firstOrCreate(
            ['room_number' => $roomNumber],
            ['building' => 'Main', 'floor' => '1st', 'capacity' => 30],
        );
        $subject = Subject::firstOrCreate(
            ['subject_code' => 'IT 101'],
            ['subject_name' => 'Computing', 'units' => 3],
        );

        return Schedule::create([
            'teacher_id' => $teacher->id,
            'classroom_id' => $room->id,
            'subject_id' => $subject->id,
            'day_of_week' => $day,
            'start_time' => $start,
            'end_time' => $end,
            'school_year' => '2026-2027',
            'semester' => '1st Semester',
        ]);
    }

    /** @return array{User, Teacher} */
    private function createTeacherUser(string $email, ?string $username = null): array
    {
        $user = $this->createUser($email, 'teacher', $username);
        $teacher = Teacher::create([
            'user_id' => $user->id,
            'employee_number' => 'T-TEST-001',
            'department' => 'Information Technology',
            'employment_status' => 'Active',
        ]);

        return [$user, $teacher];
    }
}
