<?php

namespace Tests\Feature;

use App\Models\Department;
use App\Models\Role;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AdminDeletionAndDepartmentTest extends TestCase
{
    use RefreshDatabase;

    private function superAdmin(): User
    {
        $role = Role::where('slug', 'super_admin')->firstOrFail();
        return User::create(['name' => 'Test Super Admin', 'first_name' => 'Test', 'last_name' => 'Admin', 'username' => 'test-super-admin', 'email' => 'test-super-admin@example.com', 'password' => Hash::make('password'), 'role_id' => $role->id, 'is_active' => true]);
    }

    public function test_super_admin_can_create_edit_and_delete_an_unused_department(): void
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $admin = $this->superAdmin();
        $this->actingAs($admin, 'sanctum');

        $created = $this->postJson('/api/departments', ['name' => 'Computer Studies'])
            ->assertCreated()->json('department');

        $this->putJson('/api/departments/'.$created['id'], ['name' => 'Information Technology'])
            ->assertOk();

        $this->deleteJson('/api/departments/'.$created['id'])->assertOk();
        $this->assertDatabaseMissing('departments', ['id' => $created['id']]);
    }

    public function test_department_delete_is_blocked_while_a_teacher_is_assigned(): void
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $admin = $this->superAdmin();
        $department = Department::create(['name' => 'Science']);
        $teacherUser = User::create(['name' => 'Test Teacher', 'first_name' => 'Test', 'last_name' => 'Teacher', 'username' => 'teacher-'.uniqid(), 'email' => uniqid('teacher-').'@example.com', 'password' => Hash::make('password')]);
        Teacher::create(['user_id' => $teacherUser->id, 'department_id' => $department->id, 'department' => $department->name]);

        $this->actingAs($admin, 'sanctum')
            ->deleteJson('/api/departments/'.$department->id)
            ->assertStatus(409);
    }

    public function test_teacher_delete_is_blocked_when_history_exists(): void
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $admin = $this->superAdmin();
        $teacherUser = User::create(['name' => 'Test Teacher', 'first_name' => 'Test', 'last_name' => 'Teacher', 'username' => 'teacher-'.uniqid(), 'email' => uniqid('teacher-').'@example.com', 'password' => Hash::make('password')]);
        $teacher = Teacher::create(['user_id' => $teacherUser->id]);
        $teacher->attendances()->create(['attendance_date' => now()->toDateString()]);

        $this->actingAs($admin, 'sanctum')
            ->deleteJson('/api/teachers/'.$teacher->id)
            ->assertStatus(409);
    }

    public function test_unused_teacher_can_be_deleted(): void
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $admin = $this->superAdmin();
        $teacherUser = User::create(['name' => 'Test Teacher', 'first_name' => 'Test', 'last_name' => 'Teacher', 'username' => 'teacher-'.uniqid(), 'email' => uniqid('teacher-').'@example.com', 'password' => Hash::make('password')]);
        $teacher = Teacher::create(['user_id' => $teacherUser->id]);

        $this->actingAs($admin, 'sanctum')
            ->deleteJson('/api/teachers/'.$teacher->id)
            ->assertOk();

        $this->assertDatabaseMissing('teachers', ['id' => $teacher->id]);
        $this->assertDatabaseMissing('users', ['id' => $teacherUser->id]);
    }

    public function test_subject_delete_is_blocked_when_a_teacher_assignment_exists(): void
    {
        $this->seed(\Database\Seeders\SchedSpaceRolesAndPermissionsSeeder::class);
        $admin = $this->superAdmin();
        $subject = Subject::create(['subject_code' => 'TEST101', 'subject_name' => 'Test Subject']);
        $teacherUser = User::create(['name' => 'Test Teacher', 'first_name' => 'Test', 'last_name' => 'Teacher', 'username' => 'teacher-'.uniqid(), 'email' => uniqid('teacher-').'@example.com', 'password' => Hash::make('password')]);
        $teacher = Teacher::create(['user_id' => $teacherUser->id]);
        $teacher->subjects()->attach($subject->id);

        $this->actingAs($admin, 'sanctum')
            ->deleteJson('/api/subjects/'.$subject->id)
            ->assertStatus(409);
    }
}
