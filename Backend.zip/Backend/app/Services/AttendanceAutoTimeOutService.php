<?php

namespace App\Services;

use App\Models\Attendance;
use Illuminate\Support\Carbon;

/**
 * Closes an open attendance record at the end of the teacher's last scheduled
 * class for its attendance date. The scheduler runs this once per minute, while
 * attendance endpoints also invoke it. Older open records are reconciled too,
 * so a short scheduler outage across midnight does not leave them open forever.
 */
class AttendanceAutoTimeOutService
{
    public function run(?Carbon $at = null): int
    {
        $at ??= now();
        $today = $at->toDateString();
        $currentTime = $at->format('H:i:s');
        $closed = 0;

        $records = Attendance::with('teacher.schedules')
            ->whereDate('attendance_date', '<=', $today)
            ->whereNotNull('time_in')
            ->whereNull('time_out')
            ->get();

        foreach ($records as $record) {
            $recordDate = Carbon::parse($record->attendance_date);
            $recordDay = $recordDate->englishDayOfWeek;
            $lastClassEnd = $record->teacher?->schedules
                ->where('day_of_week', $recordDay)
                ->max('end_time');

            if (!$lastClassEnd) {
                continue;
            }

            $isPastAttendanceDate = $recordDate->toDateString() < $today;
            if (!$isPastAttendanceDate && $currentTime < (string) $lastClassEnd) {
                continue;
            }

            $record->update([
                // Record the scheduled end, not the later time the scheduler ran.
                'time_out' => substr((string) $lastClassEnd, 0, 8),
            ]);

            $closed++;
        }

        return $closed;
    }
}
