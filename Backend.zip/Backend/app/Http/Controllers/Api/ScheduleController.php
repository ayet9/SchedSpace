<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Schedule;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Services\AuditLogger;

class ScheduleController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Schedule::with(['teacher.user', 'classroom', 'subject'])->orderByDesc('schedule_date')->orderBy('start_time');
        $search = trim((string) $request->query('search', ''));
        foreach (['teacher_id', 'subject_id', 'classroom_id'] as $filter) if ($request->filled($filter)) $query->where($filter, $request->query($filter));
        if ($request->filled('date')) $query->whereDate('schedule_date', $request->query('date'));
        if ($search !== '') {
            $like = '%' . addcslashes($search, '%_') . '%';
            $query->where(function ($q) use ($like) {
                $q->whereHas('subject', fn ($sq) => $sq->where('subject_name', 'like', $like)->orWhere('subject_code', 'like', $like))
                    ->orWhereHas('classroom', fn ($rq) => $rq->where('room_number', 'like', $like))
                    ->orWhereHas('teacher.user', fn ($tq) => $tq->where('name', 'like', $like));
            });
        }
        return response()->json($query->paginate(min(max($request->integer('per_page', 20), 1), 100)));
    }

    public function mySchedule(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacher;
        if (!$teacher) return response()->json(['message' => 'Your account is not linked to a teacher record.'], 403);
        return response()->json(Schedule::with(['classroom', 'subject'])->where('teacher_id', $teacher->id)->orderBy('schedule_date')->orderBy('start_time')->paginate(50));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validateSchedule($request);
        $validated['school_year'] ??= $this->currentSchoolYear();
        if (!empty($validated['schedule_date'])) $this->ensureDateAllowed($validated['schedule_date']);

        if (DB::getDriverName() === 'mysql') DB::statement('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
        $schedule = DB::transaction(function () use ($validated) {
            $this->lockRelevantSchedules($validated);
            $conflict = $this->findConflict($validated);
            if ($conflict) abort(409, $conflict);
            return Schedule::create($validated);
        });

        AuditLogger::record($request->user(),'created','schedule',$schedule->id,['schedule_date'=>$schedule->schedule_date]);
        return response()->json(['message' => 'Schedule created successfully.', 'schedule' => $schedule->load(['teacher.user', 'classroom', 'subject'])], 201);
    }

    public function show(Schedule $schedule): JsonResponse
    {
        return response()->json($schedule->load(['teacher.user', 'classroom', 'subject']));
    }

    public function update(Request $request, Schedule $schedule): JsonResponse
    {
        if ($schedule->schedule_date && CarbonImmutable::parse($schedule->schedule_date)->lt(today())) {
            return response()->json(['message' => 'Past schedules are read-only history and cannot be edited.'], 409);
        }
        $validated = $this->validateSchedule($request);
        $validated['school_year'] ??= $schedule->school_year ?: $this->currentSchoolYear();
        if (!empty($validated['schedule_date'])) $this->ensureDateAllowed($validated['schedule_date']);

        if (DB::getDriverName() === 'mysql') DB::statement('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE');
        $updated = DB::transaction(function () use ($schedule, $validated) {
            $this->lockRelevantSchedules($validated);
            $conflict = $this->findConflict($validated, $schedule->id);
            if ($conflict) abort(409, $conflict);
            $schedule->update($validated);
            return $schedule->fresh()->load(['teacher.user', 'classroom', 'subject']);
        });

        AuditLogger::record($request->user(),'edited','schedule',$updated->id,['schedule_date'=>$updated->schedule_date]);
        return response()->json(['message' => 'Schedule updated successfully.', 'schedule' => $updated]);
    }

    public function destroy(Schedule $schedule): JsonResponse
    {
        if ($schedule->schedule_date && CarbonImmutable::parse($schedule->schedule_date)->lt(today())) {
            return response()->json(['message' => 'Past schedules are read-only history and cannot be deleted.'], 409);
        }
        $id=$schedule->id; $schedule->delete(); AuditLogger::record($request->user(),'deleted','schedule',$id);
        return response()->json(['message' => 'Schedule deleted successfully.']);
    }

    public function dates(): JsonResponse
    {
        return response()->json(['dates' => Schedule::whereNotNull('schedule_date')->distinct()->orderBy('schedule_date')->pluck('schedule_date')->map(fn ($d) => CarbonImmutable::parse($d)->toDateString())->values()]);
    }

    private function validateSchedule(Request $request): array
    {
        $validated = $request->validate([
            'schedule_date' => ['nullable', 'date_format:Y-m-d'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i', 'after:start_time'],
            'teacher_id' => ['required', 'exists:teachers,id'],
            'subject_id' => ['required', 'exists:subjects,id'],
            'classroom_id' => ['required', 'exists:classrooms,id'],
            'section' => ['nullable', 'string', 'max:255'],
            'day_of_week' => ['required_without:schedule_date', 'nullable', Rule::in(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'])],
            'school_year' => ['nullable', 'string', 'max:255'],
            'semester' => ['nullable', 'string', 'max:255'],
        ]);

        $timeWindows = [['08:00', '12:00'], ['13:00', '17:00'], ['17:30', '21:30']];
        $fitsTimeWindow = false;
        foreach ($timeWindows as [$windowStart, $windowEnd]) {
            if ($validated['start_time'] >= $windowStart && $validated['end_time'] <= $windowEnd) {
                $fitsTimeWindow = true;
                break;
            }
        }
        if (!$fitsTimeWindow) {
            abort(422, 'Choose a start and end time within one of the available daily windows.');
        }

        if (!empty($validated['schedule_date'])) {
            $validated['day_of_week'] = CarbonImmutable::parse($validated['schedule_date'])->englishDayOfWeek;
        }

        if (empty($validated['schedule_date']) && empty($validated['day_of_week'])) {
            abort(422, 'Choose a schedule date or day of the week.');
        }

        return $validated;
    }

    private function ensureDateAllowed(string $date): void
    {
        $value = CarbonImmutable::createFromFormat('Y-m-d', $date, config('app.timezone'))->startOfDay();
        $today = CarbonImmutable::now(config('app.timezone'))->startOfDay();
        $max = $today->addYear();
        if ($value->lt($today) || $value->gt($max)) abort(422, 'Choose a schedule date from today through one year from today.');
    }

    private function currentSchoolYear(): string
    {
        $year = CarbonImmutable::now(config('app.timezone'))->year;
        return $year . '-' . ($year + 1);
    }

    private function lockRelevantSchedules(array $data): void
    {
        $query = Schedule::query();
        if (!empty($data['schedule_date'])) {
            $query->whereDate('schedule_date', $data['schedule_date']);
        } else {
            $query->whereNull('schedule_date')->where('day_of_week', $data['day_of_week']);
        }

        $query
            ->where(function ($q) use ($data) {
                $q->where('teacher_id', $data['teacher_id'])->orWhere('classroom_id', $data['classroom_id']);
            })->lockForUpdate()->get();
    }

    private function findConflict(array $data, ?int $ignoreId = null): ?string
    {
        $query = Schedule::with(['teacher.user', 'subject', 'classroom'])
            ->where('start_time', '<', $data['end_time'])
            ->where('end_time', '>', $data['start_time'])
            ->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId));

        if (!empty($data['schedule_date'])) {
            $query->whereDate('schedule_date', $data['schedule_date']);
        } else {
            $query->whereNull('schedule_date')->where('day_of_week', $data['day_of_week']);
        }

        $room = (clone $query)->where('classroom_id', $data['classroom_id'])->first();
        if ($room) return sprintf('%s is already booked %s-%s by %s (%s).', $room->classroom?->room_number ?? 'This room', substr($room->start_time, 0, 5), substr($room->end_time, 0, 5), $room->teacher?->user?->name ?? 'another teacher', $room->subject?->subject_name ?? 'another subject');

        $teacher = (clone $query)->where('teacher_id', $data['teacher_id'])->first();
        if ($teacher) return sprintf('%s is already scheduled %s-%s for %s.', $teacher->teacher?->user?->name ?? 'This teacher', substr($teacher->start_time, 0, 5), substr($teacher->end_time, 0, 5), $teacher->subject?->subject_name ?? 'another subject');
        return null;
    }
}
