<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
class AuditLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query=AuditLog::with('actor:id,name,email')->latest();
        if ($request->filled('action')) {
            $action = $request->query('action');
            if (in_array($action, ['edited', 'updated'], true)) {
                $query->whereIn('action', ['edited', 'updated']);
            } else {
                $query->where('action', $action);
            }
        }
        if($request->filled('entity_type')) $query->where('entity_type',$request->query('entity_type'));
        if ($request->filled('search')) {
            $search = trim((string) $request->query('search'));
            $like = '%' . addcslashes($search, '%_') . '%';
            $query->where(function ($q) use ($like, $search) {
                $q->where('entity_type', 'like', $like)
                    ->orWhere('action', 'like', $like)
                    ->orWhere('metadata', 'like', $like)
                    ->orWhere('entity_id', $search)
                    ->orWhereHas('actor', fn ($actor) => $actor
                        ->where('name', 'like', $like)
                        ->orWhere('email', 'like', $like));
            });
        }
        return response()->json($query->paginate(min(max($request->integer('per_page', 20), 1), 20)));
    }
}
