<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\AttendanceCaptureToken;
use App\Models\AttendanceIdempotencyKey;
use App\Models\Schedule;
use App\Models\Teacher;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Services\AuditLogger;
use Illuminate\Support\Str;

class AttendanceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Attendance::with('teacher.user')->orderByDesc('attendance_date')->orderByDesc('time_in_at');
        $teacherId = $request->integer('teacher_id') ?: null;
        $date = $request->query('date');
        $status = $request->query('status');
        $search = trim((string) $request->query('search', ''));

        if ($teacherId) $query->where('teacher_id', $teacherId);
        if ($date) $query->whereDate('attendance_date', $date);
        if ($status) $query->where('status', $status);
        if ($search !== '') {
            $like = '%' . addcslashes($search, '%_') . '%';
            $query->whereHas('teacher.user', fn ($q) => $q->where('name', 'like', $like));
        }

        $page = $query->paginate(min(max($request->integer('per_page', 20), 1), 100));
        $page->getCollection()->transform(fn (Attendance $a) => $this->decorateRecord($a));
        return response()->json($page, 200, $this->noStoreHeaders());
    }

    public function captureToken(Request $request, string $action): JsonResponse
    {
        abort_unless(in_array($action, ['time-in', 'time-out'], true), 404);
        $teacher = $request->user()->teacher;
        if (!$teacher) return response()->json(['message' => 'Your account is not linked to a teacher record.'], 403);

        $raw = Str::random(64);
        AttendanceCaptureToken::where('teacher_id', $teacher->id)->where('action', $action)->whereNull('used_at')->update(['used_at' => now()]);
        $token = AttendanceCaptureToken::create([
            'teacher_id' => $teacher->id,
            'token_hash' => hash('sha256', $raw),
            'action' => $action,
            'expires_at' => now()->addMinutes(3),
        ]);

        return response()->json(['token' => $raw, 'expires_at' => $token->expires_at])->withHeaders($this->noStoreHeaders());
    }

    public function myStatus(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacher;
        if (!$teacher) return response()->json(['message' => 'Your account is not linked to a teacher record.'], 403);

        $now = now();
        $schedules = $this->schedulesForDate($teacher->id, $now);

        // Reconcile an open attendance row on status reads as a fallback for
        // the scheduled background job, including after midnight downtime.
        $openAttendance = Attendance::where('teacher_id', $teacher->id)
            ->whereNull('time_out')
            ->whereNull('time_out_at')
            ->orderByDesc('attendance_date')
            ->first();
        if ($openAttendance) $this->closeAttendanceAtLastClassEnd($openAttendance, $now);

        $currentTime = $now->format('H:i:s');
        $activeClass = $schedules->first(fn (Schedule $s) => (string) $s->start_time <= $currentTime && (string) $s->end_time > $currentTime);
        $attendance = Attendance::where('teacher_id', $teacher->id)->whereDate('attendance_date', $now->toDateString())->first();

        return response()->json([
            'today' => $now->toDateString(),
            'current_time' => $now->format('H:i:s'),
            'attendance' => $attendance,
            'has_class_today' => $schedules->isNotEmpty(),
            'first_class' => $schedules->first()?->start_time ? substr((string) $schedules->first()->start_time, 0, 5) : null,
            'last_class_end' => $schedules->max('end_time') ? substr((string) $schedules->max('end_time'), 0, 5) : null,
            'active_class' => $activeClass ? [
                'subject_code' => $activeClass->subject?->subject_code,
                'subject_name' => $activeClass->subject?->subject_name,
                'start_time' => substr((string) $activeClass->start_time, 0, 5),
                'end_time' => substr((string) $activeClass->end_time, 0, 5),
            ] : null,
            'can_time_in' => $activeClass !== null
                && (
                    !$attendance
                    || (
                        ($attendance->time_out_at !== null || $attendance->time_out !== null)
                        && $attendance->status === 'completed'
                    )
                ),
            'can_time_out' => ($attendance?->time_in_at !== null || $attendance?->time_in !== null)
                && $attendance?->time_out_at === null && $attendance?->time_out === null,
        ], 200, $this->noStoreHeaders());
    }

    private function schedulesForDate(int $teacherId, Carbon $date)
    {
        return Schedule::with('subject')->where('teacher_id', $teacherId)
            ->where(function ($query) use ($date): void {
                $query->whereDate('schedule_date', $date->toDateString())
                    ->orWhere(function ($recurring) use ($date): void {
                        $recurring->whereNull('schedule_date')->where('day_of_week', $date->format('l'));
                    });
            })
            ->orderBy('start_time')
            ->get();
    }

    private function closeAttendanceAtLastClassEnd(Attendance $attendance, Carbon $now): Attendance
    {
        if ((!$attendance->time_in_at && !$attendance->time_in) || $attendance->time_out_at || $attendance->time_out) {
            return $attendance;
        }

        $date = Carbon::parse($attendance->attendance_date, config('app.timezone'))->startOfDay();
        $lastEnd = $this->schedulesForDate($attendance->teacher_id, $date)->max('end_time');
        if (!$lastEnd) return $attendance;

        $lastEnd = strlen((string) $lastEnd) === 5 ? $lastEnd.':00' : (string) $lastEnd;
        $deadline = $date->copy()->setTimeFromTimeString($lastEnd);
        if ($now->lt($deadline)) return $attendance;

        $attendance->forceFill([
            'time_out' => $lastEnd,
            'time_out_at' => $deadline->copy()->utc(),
            'status' => 'completed',
        ])->save();

        return $attendance->fresh();
    }

    public function timeIn(Request $request): JsonResponse
    {
        return $this->record($request, 'time-in');
    }

    public function timeOut(Request $request): JsonResponse
    {
        return $this->record($request, 'time-out');
    }

    private function record(Request $request, string $action): JsonResponse
    {
        $teacher = $request->user()->teacher;
        if (!$teacher) return response()->json(['message' => 'Your account is not linked to a teacher record.'], 403);

        $now = now();
        if ($action === 'time-in') {
            $activeClass = $this->schedulesForDate($teacher->id, $now)->first(
                fn (Schedule $schedule) => (string) $schedule->start_time <= $now->format('H:i:s')
                    && (string) $schedule->end_time > $now->format('H:i:s')
            );
            if (!$activeClass) {
                return response()->json([
                    'message' => 'Time-in is only allowed while one of your scheduled classes is currently in progress.',
                ], 422);
            }
        }

        // Camera capture remains supported when the client supplies a token.
        // Authenticated teachers can also record attendance without a camera;
        // all timestamps are still taken from the server.
        $hasCapture = $request->filled('capture_token') || $request->hasFile('photo');
        if ($hasCapture) {
            $request->validate([
                'capture_token' => ['required', 'string', 'size:64'],
                'photo' => ['required', 'file', 'mimes:jpg,jpeg,png', 'max:5120', 'dimensions:min_width=320,min_height=240,max_width=4096,max_height=4096'],
            ]);
        }

        $requestKey = trim((string) ($request->header('Idempotency-Key') ?: $request->input('request_key', '')));
        if (strlen($requestKey) > 128) return response()->json(['message' => 'The request key is invalid. Please try again.'], 422);

        if ($requestKey !== '') {
            $existingKey = AttendanceIdempotencyKey::where('teacher_id', $teacher->id)->where('action', $action)->where('request_key', $requestKey)->first();
            if ($existingKey?->attendance_id) return response()->json(['message' => 'Attendance already recorded.', 'attendance' => $existingKey->attendance()->first()], 200);
        }

        $date = $now->toDateString();
        $path = null;

        try {
            if ($hasCapture) $path = $request->file('photo')->store('attendance', 'local');
            $attendance = DB::transaction(function () use ($teacher, $action, $now, $date, $path, $requestKey, $request, $hasCapture): Attendance {
                if ($hasCapture) {
                    $token = AttendanceCaptureToken::where('teacher_id', $teacher->id)
                        ->where('action', $action)->where('token_hash', hash('sha256', (string) $request->input('capture_token')))
                        ->whereNull('used_at')->lockForUpdate()->first();
                    if (!$token || $token->expires_at->isPast()) throw new \RuntimeException('This camera capture session has expired. Please try again.');
                    $token->update(['used_at' => $now]);
                }
                $attendance = Attendance::where('teacher_id', $teacher->id)->whereDate('attendance_date', $date)->lockForUpdate()->first();

                if ($action === 'time-in') {
                    $hasCompletedPreviousClass = $attendance
                        && ($attendance->time_out_at || $attendance->time_out)
                        && $attendance->status === 'completed';
                    if ($attendance && !$hasCompletedPreviousClass) {
                        throw new \RuntimeException('You have already recorded your time-in for the current class.');
                    }
                    if ($attendance) {
                        $attendance->update([
                            'time_in' => $now->format('H:i:s'),
                            'time_in_at' => $now->copy()->utc(),
                            'photo_in_path' => $path,
                            'time_out' => null,
                            'time_out_at' => null,
                            'photo_out_path' => null,
                            'status' => 'open',
                            'legacy_auto_timeout' => false,
                        ]);
                    } else {
                        $attendance = Attendance::create([
                            'teacher_id' => $teacher->id,
                            'attendance_date' => $date,
                            'time_in' => $now->format('H:i:s'),
                            'time_in_at' => $now->copy()->utc(),
                            'photo_in_path' => $path,
                            'status' => 'open',
                        ]);
                    }
                } else {
                    if (!$attendance || (!$attendance->time_in_at && !$attendance->time_in)) throw new \RuntimeException('You must record your Time In first.');
                    if ($attendance->time_out_at || $attendance->time_out) throw new \RuntimeException('Your Time Out has already been recorded.');
                    $timeInAt = $attendance->time_in_at
                        ? $attendance->time_in_at->copy()->utc()
                        : Carbon::parse($date.' '.$attendance->time_in, config('app.timezone'))->utc();
                    if ($now->copy()->utc()->lt($timeInAt)) throw new \RuntimeException('Time Out cannot be earlier than Time In.');
                    $attendance->update([
                        'time_out' => $now->format('H:i:s'),
                        'time_out_at' => $now->copy()->utc(),
                        'photo_out_path' => $path,
                        'status' => 'completed',
                    ]);
                }

                if ($requestKey !== '') {
                    AttendanceIdempotencyKey::create(['teacher_id' => $teacher->id, 'action' => $action, 'request_key' => $requestKey, 'attendance_id' => $attendance->id]);
                }
                return $attendance->fresh();
            });
        } catch (\Throwable $e) {
            if ($path) Storage::disk('local')->delete($path);
            if (str_contains($e->getMessage(), 'record your Time In first')) {
                return response()->json(['message' => $e->getMessage()], 404);
            }
            $message = str_contains($e->getMessage(), 'already') || str_contains($e->getMessage(), 'first') || str_contains($e->getMessage(), 'earlier')
                ? $e->getMessage() : 'The attendance record could not be saved. Please try again.';
            return response()->json(['message' => $message], 409);
        }

        return response()->json(['message' => ucfirst(str_replace('-', ' ', $action)).' recorded successfully.', 'attendance' => $this->decorateRecord($attendance)], $action === 'time-in' ? 201 : 200, $this->noStoreHeaders());
    }

    public function myAttendance(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacher;
        if (!$teacher) return response()->json(['message' => 'Your account is not linked to a teacher record.'], 403);
        $rows = Attendance::where('teacher_id', $teacher->id)->orderByDesc('attendance_date')->paginate(20);
        $rows->getCollection()->transform(fn ($a) => $this->decorateRecord($a));
        return response()->json($rows, 200, $this->noStoreHeaders());
    }

    public function dates(Request $request): JsonResponse
    {
        $teacherId = $request->integer('teacher_id') ?: null;
        if ($request->user()->role?->slug === 'teacher') $teacherId = $request->user()->teacher?->id;
        $month = $request->query('month');
        $query = Attendance::query()->select('attendance_date')->distinct()->orderByDesc('attendance_date');
        if ($teacherId) $query->where('teacher_id', $teacherId);
        if ($month && preg_match('/^\d{4}-\d{2}$/', $month)) $query->where('attendance_date', 'like', $month . '%');
        return response()->json(['dates' => $query->pluck('attendance_date')->map(fn ($d) => Carbon::parse($d)->toDateString())->values()], 200, $this->noStoreHeaders());
    }

    public function correct(Request $request, Attendance $attendance): JsonResponse
    {
        $validated = $request->validate([
            'time_out' => ['nullable', 'date_format:H:i'],
            'reason' => ['required', 'string', 'min:3', 'max:1000'],
        ]);
        if (!$attendance->time_in_at) return response()->json(['message' => 'This attendance record has no Time In.'], 422);
        if (!$validated['time_out']) return response()->json(['message' => 'Choose a Time Out when correcting an open record.'], 422);
        $out = Carbon::parse($attendance->attendance_date->format('Y-m-d').' '.$validated['time_out'], config('app.timezone'));
        $in = $attendance->time_in_at->copy()->setTimezone(config('app.timezone'));
        if ($out->lte($in)) return response()->json(['message' => 'Time Out must be after Time In.'], 422);
        $attendance->update([
            'time_out' => $out->format('H:i:s'),
            'time_out_at' => $out->copy()->utc(),
            'status' => 'completed',
            'manual_correction_at' => now(),
            'manual_corrected_by' => $request->user()->id,
            'manual_correction_reason' => $validated['reason'],
        ]);
        AuditLogger::record($request->user(),'attendance_correction','attendance',$attendance->id,['reason'=>$validated['reason'],'time_out'=>$validated['time_out']]);
        return response()->json(['message' => 'Attendance corrected successfully.', 'attendance' => $this->decorateRecord($attendance->fresh())]);
    }

    public function verify(Request $request, Attendance $attendance): JsonResponse
    {
        $validated = $request->validate(['verification_status' => ['required', 'in:pending,verified,flagged']]);
        $attendance->update(['verification_status' => $validated['verification_status']]);
        return response()->json(['message' => 'Verification status updated.', 'attendance' => $this->decorateRecord($attendance->fresh())]);
    }

    public function photo(Request $request, Attendance $attendance, string $side)
    {
        abort_unless(in_array($side, ['in', 'out'], true), 404);
        $user = $request->user();
        if ($user->role?->slug === 'teacher' && $attendance->teacher?->user_id !== $user->id) abort(403);
        $path = $side === 'in' ? $attendance->photo_in_path : $attendance->photo_out_path;
        abort_unless($path && Storage::disk('local')->exists($path), 404);
        return response()->file(Storage::disk('local')->path($path), ['Cache-Control' => 'private, no-store']);
    }

    private function decorateRecord(Attendance $attendance): Attendance
    {
        $attendance->setAttribute('duration_minutes', $attendance->time_in_at && $attendance->time_out_at ? $attendance->time_in_at->diffInMinutes($attendance->time_out_at) : null);
        $attendance->setAttribute('photo_in_url', $attendance->photo_in_path ? route('attendance.photo', [$attendance->id, 'in']) : null);
        $attendance->setAttribute('photo_out_url', $attendance->photo_out_path ? route('attendance.photo', [$attendance->id, 'out']) : null);
        return $attendance;
    }

    private function noStoreHeaders(): array
    {
        return ['Cache-Control' => 'no-store, no-cache, must-revalidate, private', 'Pragma' => 'no-cache'];
    }
}
