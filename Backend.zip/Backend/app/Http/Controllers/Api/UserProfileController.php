<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\User;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
class UserProfileController extends Controller
{
 public function show(Request $request): JsonResponse { return response()->json(['user'=>$request->user()->load(['role.permissions','permissions','teacher.department'])]); }
 public function update(Request $request): JsonResponse {
  /** @var User $user */ $user=$request->user();
  if ($user->must_change_password) return response()->json(['code'=>'password_change_required','message'=>'Change your temporary password before editing your profile.'],403);
  $validated=$request->validate(['first_name'=>['sometimes','required','string','max:255'],'middle_name'=>['sometimes','nullable','string','max:255'],'last_name'=>['sometimes','required','string','max:255'],'username'=>['sometimes','required','string','max:255',Rule::unique('users','username')->ignore($user->id)],'email'=>['sometimes','required','email','max:255',Rule::unique('users','email')->ignore($user->id)],'employee_number'=>['sometimes','nullable','string','max:255',Rule::unique('teachers','employee_number')->ignore($user->teacher?->id)],'department_id'=>['sometimes','nullable','integer','exists:departments,id'],'current_password'=>['required_with:password','string'],'password'=>['sometimes','required','string','min:10','confirmed','regex:/[A-Za-z]/','regex:/[0-9]/']]);
  if($user->teacher && array_key_exists('department_id',$validated)) return response()->json(['message'=>'Teachers cannot change their department from Profile.','errors'=>['department_id'=>['Department is managed by an administrator.']]],422);
  if(isset($validated['password'])) { if(!Hash::check($validated['current_password']??'',$user->password)) return response()->json(['message'=>'Your current password is incorrect.','errors'=>['current_password'=>['Your current password is incorrect.']]],422); if(Hash::check($validated['password'],$user->password)) return response()->json(['message'=>'Your new password must be different from your current password.'],422); }
  unset($validated['current_password']);$password=$validated['password']??null;unset($validated['password']);
  DB::transaction(function()use($user,$validated,$password){$profile=array_intersect_key($validated,array_flip(['first_name','middle_name','last_name','username','email']));if($profile){$user->fill($profile);$user->name=trim(implode(' ',array_filter([$user->first_name,$user->middle_name,$user->last_name])));}$user->save();if($user->teacher && array_key_exists('employee_number',$validated))$user->teacher->update(['employee_number'=>$validated['employee_number']]);if($password!==null){$user->password=$password;$user->must_change_password=false;$user->save();}});
  AuditLogger::record($user,'edited','profile',$user->id,['fields'=>array_keys($validated)]);
  return response()->json(['message'=>'Profile updated successfully.','user'=>$user->fresh()->load(['role.permissions','permissions','teacher.department'])]);
 }
 public function destroy(Request $request): JsonResponse {
  /** @var User $user */$user=$request->user();
  if($user->must_change_password) return response()->json(['code'=>'password_change_required','message'=>'Change your temporary password before deleting your account.'],403);
  $rootSlugs=['root-admin','super_admin','super-admin'];
  if(in_array($user->role?->slug,$rootSlugs,true) && User::whereHas('role',fn($q)=>$q->whereIn('slug',$rootSlugs))->where('is_active',true)->count()<=1)return response()->json(['code'=>'last_super_admin_protected','message'=>'The only Super Admin account cannot be deleted. Assign another Super Admin first.'],409);
  if($user->teacher && ($user->teacher->schedules()->exists() || $user->teacher->attendances()->exists()))return response()->json(['code'=>'account_history_exists','message'=>'This account cannot be deleted because it has schedule or attendance history.'],409);
  $validated=$request->validate(['current_password'=>['required','string']]);if(!Hash::check($validated['current_password'],$user->password))return response()->json(['message'=>'Your current password is incorrect.'],422);
  $id=$user->id;DB::transaction(fn()=> $user->delete());AuditLogger::record($request->user(),'deleted','user',$id);return response()->json(['message'=>'Your account was deleted.']);
 }
}
