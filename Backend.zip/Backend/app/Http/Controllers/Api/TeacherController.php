<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Role;
use App\Models\Teacher;
use App\Models\User;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class TeacherController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query=Teacher::with(['user','subjects','department'])->where('employment_status','!=','Deleted');
        $search=trim((string)$request->query('search','')); $status=$request->query('status');
        if($request->filled('department_id')) $query->where('department_id',$request->integer('department_id'));
        if($search!==''){ $like='%'.addcslashes($search,'%_').'%'; $query->whereHas('user',fn($u)=>$u->where('name','like',$like)->orWhere('email','like',$like)->orWhere('username','like',$like)); }
        if($status==='active') $query->where('employment_status','Active')->whereHas('user',fn($q)=>$q->where('is_active',true));
        if($status==='inactive') $query->where(fn($q)=>$q->where('employment_status','Inactive')->orWhereHas('user',fn($u)=>$u->where('is_active',false)));
        if($request->filled('subject_id')) $query->whereHas('subjects',fn($q)=>$q->whereKey($request->integer('subject_id')));
        return response()->json($query->orderBy('id')->paginate(min(max($request->integer('per_page',20),1),100)));
    }

    public function store(Request $request): JsonResponse
    {
        $validated=$request->validate([
            'first_name'=>['required','string','max:255'],'middle_name'=>['nullable','string','max:255'],'last_name'=>['required','string','max:255'],
            'username'=>['required','string','max:255','unique:users,username'],'email'=>['required','email','max:255','unique:users,email'],
            'department_id'=>['nullable','integer','exists:departments,id'],'employee_number'=>['nullable','string','max:255','unique:teachers,employee_number'],
            'subject_ids'=>['nullable','array'],'subject_ids.*'=>['integer','exists:subjects,id'],'temporary_password'=>['nullable','string','min:10','max:255'],
        ]);
        if(isset($validated['department_id']) && !Department::whereKey($validated['department_id'])->where('is_active',true)->exists()) return response()->json(['message'=>'Choose an active department.'],422);
        $role=Role::where('slug','teacher')->firstOrFail(); $temporaryPassword=$validated['temporary_password']??Str::password(12);
        $teacher=DB::transaction(function()use($validated,$role,$temporaryPassword){$user=User::create(['name'=>trim(implode(' ',array_filter([$validated['first_name'],$validated['middle_name']??null,$validated['last_name']]))),'first_name'=>trim($validated['first_name']),'middle_name'=>$validated['middle_name']??null,'last_name'=>trim($validated['last_name']),'username'=>trim($validated['username']),'email'=>trim($validated['email']),'password'=>Hash::make($temporaryPassword),'role_id'=>$role->id,'is_active'=>true,'must_change_password'=>true]);$dept=$validated['department_id']??null;$teacher=Teacher::create(['user_id'=>$user->id,'employee_number'=>$validated['employee_number']??null,'department_id'=>$dept,'department'=>$dept?Department::find($dept)?->name:null,'employment_status'=>'Active']);$teacher->subjects()->sync($validated['subject_ids']??[]);return $teacher;});
        AuditLogger::record($request->user(),'created','teacher',$teacher->id,['user_id'=>$teacher->user_id]);
        return response()->json(['message'=>'Teacher account created successfully.','temporary_password'=>$temporaryPassword,'teacher'=>$teacher->load(['user','subjects','department'])],201);
    }

    public function show(Teacher $teacher): JsonResponse { return response()->json($teacher->load('user','subjects','department','schedules.classroom','schedules.subject')); }

    public function update(Request $request, Teacher $teacher): JsonResponse
    {
        $validated=$request->validate([
            'first_name'=>['sometimes','required','string','max:255'],'middle_name'=>['sometimes','nullable','string','max:255'],'last_name'=>['sometimes','required','string','max:255'],
            'username'=>['sometimes','required','string','max:255',Rule::unique('users','username')->ignore($teacher->user_id)],'email'=>['sometimes','required','email','max:255',Rule::unique('users','email')->ignore($teacher->user_id)],
            'employee_number'=>['sometimes','nullable','string','max:255',Rule::unique('teachers','employee_number')->ignore($teacher->id)],'department_id'=>['sometimes','nullable','integer','exists:departments,id'],'subject_ids'=>['sometimes','array'],'subject_ids.*'=>['integer','exists:subjects,id'],
        ]);
        if(array_key_exists('department_id',$validated) && $validated['department_id']!==null && !Department::whereKey($validated['department_id'])->where('is_active',true)->exists()) return response()->json(['message'=>'Choose an active department.'],422);
        $old=$teacher->load('user');
        DB::transaction(function()use($teacher,$validated){$user=$teacher->user;$fields=array_intersect_key($validated,array_flip(['first_name','middle_name','last_name','username','email']));if($fields){$user->fill($fields);$user->name=trim(implode(' ',array_filter([$user->first_name,$user->middle_name,$user->last_name])));$user->save();} $teacherFields=array_intersect_key($validated,array_flip(['employee_number','department_id']));if(array_key_exists('department_id',$teacherFields))$teacherFields['department']=Department::find($teacherFields['department_id'])?->name;$teacher->update($teacherFields);if(array_key_exists('subject_ids',$validated))$teacher->subjects()->sync($validated['subject_ids']);});
        AuditLogger::record($request->user(),'edited','teacher',$teacher->id,['old_user_id'=>$old->user_id,'changes'=>$validated]);
        return response()->json(['message'=>'Teacher updated successfully.','teacher'=>$teacher->fresh()->load(['user','subjects','department'])]);
    }

    public function destroy(Request $request, Teacher $teacher): JsonResponse
    {
        if($teacher->schedules()->exists() || $teacher->attendances()->exists()) return response()->json(['code'=>'teacher_history_exists','message'=>'This teacher cannot be deleted because schedules or attendance history exist.'],409);
        $user=$teacher->user; DB::transaction(function()use($teacher,$user){$teacher->subjects()->detach();$teacher->delete();$user?->delete();}); AuditLogger::record($request->user(),'deleted','teacher',$teacher->id,['user_id'=>$user?->id]);
        return response()->json(['message'=>'Teacher account deleted successfully.']);
    }

    public function resetPassword(Request $request, Teacher $teacher): JsonResponse
    {
        $password=Str::password(12); DB::transaction(function()use($teacher,$password){$teacher->user->update(['password'=>Hash::make($password),'must_change_password'=>true]);$teacher->user->tokens()->delete();});
        AuditLogger::record($request->user(),'edited','teacher',$teacher->id,['action'=>'password_reset']);
        return response()->json(['message'=>'Teacher password reset.','temporary_password'=>$password]);
    }
}
