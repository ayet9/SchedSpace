<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class DepartmentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Department::query()->withCount(['teachers as assigned_teachers_count' => fn($q) => $q->where('employment_status','!=','Deleted')]);
        $query->addSelect(['unassigned_teachers_count' => function($q){
            $q->selectRaw('COUNT(*)')->from('teachers')->whereNull('department_id')->where('employment_status','!=','Deleted');
        }]);
        if ($request->filled('active')) $query->where('is_active', $request->boolean('active'));
        return response()->json($query->orderBy('name')->get());
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate(['name'=>['required','string','max:255','unique:departments,name']]);
        $department = DB::transaction(fn()=>Department::create(['name'=>trim($validated['name']),'is_active'=>true]));
        AuditLogger::record($request->user(),'created','department',$department->id,['name'=>$department->name]);
        return response()->json(['message'=>'Department created successfully.','department'=>$department],201);
    }

    public function update(Request $request, Department $department): JsonResponse
    {
        $validated = $request->validate([
            'name'=>['sometimes','required','string','max:255',Rule::unique('departments','name')->ignore($department->id)],
            'is_active'=>['sometimes','boolean'],
        ]);
        $old=$department->name;
        DB::transaction(function() use($department,$validated){ $department->update($validated); });
        AuditLogger::record($request->user(),'edited','department',$department->id,['old_name'=>$old,'changes'=>$validated]);
        return response()->json(['message'=>'Department updated successfully.','department'=>$department->fresh()]);
    }

    public function destroy(Request $request, Department $department): JsonResponse
    {
        if ($department->teachers()->where('employment_status','!=','Deleted')->exists()) {
            return response()->json(['code'=>'department_in_use','message'=>'This department cannot be deleted while teachers are assigned to it.'],409);
        }
        DB::transaction(fn()=> $department->delete());
        AuditLogger::record($request->user(),'deleted','department',$department->id,['name'=>$department->name]);
        return response()->json(['message'=>'Department deleted successfully.']);
    }
}
