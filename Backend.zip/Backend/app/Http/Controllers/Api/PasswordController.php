<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
class PasswordController extends Controller
{
    public function change(Request $request): JsonResponse
    {
        /** @var User $user */ $user=$request->user();
        $validated=$request->validate(['current_password'=>['required','string'],'password'=>['required','string','min:10','confirmed','regex:/[A-Za-z]/','regex:/[0-9]/']]);
        if(!Hash::check($validated['current_password'],$user->password)) return response()->json(['code'=>'current_password_incorrect','message'=>'Your current password is incorrect.','errors'=>['current_password'=>['Your current password is incorrect.']]],422);
        if(Hash::check($validated['password'],$user->password)) return response()->json(['code'=>'password_unchanged','message'=>'Your new password must be different from your current password.','errors'=>['password'=>['Your new password must be different from your current password.']]],422);
        $user->password=$validated['password'];$user->must_change_password=false;$user->save();
        $current=$user->currentAccessToken();
        $user->tokens()->where('id','!=',$current?->id)->delete();
        $fresh=$user->fresh()->load(['role.permissions','permissions','teacher']);
        return response()->json(['message'=>'Password changed successfully.','user'=>$fresh,'must_change_password'=>false]);
    }
}
