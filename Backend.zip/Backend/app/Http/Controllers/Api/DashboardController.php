<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Schedule;
use App\Models\Subject;
use App\Models\Teacher;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Carbon\CarbonImmutable;

class DashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $today = CarbonImmutable::now(config('app.timezone'))->toDateString();
        $isTeacher = $user->role?->slug === 'teacher';
        $teacherId = $user->teacher?->id;

        $rooms = Classroom::query()
            ->where('is_active', true)
            ->with('layoutType:id,name,image_path')
            ->get([
                'id',
                'room_number',
                'building',
                'floor',
                'capacity',
                'features',
                'plan',
                'layout_type_id',
                'layout_image_path',
            ]);

        $scheduleQuery = Schedule::query()
            ->with([
                'teacher:id,user_id',
                'teacher.user:id,first_name,middle_name,last_name',
                'subject:id,subject_code,subject_name',
                'classroom:id,room_number',
            ]);

        if ($isTeacher) {
            $scheduleQuery->where('teacher_id', $teacherId ?? 0);
        }

        $schedules = $scheduleQuery
            ->where(function ($query) use ($today) {
                $query->whereDate('schedule_date', $today)
                    ->orWhere(function ($fallback) use ($today) {
                        $fallback->whereNull('schedule_date')
                            ->where('day_of_week', CarbonImmutable::parse($today)->format('l'));
                    });
            })
            ->orderBy('start_time')
            ->get();

        // The schedule query already eager-loads its subject and teacher. Reuse only
        // those records for today's dashboard rows instead of loading every subject
        // and every teacher on each sign-in.
        $subjects = $schedules->pluck('subject')->filter()->unique('id')->values();
        $teachers = $schedules->pluck('teacher')->filter()->unique('id')->values();
        $teacherCount = $isTeacher
            ? (int) ($teacherId !== null)
            : Teacher::query()->where('employment_status', 'Active')->count();

        $attendanceQuery = Attendance::query()
            ->whereDate('attendance_date', $today);

        if ($isTeacher) {
            $attendanceQuery->where('teacher_id', $teacherId ?? 0);
        }

        $attendance = $attendanceQuery->get([
            'id',
            'teacher_id',
            'attendance_date',
            'time_in',
            'time_out',
            'status',
            'verification_status',
        ]);

        return response()->json([
            'today' => $today,
            'rooms' => $rooms,
            'schedules' => $schedules,
            'subjects' => $subjects,
            'teachers' => $teachers,
            'teacher_count' => $teacherCount,
            'attendance' => $attendance,
        ]);
    }
}
