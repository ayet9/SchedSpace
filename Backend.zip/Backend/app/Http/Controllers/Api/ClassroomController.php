<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Classroom;
use App\Models\ClassroomLayoutType;
use App\Models\Building;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use App\Services\AuditLogger;
use Illuminate\Validation\Rule;

class ClassroomController extends Controller
{
    public function layoutTypes(): JsonResponse
    {
        return response()->json(ClassroomLayoutType::orderBy('name')->get());
    }

    public function index(Request $request): JsonResponse
    {
        $query = Classroom::with('layoutType')->where('is_active', true)->orderBy('room_number');
        if ($request->filled('search')) $query->where('room_number', 'like', '%' . addcslashes(trim($request->query('search')), '%_') . '%');
        if ($request->filled('layout_type_id')) $query->where('layout_type_id', $request->query('layout_type_id'));
        return response()->json($query->paginate(min(max($request->integer('per_page', 20), 1), 100)));
    }

    public function show(Classroom $classroom): JsonResponse
    {
        return response()->json($classroom->load('layoutType', 'schedules.teacher.user', 'schedules.subject'));
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validateRoom($request);
        $layoutImage = $validated['layout_image'] ?? null;
        unset($validated['layout_image']);
        if ($layoutImage) $validated['layout_image_path'] = $layoutImage->store('classroom-layouts', 'public');
        $room = Classroom::create($validated);
        return response()->json(['message' => 'Classroom created successfully.', 'classroom' => $room->load('layoutType')], 201);
    }

    public function update(Request $request, Classroom $classroom): JsonResponse
    {
        if (!$classroom->is_active) return response()->json(['message' => 'Inactive classrooms cannot be edited. Reactivate it first.'], 409);
        $validated = $this->validateRoom($request, $classroom);
        $layoutImage = $validated['layout_image'] ?? null;
        unset($validated['layout_image']);
        $oldLayoutImage = $classroom->layout_image_path;
        if ($layoutImage) $validated['layout_image_path'] = $layoutImage->store('classroom-layouts', 'public');
        $classroom->update($validated);
        if ($layoutImage && $oldLayoutImage) Storage::disk('public')->delete($oldLayoutImage);
        return response()->json(['message' => 'Classroom updated successfully.', 'classroom' => $classroom->fresh()->load('layoutType')]);
    }

    public function updatePlan(Request $request, Classroom $classroom): JsonResponse
    {
        if (!$classroom->is_active) {
            return response()->json(['message' => 'Inactive classrooms cannot be moved. Reactivate it first.'], 409);
        }

        $validated = $request->validate([
            'plan' => ['required', 'array'],
            'plan.col' => ['required', 'integer', 'min:1', 'max:12'],
            'plan.row' => ['required', 'integer', 'min:1', 'max:200'],
            'plan.colSpan' => ['required', 'integer', 'min:1', 'max:12'],
            'plan.rowSpan' => ['required', 'integer', 'min:1', 'max:100'],
            'plan.door' => ['nullable', Rule::in(['top', 'bottom'])],
        ]);
        $plan = $validated['plan'];

        if ($plan['col'] + $plan['colSpan'] > 13 || $plan['row'] + $plan['rowSpan'] > 201) {
            return response()->json(['message' => 'That room would extend beyond the floor-plan area.'], 422);
        }
        if ($plan['row'] <= 4 && $plan['row'] + $plan['rowSpan'] > 4) {
            return response()->json(['message' => 'The central corridor must remain clear.'], 422);
        }
        if ($this->planIsOccupied($plan, ['building' => $classroom->building, 'floor' => $classroom->floor], $classroom)) {
            return response()->json(['message' => 'That floor-plan position overlaps another classroom.'], 422);
        }
        $building = Building::query()->where('name', $classroom->building)->first();
        $buildingWalkways = $building?->walkways ?? [];
        $walkways = $buildingWalkways[(string) $classroom->floor] ?? [];
        foreach ($walkways as $cell) {
            if ($cell['col'] >= $plan['col'] && $cell['col'] < $plan['col'] + $plan['colSpan']
                && $cell['row'] >= $plan['row'] && $cell['row'] < $plan['row'] + $plan['rowSpan']) {
                return response()->json(['message' => 'Move the walkway marker before placing a classroom here.'], 422);
            }
        }

        $classroom->update(['plan' => $plan]);
        AuditLogger::record($request->user(), 'updated', 'classroom', $classroom->id, [
            'room_number' => $classroom->room_number,
            'plan' => $plan,
        ]);

        return response()->json([
            'message' => 'Classroom position saved.',
            'classroom' => $classroom->fresh()->load('layoutType'),
        ]);
    }

    public function reposition(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'placements' => ['required', 'array', 'min:1', 'max:2'],
            'placements.*.id' => ['required', 'integer', 'distinct', 'exists:classrooms,id'],
            'placements.*.plan' => ['required', 'array'],
            'placements.*.plan.col' => ['required', 'integer', 'min:1', 'max:12'],
            'placements.*.plan.row' => ['required', 'integer', 'min:1', 'max:200'],
            'placements.*.plan.colSpan' => ['required', 'integer', 'min:1', 'max:12'],
            'placements.*.plan.rowSpan' => ['required', 'integer', 'min:1', 'max:100'],
            'placements.*.plan.door' => ['nullable', Rule::in(['top', 'bottom'])],
        ]);

        $placements = $validated['placements'];
        $rooms = Classroom::query()->whereIn('id', array_column($placements, 'id'))->get()->keyBy('id');
        if ($rooms->count() !== count($placements)) {
            return response()->json(['message' => 'One of the classrooms could not be found. Refresh the floor plan and try again.'], 404);
        }

        $firstRoom = $rooms->first();
        foreach ($rooms as $room) {
            if (!$room->is_active) return response()->json(['message' => "{$room->room_number} is inactive and cannot be moved."], 409);
            if ($room->building !== $firstRoom->building || $room->floor !== $firstRoom->floor) {
                return response()->json(['message' => 'Rooms can only be rearranged within the same building and floor.'], 422);
            }
        }

        $plans = [];
        foreach ($placements as $placement) {
            $plan = $placement['plan'];
            if ($plan['col'] + $plan['colSpan'] > 13 || $plan['row'] + $plan['rowSpan'] > 201) {
                return response()->json(['message' => 'A room would extend beyond the floor-plan area.'], 422);
            }
            if ($plan['row'] <= 4 && $plan['row'] + $plan['rowSpan'] > 4) {
                return response()->json(['message' => 'The central corridor must remain clear.'], 422);
            }
            $plans[(int) $placement['id']] = $plan;
        }

        $planIds = array_keys($plans);
        foreach ($planIds as $index => $roomId) {
            foreach (array_slice($planIds, $index + 1) as $otherId) {
                if ($this->plansOverlap($plans[$roomId], $plans[$otherId])) {
                    return response()->json(['message' => 'The new room positions overlap each other.'], 422);
                }
            }
        }

        $otherRooms = Classroom::query()
            ->where('building', $firstRoom->building)
            ->where('floor', $firstRoom->floor)
            ->whereNotIn('id', $planIds)
            ->get(['id', 'plan']);
        foreach ($plans as $plan) {
            if ($otherRooms->contains(fn (Classroom $other) => $this->plansOverlap($plan, $other->plan ?? []))) {
                return response()->json(['message' => 'Choose an empty position or drop onto another room to swap their positions.'], 422);
            }
        }

        $building = Building::query()->where('name', $firstRoom->building)->first();
        $buildingWalkways = $building?->walkways ?? [];
        $walkways = $buildingWalkways[(string) $firstRoom->floor] ?? [];
        foreach ($plans as $plan) {
            foreach ($walkways as $cell) {
                if ($cell['col'] >= $plan['col'] && $cell['col'] < $plan['col'] + $plan['colSpan']
                    && $cell['row'] >= $plan['row'] && $cell['row'] < $plan['row'] + $plan['rowSpan']) {
                    return response()->json(['message' => 'Move the walkway marker before placing a classroom here.'], 422);
                }
            }
        }

        DB::transaction(function () use ($rooms, $plans, $request): void {
            foreach ($plans as $roomId => $plan) {
                $room = $rooms->get($roomId);
                $room->update(['plan' => $plan]);
                AuditLogger::record($request->user(), 'updated', 'classroom', $room->id, [
                    'room_number' => $room->room_number,
                    'plan' => $plan,
                ]);
            }
        });

        return response()->json([
            'message' => 'Floor-plan positions saved.',
            'classrooms' => Classroom::query()->whereIn('id', $planIds)->with('layoutType')->get(),
        ]);
    }

    public function deactivate(Classroom $classroom): JsonResponse
    {
        $classroom->update(['is_active' => false, 'status' => 'Inactive']);
        return response()->json(['message' => 'Classroom deactivated successfully.']);
    }

    public function reactivate(Classroom $classroom): JsonResponse
    {
        $classroom->update(['is_active' => true, 'status' => 'Available']);
        return response()->json(['message' => 'Classroom reactivated successfully.']);
    }

    public function destroy(Classroom $classroom): JsonResponse
    {
        if ($classroom->schedules()->exists()) return response()->json(['message' => 'This classroom has schedules. Deactivate it instead.'], 409);
        if ($classroom->layout_image_path) Storage::disk('public')->delete($classroom->layout_image_path);
        $classroom->delete();
        return response()->json(['message' => 'Classroom deleted successfully.']);
    }

    private function validateRoom(Request $request, ?Classroom $room = null): array
    {
        $validated = $request->validate([
            'room_number' => ['required', 'string', 'max:255'],
            'layout_type_id' => ['nullable', 'integer', 'exists:classroom_layout_types,id'],
            'layout_image' => ['sometimes', 'nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
            'capacity' => ['required', 'integer', 'min:1'],
            'building' => ['nullable', 'string', 'max:255'],
            'floor' => ['nullable', 'string', 'max:255'],
            'location_description' => ['nullable', 'string', 'max:1000'],
            'status' => ['nullable', 'string', 'max:255'],
            'features' => ['nullable', 'array'],
            'features.*' => ['string', 'max:255'],
            'plan' => ['sometimes', 'nullable', 'array'],
            'plan.col' => ['required_with:plan', 'integer', 'min:1'],
            'plan.row' => ['required_with:plan', 'integer', 'min:1'],
            'plan.colSpan' => ['required_with:plan', 'integer', 'min:1'],
            'plan.rowSpan' => ['required_with:plan', 'integer', 'min:1'],
            'plan.door' => ['nullable', Rule::in(['top', 'bottom'])],
        ]);

        $normalized = preg_replace('/\s+/', ' ', trim($validated['room_number']));
        $duplicate = Classroom::whereRaw('LOWER(TRIM(room_number)) = ?', [mb_strtolower($normalized)])
            ->when($room, fn ($q) => $q->where('id', '!=', $room->id))->exists();
        if ($duplicate) abort(422, 'A classroom with that name already exists.');

        $building = Building::query()->whereRaw('LOWER(name) = ?', [mb_strtolower(trim((string) ($validated['building'] ?? '')))])->first();
        if ($building) {
            $floor = trim((string) ($validated['floor'] ?? ''));
            if (!ctype_digit($floor) || (int) $floor < 1 || (int) $floor > $building->floor_count) {
                abort(422, "Choose a floor from 1 to {$building->floor_count} for {$building->name}.");
            }
        }

        if (!empty($validated['plan']) && $this->planIsOccupied($validated['plan'], $validated, $room)) {
            abort(422, 'That floor-plan position is already occupied in this building and floor.');
        }

        if (!empty($validated['layout_type_id'])) {
            $layout = ClassroomLayoutType::findOrFail($validated['layout_type_id']);
            if ($validated['capacity'] < $layout->min_capacity || $validated['capacity'] > $layout->max_capacity) {
                abort(422, "Capacity must be between {$layout->min_capacity} and {$layout->max_capacity} for {$layout->name}.");
            }
        }
        $validated['room_number'] = $normalized;
        $validated['status'] = $validated['status'] ?? 'Available';
        $validated['is_active'] = true;
        return $validated;
    }

    private function planIsOccupied(array $plan, array $validated, ?Classroom $room): bool
    {
        return Classroom::query()
            ->where('building', $validated['building'] ?? null)
            ->where('floor', $validated['floor'] ?? null)
            ->when($room, fn ($query) => $query->where('id', '!=', $room->id))
            ->get(['id', 'plan'])
            ->contains(fn (Classroom $other) => $this->plansOverlap($plan, $other->plan ?? []));
    }

    private function plansOverlap(array $left, array $right): bool
    {
        if (!isset($left['col'], $left['row'], $left['colSpan'], $left['rowSpan'], $right['col'], $right['row'], $right['colSpan'], $right['rowSpan'])) {
            return false;
        }

        return $left['col'] < $right['col'] + $right['colSpan']
            && $left['col'] + $left['colSpan'] > $right['col']
            && $left['row'] < $right['row'] + $right['rowSpan']
            && $left['row'] + $left['rowSpan'] > $right['row'];
    }
}
