<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use App\Services\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SubjectController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(
            Subject::with('students')->orderBy('subject_code')->get()
        );
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'subject_code' => ['required', 'string', 'max:255', 'unique:subjects,subject_code'],
            'subject_name' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'units' => ['nullable', 'integer', 'min:1'],
        ]);

        $subject = Subject::create($validated);
        AuditLogger::record($request->user(), 'created', 'subject', $subject->id, ['code' => $subject->subject_code]);

        return response()->json([
            'message' => 'Subject created successfully.',
            'subject' => $subject,
        ], 201);
    }

    public function show(Subject $subject): JsonResponse
    {
        return response()->json($subject->load('students'));
    }

    public function update(Request $request, Subject $subject): JsonResponse
    {
        $validated = $request->validate([
            'subject_code' => [
                'sometimes', 'required', 'string', 'max:255',
                Rule::unique('subjects', 'subject_code')->ignore($subject->id),
            ],
            'subject_name' => ['sometimes', 'required', 'string', 'max:255'],
            'description' => ['sometimes', 'nullable', 'string'],
            'units' => ['sometimes', 'nullable', 'integer', 'min:1'],
        ]);

        $subject->update($validated);
        AuditLogger::record($request->user(), 'edited', 'subject', $subject->id, ['changes' => $validated]);

        return response()->json([
            'message' => 'Subject updated successfully.',
            'subject' => $subject,
        ]);
    }

    public function destroy(Subject $subject): JsonResponse
    {
        if ($subject->studentSubjects()->exists() || $subject->schedules()->exists() || $subject->teachers()->exists()) {
            return response()->json([
                'message' => 'Cannot delete this subject because enrollments, teacher assignments, or schedules still reference it.',
            ], 409);
        }

        $id=$subject->id;
        DB::transaction(fn()=> $subject->delete());
        AuditLogger::record($request->user(), 'deleted', 'subject', $id);

        return response()->json([
            'message' => 'Subject deleted successfully.',
        ]);
    }
}