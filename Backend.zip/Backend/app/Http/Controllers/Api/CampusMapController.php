<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CampusMapController extends Controller
{
    public function show(): JsonResponse
    {
        $storedWalkways = DB::table('campus_map_settings')->where('map_key', 'main')->value('walkways');
        $walkways = is_string($storedWalkways) ? json_decode($storedWalkways, true) : $storedWalkways;

        return response()->json(['walkways' => is_array($walkways) ? $walkways : []]);
    }

    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'walkways' => ['present', 'array'],
            'walkways.*' => ['required', 'array', 'min:2'],
            'walkways.*.*' => ['required', 'array:x,y'],
            'walkways.*.*.x' => ['required', 'numeric', 'between:0,100'],
            'walkways.*.*.y' => ['required', 'numeric', 'between:0,100'],
        ]);

        $walkways = array_map(
            fn (array $path): array => array_map(
                fn (array $point): array => [
                    'x' => round((float) $point['x'], 2),
                    'y' => round((float) $point['y'], 2),
                ],
                $path,
            ),
            $validated['walkways'],
        );
        $createdAt = DB::table('campus_map_settings')->where('map_key', 'main')->value('created_at') ?? now();

        DB::table('campus_map_settings')->updateOrInsert(
            ['map_key' => 'main'],
            ['walkways' => json_encode($walkways, JSON_THROW_ON_ERROR), 'created_at' => $createdAt, 'updated_at' => now()],
        );

        AuditLogger::record($request->user(), 'updated', 'campus_map', 'main', [
            'walkway_count' => count($walkways),
        ]);

        return response()->json([
            'message' => 'Campus walkways saved.',
            'walkways' => $walkways,
        ]);
    }
}
