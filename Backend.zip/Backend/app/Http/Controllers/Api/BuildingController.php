<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Building;
use App\Models\Classroom;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BuildingController extends Controller
{
    public function index(): JsonResponse
    {
        $buildings = Building::query()->orderBy('name')->get()->map(fn (Building $building) => $this->present($building));

        return response()->json($buildings);
    }

    public function store(Request $request): JsonResponse
    {
        $request->merge(['name' => $this->normalizeName((string) $request->input('name', ''))]);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:buildings,name'],
            'floor_count' => ['required', 'integer', 'min:1', 'max:100'],
        ]);

        $highestAssignedFloor = Classroom::query()
            ->whereRaw('LOWER(building) = ?', [mb_strtolower($validated['name'])])
            ->pluck('floor')
            ->filter(fn ($floor) => ctype_digit((string) $floor))
            ->map(fn ($floor) => (int) $floor)
            ->max() ?? 0;
        if ($highestAssignedFloor > $validated['floor_count']) {
            return response()->json([
                'message' => "This building already has classrooms on floor {$highestAssignedFloor}. Set the floor count to at least {$highestAssignedFloor}.",
            ], 409);
        }

        $building = Building::create($validated);
        AuditLogger::record($request->user(), 'created', 'building', $building->id, [
            'name' => $building->name,
            'floor_count' => $building->floor_count,
        ]);

        return response()->json([
            'message' => 'Building created successfully.',
            'building' => $this->present($building),
        ], 201);
    }

    public function update(Request $request, Building $building): JsonResponse
    {
        $request->merge(['name' => $this->normalizeName((string) $request->input('name', ''))]);
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:buildings,name,' . $building->id],
            'floor_count' => ['required', 'integer', 'min:1', 'max:100'],
        ]);
        $rooms = Classroom::query()->where('building', $building->name)->get(['id', 'floor']);
        $tooHigh = $rooms->first(fn (Classroom $room) => ctype_digit((string) $room->floor) && (int) $room->floor > $validated['floor_count']);
        if ($tooHigh) {
            return response()->json([
                'message' => "Floor count cannot be reduced while classroom {$tooHigh->id} is assigned to floor {$tooHigh->floor}.",
            ], 409);
        }

        $oldName = $building->name;
        DB::transaction(function () use ($building, $validated, $oldName): void {
            if ($oldName !== $validated['name']) {
                Classroom::query()->where('building', $oldName)->update(['building' => $validated['name']]);
            }

            $building->update($validated);
        });

        AuditLogger::record($request->user(), 'updated', 'building', $building->id, [
            'old_name' => $oldName,
            'name' => $building->name,
            'floor_count' => $building->floor_count,
        ]);

        return response()->json([
            'message' => 'Building updated successfully.',
            'building' => $this->present($building->fresh()),
        ]);
    }

    public function updatePosition(Request $request, Building $building): JsonResponse
    {
        $position = $request->validate([
            'map_x' => ['required', 'integer', 'min:4', 'max:96'],
            'map_y' => ['required', 'integer', 'min:8', 'max:92'],
        ]);

        $building->update($position);
        AuditLogger::record($request->user(), 'updated', 'building', $building->id, [
            'map_x' => $building->map_x,
            'map_y' => $building->map_y,
        ]);

        return response()->json([
            'message' => 'Building position saved.',
            'building' => $this->present($building->fresh()),
        ]);
    }

    public function destroy(Request $request, Building $building): JsonResponse
    {
        $roomCount = Classroom::query()->where('building', $building->name)->count();
        if ($roomCount > 0) {
            return response()->json([
                'message' => 'Move or delete this building’s classrooms before deleting the building.',
            ], 409);
        }

        AuditLogger::record($request->user(), 'deleted', 'building', $building->id, ['name' => $building->name]);
        $building->delete();

        return response()->json(['message' => 'Building deleted successfully.']);
    }

    public function updateWalkways(Request $request, Building $building, int $floor): JsonResponse
    {
        abort_if($floor < 1 || $floor > $building->floor_count, 404, 'That floor does not exist in this building.');

        $validated = $request->validate([
            'cells' => ['present', 'array', 'max:128'],
            'cells.*.col' => ['required', 'integer', 'min:1', 'max:12'],
            'cells.*.row' => ['required', 'integer', 'min:1', 'max:200', 'not_in:4'],
        ]);

        $cells = collect($validated['cells'])
            ->unique(fn (array $cell) => $cell['col'] . ':' . $cell['row'])
            ->values()
            ->all();
        $rooms = Classroom::query()
            ->where('building', $building->name)
            ->where('floor', (string) $floor)
            ->get(['id', 'plan']);

        foreach ($cells as $cell) {
            foreach ($rooms as $room) {
                $plan = $room->plan ?? [];
                if (isset($plan['col'], $plan['row'], $plan['colSpan'], $plan['rowSpan'])
                    && $cell['col'] >= $plan['col'] && $cell['col'] < $plan['col'] + $plan['colSpan']
                    && $cell['row'] >= $plan['row'] && $cell['row'] < $plan['row'] + $plan['rowSpan']) {
                    return response()->json(['message' => 'A walkway marker cannot cover a classroom.'], 422);
                }
            }
        }

        $walkways = $building->walkways ?? [];
        $walkways[(string) $floor] = $cells;
        $building->update(['walkways' => $walkways]);

        AuditLogger::record($request->user(), 'updated', 'building', $building->id, [
            'floor' => $floor,
            'walkway_cells' => count($cells),
        ]);

        return response()->json([
            'message' => 'Walkway markers saved.',
            'building' => $this->present($building->fresh()),
        ]);
    }

    private function present(Building $building): array
    {
        $counts = Classroom::query()
            ->where('building', $building->name)
            ->select('floor', DB::raw('COUNT(*) as room_count'))
            ->groupBy('floor')
            ->pluck('room_count', 'floor');

        $floors = collect(range(1, $building->floor_count))->map(fn (int $number) => [
            'number' => $number,
            'room_count' => (int) ($counts[(string) $number] ?? 0),
        ])->all();

        return [
            'id' => $building->id,
            'name' => $building->name,
            'floor_count' => $building->floor_count,
            'room_count' => (int) $counts->sum(),
            'floors' => $floors,
            'walkways' => $building->walkways ?? (object) [],
            'map_x' => $building->map_x,
            'map_y' => $building->map_y,
        ];
    }

    private function normalizeName(string $name): string
    {
        return preg_replace('/\s+/', ' ', trim($name));
    }
}
