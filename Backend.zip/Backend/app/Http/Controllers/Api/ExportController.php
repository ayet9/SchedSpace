<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Classroom;
use App\Models\Schedule;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ExportController extends Controller
{
    public function attendanceCsv(Request $request): StreamedResponse
    {
        $query = Attendance::with('teacher.user')->orderByDesc('attendance_date')->orderByDesc('time_in_at');
        if ($request->filled('teacher_id')) $query->where('teacher_id', $request->query('teacher_id'));
        if ($request->filled('from')) $query->whereDate('attendance_date', '>=', $request->query('from'));
        if ($request->filled('to')) $query->whereDate('attendance_date', '<=', $request->query('to'));
        $rows = $query->get()->map(fn ($a) => [
            $a->attendance_date?->format('Y-m-d'), $a->teacher?->user?->name,
            $a->time_in_at?->format('H:i:s'), $a->time_out_at?->format('H:i:s'), $a->status,
        ])->all();

        return $this->downloadCsv('attendance', ['Date', 'Teacher', 'Time In', 'Time Out', 'Status'], $rows);
    }

    public function schedulesCsv(Request $request): StreamedResponse
    {
        $query = Schedule::with(['teacher.user', 'classroom', 'subject'])->orderBy('schedule_date')->orderBy('start_time');
        if ($request->filled('teacher_id')) $query->where('teacher_id', $request->query('teacher_id'));
        if ($request->filled('subject_id')) $query->where('subject_id', $request->query('subject_id'));
        if ($request->filled('classroom_id')) $query->where('classroom_id', $request->query('classroom_id'));
        if ($request->filled('date')) $query->whereDate('schedule_date', $request->query('date'));
        $rows = $query->get()->map(fn ($s) => [
            $s->schedule_date?->format('Y-m-d'), $s->start_time, $s->end_time,
            $s->teacher?->user?->name, $s->subject?->subject_code, $s->subject?->subject_name,
            $s->classroom?->room_number, $s->section,
        ])->all();

        return $this->downloadCsv('schedules', ['Date', 'Start Time', 'End Time', 'Teacher', 'Subject Code', 'Subject Name', 'Room', 'Section'], $rows);
    }

    public function teacherSchedulesCsv(Request $request): StreamedResponse
    {
        return $this->schedulesCsv($request);
    }

    public function attendance(Request $request): BinaryFileResponse
    {
        $query = Attendance::with('teacher.user')->orderByDesc('attendance_date')->orderByDesc('time_in_at');
        if ($request->filled('teacher_id')) $query->where('teacher_id', $request->query('teacher_id'));
        if ($request->filled('date')) $query->whereDate('attendance_date', $request->query('date'));
        $rows = $query->get()->map(fn ($a) => [
            $a->attendance_date?->format('Y-m-d'), $a->teacher?->user?->name, $a->time_in_at?->format('H:i:s'), $a->time_out_at?->format('H:i:s'), $a->status, $a->verification_status,
        ])->all();
        return $this->download('attendance', ['Date', 'Teacher', 'Time In', 'Time Out', 'Status', 'Verification'], $rows);
    }

    public function schedules(Request $request): BinaryFileResponse
    {
        $query = Schedule::with(['teacher.user', 'classroom', 'subject'])->orderBy('schedule_date')->orderBy('start_time');
        if ($request->filled('teacher_id')) $query->where('teacher_id', $request->query('teacher_id'));
        if ($request->filled('subject_id')) $query->where('subject_id', $request->query('subject_id'));
        if ($request->filled('classroom_id')) $query->where('classroom_id', $request->query('classroom_id'));
        if ($request->filled('date')) $query->whereDate('schedule_date', $request->query('date'));
        $rows = $query->get()->map(fn ($s) => [
            $s->schedule_date?->format('Y-m-d'), $s->start_time, $s->end_time, $s->teacher?->user?->name, $s->subject?->subject_code, $s->subject?->subject_name, $s->classroom?->room_number, $s->section,
        ])->all();
        return $this->download('schedules', ['Date', 'Start Time', 'End Time', 'Teacher', 'Subject Code', 'Subject Name', 'Room', 'Section'], $rows);
    }

    public function teacherSchedules(Request $request): BinaryFileResponse
    {
        $request->merge(['teacher_id' => $request->query('teacher_id')]);
        return $this->schedules($request);
    }

    public function teachers(): BinaryFileResponse
    {
        $rows = Teacher::with(['user','department'])->get()->map(fn ($t) => [$t->user?->name, $t->user?->email, $t->user?->username, $t->employee_number, $t->department?->name ?? $t->department, $t->employment_status])->all();
        return $this->download('teachers', ['Name', 'Email', 'Username', 'Employee Number', 'Department', 'Status'], $rows);
    }

    public function students(): BinaryFileResponse
    {
        $rows = Student::orderBy('student_number')->get()->map(fn ($s) => [$s->student_number, $s->first_name, $s->middle_name, $s->last_name, $s->program, $s->year_level, $s->section, $s->status])->all();
        return $this->download('students', ['Student Number', 'First Name', 'Middle Name', 'Last Name', 'Program', 'Year Level', 'Section', 'Status'], $rows);
    }

    public function subjects(): BinaryFileResponse
    {
        $rows = Subject::orderBy('subject_code')->get()->map(fn ($s) => [$s->subject_code, $s->subject_name, $s->units, $s->description])->all();
        return $this->download('subjects', ['Code', 'Name', 'Units', 'Description'], $rows);
    }

    public function template(string $module): BinaryFileResponse
    {
        $headers = match ($module) {
            'students' => ['Student Number', 'First Name', 'Middle Name', 'Last Name', 'Program', 'Year Level', 'Section', 'Status'],
            'subjects' => ['Code', 'Name', 'Units', 'Description'],
            'schedules' => ['Date', 'Start Time', 'End Time', 'Teacher Email', 'Subject Code', 'Room', 'Section'],
            default => abort(404),
        };
        return $this->download($module.'_template', $headers, [], true);
    }

    private function download(string $name, array $headers, array $rows, bool $instructions = false): BinaryFileResponse
    {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle(ucwords(str_replace('_', ' ', $name)));
        foreach ($headers as $i => $header) $sheet->setCellValueByColumnAndRow($i + 1, 1, $header);
        $sheet->getStyleByColumnAndRow(1, 1, count($headers), 1)->getFont()->setBold(true);
        $sheet->freezePane('A2');
        $sheet->setAutoFilter($sheet->calculateWorksheetDimension());
        foreach ($rows as $r => $row) foreach ($row as $c => $value) {
            $cell = $sheet->getCellByColumnAndRow($c + 1, $r + 2);
            $header = strtolower((string) $headers[$c]);
            $text = (string) ($value ?? '');
            if (in_array(substr($text, 0, 1), ['=', '+', '-', '@'], true)) {
                $cell->setValueExplicit("'{$text}", DataType::TYPE_STRING);
            } elseif (str_contains($header, 'date') && preg_match('/^\d{4}-\d{2}-\d{2}$/', $text)) {
                $cell->setValue(ExcelDate::PHPToExcel(new \DateTimeImmutable($text)));
                $cell->getStyle()->getNumberFormat()->setFormatCode('yyyy-mm-dd');
            } elseif (str_contains($header, 'time') && preg_match('/^\d{2}:\d{2}:\d{2}$/', $text)) {
                $seconds = array_map('intval', explode(':', $text));
                $cell->setValue(($seconds[0] * 3600 + $seconds[1] * 60 + $seconds[2]) / 86400);
                $cell->getStyle()->getNumberFormat()->setFormatCode('hh:mm:ss');
            } else {
                $cell->setValue($value);
            }
        }
        foreach (range(1, count($headers)) as $col) $sheet->getColumnDimensionByColumn($col)->setAutoSize(true);
        if ($instructions) {
            $instructionsSheet = $spreadsheet->createSheet();
            $instructionsSheet->setTitle('Instructions');
            $instructionsSheet->setCellValue('A1', 'Fill the template without changing the required headers. Dates and times should be entered as Excel date/time values. Upload the completed workbook through SchedSpace.');
            $instructionsSheet->getColumnDimension('A')->setWidth(110);
            $instructionsSheet->getStyle('A1')->getAlignment()->setWrapText(true);
        }
        $path = storage_path('app/' . $name . '_' . now()->format('Y-m-d') . '.xlsx');
        (new Xlsx($spreadsheet))->save($path);
        return response()->download($path, basename($path))->deleteFileAfterSend(true);
    }

    private function downloadCsv(string $name, array $headers, array $rows): StreamedResponse
    {
        $filename = $name.'_'.now()->format('Y-m-d').'.csv';

        return response()->streamDownload(function () use ($headers, $rows): void {
            $stream = fopen('php://output', 'wb');
            fwrite($stream, "\xEF\xBB\xBF");
            fputcsv($stream, $headers);
            foreach ($rows as $row) {
                $safeRow = array_map(function ($value): string {
                    $value = (string) ($value ?? '');
                    return in_array(substr($value, 0, 1), ['=', '+', '-', '@'], true) ? "'".$value : $value;
                }, $row);
                fputcsv($stream, $safeRow);
            }
            fclose($stream);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }
}
