<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\StudentSubject;
use App\Models\Subject;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class StudentSubjectController extends Controller
{
    // Admin and Super Admin: view all student-subject assignments.
    public function index(): JsonResponse
    {
        return response()->json(
            StudentSubject::with(['student', 'subject'])->get()
        );
    }


    /** Import a validated CSV roster atomically using the published student template. */
    public function importCsv(Request $request): JsonResponse
    {
        $input = $request->validate([
            'file' => ['required', 'file', 'mimes:csv,txt', 'max:5120'],
            'subject_id' => ['required', 'integer', 'exists:subjects,id'],
            'school_year' => ['required', 'string', 'max:255'],
            'semester' => ['nullable', 'string', 'max:255'],
        ]);

        $path = $request->file('file')->getRealPath();
        if (!$path || !is_file($path) || filesize($path) > 5 * 1024 * 1024) {
            return response()->json(['message' => 'The CSV is missing or exceeds the 5 MB limit.'], 422);
        }

        $handle = fopen($path, 'rb');
        if ($handle === false) {
            return response()->json(['message' => 'The CSV file could not be read.'], 422);
        }

        try {
            $expected = ['student_number', 'first_name', 'middle_name', 'last_name', 'program', 'year_level', 'section', 'status'];
            $header = fgetcsv($handle);
            if ($header === false) {
                return response()->json(['message' => 'The CSV headers must exactly match the SchedSpace student template.'], 422);
            }
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]);
            $header = array_map(fn ($value) => trim((string) $value), $header);
            if ($header !== $expected) {
                return response()->json(['message' => 'The CSV headers must exactly match the SchedSpace student template.'], 422);
            }

            $rows = [];
            $errors = [];
            $rowNumber = 1;
            while (($cells = fgetcsv($handle)) !== false) {
                $rowNumber++;
                if ($cells === [null] || count(array_filter($cells, fn ($value) => trim((string) $value) !== '')) === 0) {
                    continue;
                }
                if (count($cells) !== count($expected)) {
                    $errors[] = ['row' => $rowNumber, 'message' => 'Each row must contain exactly eight columns.'];
                    continue;
                }

                $data = array_combine($expected, array_map(fn ($value) => trim((string) $value), $cells));
                $data['middle_name'] = $data['middle_name'] ?: null;
                $data['program'] = $data['program'] ?: null;
                $data['year_level'] = $data['year_level'] ?: null;
                $data['section'] = $data['section'] ?: null;
                $data['status'] = $data['status'] ?: 'Active';
                $validator = Validator::make($data, [
                    'student_number' => ['required', 'string', 'max:255'],
                    'first_name' => ['required', 'string', 'max:255'],
                    'middle_name' => ['nullable', 'string', 'max:255'],
                    'last_name' => ['required', 'string', 'max:255'],
                    'program' => ['nullable', 'string', 'max:255'],
                    'year_level' => ['nullable', 'string', 'max:255'],
                    'section' => ['nullable', 'string', 'max:255'],
                    'status' => ['nullable', 'string', 'max:255'],
                ]);
                if ($validator->fails()) {
                    $errors[] = ['row' => $rowNumber, 'message' => implode(' ', $validator->errors()->all())];
                    continue;
                }
                $rows[] = $data;
                if (count($rows) > 5000) {
                    return response()->json(['message' => 'The CSV exceeds the 5,000 row limit.'], 422);
                }
            }
        } finally {
            fclose($handle);
        }

        if ($errors !== []) {
            return response()->json([
                'message' => 'No students were imported because the CSV contains invalid rows.',
                'errors' => $errors,
            ], 422);
        }

        $subject = Subject::findOrFail($input['subject_id']);
        $schoolYear = trim($input['school_year']);
        $semester = filled($input['semester'] ?? null) ? trim($input['semester']) : null;
        $result = DB::transaction(function () use ($rows, $subject, $schoolYear, $semester): array {
            $studentsCreated = 0;
            $studentsExisting = 0;
            $enrollmentsCreated = 0;
            $enrollmentsSkipped = 0;
            $seen = [];

            foreach ($rows as $row) {
                $number = $row['student_number'];
                if (isset($seen[$number])) {
                    $enrollmentsSkipped++;
                    continue;
                }
                $seen[$number] = true;

                $student = Student::where('student_number', $number)->lockForUpdate()->first();
                if (!$student) {
                    $student = Student::create([
                        'student_number' => $number,
                        'first_name' => $row['first_name'],
                        'middle_name' => $row['middle_name'],
                        'last_name' => $row['last_name'],
                        'program' => $row['program'],
                        'year_level' => $row['year_level'],
                        'section' => $row['section'],
                        'status' => $row['status'],
                    ]);
                    $studentsCreated++;
                } else {
                    $studentsExisting++;
                }

                $alreadyEnrolled = StudentSubject::where('student_id', $student->id)
                    ->where('subject_id', $subject->id)
                    ->where('school_year', $schoolYear)
                    ->where('semester', $semester)
                    ->exists();
                if ($alreadyEnrolled) {
                    $enrollmentsSkipped++;
                    continue;
                }

                StudentSubject::create([
                    'student_id' => $student->id,
                    'subject_id' => $subject->id,
                    'school_year' => $schoolYear,
                    'semester' => $semester,
                ]);
                $enrollmentsCreated++;
            }

            return compact('studentsCreated', 'studentsExisting', 'enrollmentsCreated', 'enrollmentsSkipped');
        });

        return response()->json(['message' => 'Student CSV imported successfully.', ...$result], 201);
    }


    /** Import a validated Excel roster atomically. */
    public function importExcel(Request $request): JsonResponse
    {
        $validatedRequest = $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx', 'max:5120'],
            'subject_id' => ['required', 'integer', 'exists:subjects,id'],
            'school_year' => ['required', 'string', 'max:255'],
            'semester' => ['nullable', 'string', 'max:255'],
        ]);

        $path = $request->file('file')->getRealPath();
        if (!$path || !is_file($path) || filesize($path) > 5 * 1024 * 1024) {
            return response()->json(['message' => 'The workbook is missing or exceeds the 5 MB limit.'], 422);
        }

        try {
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($path);
            $reader->setReadDataOnly(true);
            $workbook = $reader->load($path);
            $sheet = $workbook->getSheet(0);
            $highestRow = $sheet->getHighestDataRow();
            if ($highestRow < 2) return response()->json(['message' => 'The workbook contains a header but no student rows.'], 422);
            if ($highestRow - 1 > 5000) return response()->json(['message' => 'The workbook exceeds the 5,000 row limit.'], 422);

            $expected = ['student number','first name','middle name','last name','program','year level','section','status'];
            $header = array_map(fn ($v) => strtolower(trim((string) $v)), $sheet->rangeToArray('A1:H1', null, true, false)[0]);
            if ($header !== $expected) return response()->json(['message' => 'The workbook headers do not match the student template.', 'errors' => ['header' => ['Expected: ' . implode(', ', $expected)]]], 422);

            $rows = []; $errors = []; $seen = [];
            for ($rowNumber = 2; $rowNumber <= $highestRow; $rowNumber++) {
                $cells = $sheet->rangeToArray("A{$rowNumber}:H{$rowNumber}", null, true, false)[0];
                if (count(array_filter($cells, fn ($v) => trim((string) $v) !== '')) === 0) continue;
                $data = array_combine($expected, array_map(fn ($v) => trim((string) $v), $cells));
                $data['middle name'] = $data['middle name'] ?: null;
                $data['program'] = $data['program'] ?: null;
                $data['year level'] = $data['year level'] ?: null;
                $data['section'] = $data['section'] ?: null;
                $data['status'] = $data['status'] ?: 'Active';
                $validator = Validator::make($data, [
                    'student number' => ['required','string','max:255'],
                    'first name' => ['required','string','max:255'],
                    'middle name' => ['nullable','string','max:255'],
                    'last name' => ['required','string','max:255'],
                    'program' => ['nullable','string','max:255'],
                    'year level' => ['nullable','string','max:255'],
                    'section' => ['nullable','string','max:255'],
                    'status' => ['nullable','string','max:255'],
                ]);
                if ($validator->fails()) { $errors[] = ['row' => $rowNumber, 'column' => 'row', 'message' => implode(' ', $validator->errors()->all())]; continue; }
                $number = $data['student number'];
                if (isset($seen[$number])) { $errors[] = ['row' => $rowNumber, 'column' => 'Student Number', 'message' => 'Duplicate student number inside the workbook.']; continue; }
                $seen[$number] = true;
                $rows[] = $data;
            }

            if ($errors) return response()->json(['message' => 'No data was saved because the workbook contains invalid rows.', 'valid_rows' => count($rows), 'invalid_rows' => count($errors), 'errors' => $errors], 422);
            if ($request->boolean('preview')) return response()->json(['message' => 'Workbook validated. Nothing has been saved.', 'valid_rows' => count($rows), 'invalid_rows' => 0, 'preview' => array_slice($rows, 0, 25)]);

            $subject = Subject::findOrFail($validatedRequest['subject_id']);
            $schoolYear = trim($validatedRequest['school_year']);
            $semester = filled($validatedRequest['semester'] ?? null) ? trim($validatedRequest['semester']) : null;
            $result = DB::transaction(function () use ($rows, $subject, $schoolYear, $semester): array {
                $created = 0; $existing = 0; $enrolled = 0; $skipped = 0;
                foreach ($rows as $row) {
                    $student = Student::where('student_number', $row['student number'])->lockForUpdate()->first();
                    if (!$student) {
                        $student = Student::create([
                            'student_number' => $row['student number'], 'first_name' => $row['first name'], 'middle_name' => $row['middle name'], 'last_name' => $row['last name'],
                            'program' => $row['program'], 'year_level' => $row['year level'], 'section' => $row['section'], 'status' => $row['status'],
                        ]); $created++;
                    } else { $existing++; }
                    $assignment = StudentSubject::where('student_id', $student->id)->where('subject_id', $subject->id)->where('school_year', $schoolYear)->where('semester', $semester)->exists();
                    if ($assignment) { $skipped++; continue; }
                    StudentSubject::create(['student_id' => $student->id, 'subject_id' => $subject->id, 'school_year' => $schoolYear, 'semester' => $semester]); $enrolled++;
                }
                return compact('created','existing','enrolled','skipped');
            });

            return response()->json(['message' => 'Student workbook imported successfully.', 'total_rows' => count($rows), ...$result], 201);
        } catch (\Throwable $e) {
            report($e);
            return response()->json(['message' => 'The workbook could not be read. Make sure it is a valid, unprotected Excel workbook.'], 422);
        }
    }

    // Admin and Super Admin: assign a student to a subject.
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'student_id' => ['required', 'exists:students,id'],
            'subject_id' => ['required', 'exists:subjects,id'],
            'school_year' => ['required', 'string', 'max:255'],
            'semester' => ['nullable', 'string', 'max:255'],
        ]);

        $exists = StudentSubject::where('student_id', $validated['student_id'])
            ->where('subject_id', $validated['subject_id'])
            ->where('school_year', $validated['school_year'])
            ->where('semester', $validated['semester'] ?? null)
            ->exists();

        if ($exists) {
            return response()->json([
                'message' => 'This student is already assigned to this subject for the selected school year and semester.',
            ], 409);
        }

        $assignment = StudentSubject::create($validated);

        return response()->json([
            'message' => 'Student assigned to subject successfully.',
            'assignment' => $assignment->load(['student', 'subject']),
        ], 201);
    }

    // Admin and Super Admin: view one student's subjects.
    public function show(Student $student): JsonResponse
    {
        return response()->json(
            $student->load('subjects')
        );
    }

    // Teacher: view students assigned to subjects they teach.
    public function myStudents(Request $request): JsonResponse
    {
        $teacher = $request->user()->teacher;

        if (!$teacher) {
            return response()->json([
                'message' => 'Your account is not linked to a teacher record.',
            ], 403);
        }

        $assignments = StudentSubject::with([
            'student',
            'subject',
        ])
            ->whereExists(function ($query) use ($teacher) {
                $query->selectRaw('1')
                    ->from('schedules')
                    ->whereColumn(
                        'schedules.subject_id',
                        'student_subjects.subject_id'
                    )
                    ->where('schedules.teacher_id', $teacher->id);
            })
            ->get();

        return response()->json($assignments);
    }

    // Admin and Super Admin: remove a student-subject assignment.
    public function destroy(StudentSubject $studentSubject): JsonResponse
    {
        $studentSubject->delete();

        return response()->json([
            'message' => 'Student subject assignment removed successfully.',
        ]);
    }
}
