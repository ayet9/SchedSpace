<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Throwable;

class AuthController extends Controller
{
    public function login(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $key = Str::transliterate(Str::lower($validated['email']).'|'.$request->ip());

        try {
            if (RateLimiter::tooManyAttempts($key, 5)) {
                $seconds = RateLimiter::availableIn($key);

                return response()->json([
                    'message' => 'Too many sign-in attempts. Please try again later.',
                    'retry_after' => $seconds,
                ], 429);
            }

            /*
             * Keep the login query intentionally small.
             *
             * The login screen only needs the account, role, and teacher profile.
             * Permission checks are still enforced by backend middleware.
             */
            $user = User::query()
                ->select([
                    'id',
                    'name',
                    'first_name',
                    'middle_name',
                    'last_name',
                    'username',
                    'email',
                    'password',
                    'role_id',
                    'is_active',
                    'must_change_password',
                    'email_verified_at',
                ])
                ->with([
                    'role:id,name,slug,description',
                    'teacher:id,user_id,department_id,employee_number,department,employment_status',
                ])
                ->where('email', $validated['email'])
                ->first();

            if (!$user || !$user->is_active || !Hash::check($validated['password'], $user->password)) {
                RateLimiter::hit($key, 15 * 60);

                return response()->json(['message' => 'Invalid email or password.'], 401);
            }

            RateLimiter::clear($key);

            // Keep token creation simple and avoid loading unrelated account data.
            $token = $user->createToken('schedspace-token')->plainTextToken;
        } catch (Throwable $exception) {
            report($exception);

            return response()->json([
                'message' => 'Sign-in is temporarily unavailable. Please try again in a moment.',
            ], 503)->withHeaders($this->securityHeaders());
        }

        return response()->json([
            'message' => 'Login successful.',
            'token' => $token,
            'must_change_password' => (bool) $user->must_change_password,
            'user' => $user,
        ])->withHeaders($this->securityHeaders());
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()?->delete();

        return response()->json(['message' => 'Logout successful.'])
            ->withHeaders($this->securityHeaders());
    }

    private function securityHeaders(): array
    {
        return [
            'Cache-Control' => 'no-store, no-cache, must-revalidate, private',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
            'Referrer-Policy' => 'same-origin',
        ];
    }
}
