<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserManagementController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(
            User::with(['role', 'teacher'])
                ->orderBy('last_name')
                ->orderBy('first_name')
                ->get()
        );
    }

    public function update(Request $request, User $user): JsonResponse
    {
        $validated = $request->validate([
            'first_name' => ['sometimes', 'required', 'string', 'max:255'],
            'middle_name' => ['sometimes', 'nullable', 'string', 'max:255'],
            'last_name' => ['sometimes', 'required', 'string', 'max:255'],
            'username' => ['sometimes', 'required', 'string', 'max:255', Rule::unique('users', 'username')->ignore($user->id)],
            'email' => ['sometimes', 'required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'password' => ['sometimes', 'nullable', 'string', 'min:8', 'confirmed'],
            'current_password' => ['sometimes', 'nullable', 'string'],
        ]);

        if ($request->user()->is($user) && filled($validated['password'] ?? null)) {
            if (!filled($validated['current_password'] ?? null) || !Hash::check($validated['current_password'], $user->password)) {
                return response()->json([
                    'message' => 'Your current password is incorrect.',
                    'errors' => ['current_password' => ['Enter your correct current password before changing your password.']],
                ], 422);
            }
        }

        unset($validated['current_password']);

        DB::transaction(function () use ($user, $validated): void {
            $password = $validated['password'] ?? null;
            unset($validated['password']);
            $first = $validated['first_name'] ?? $user->first_name;
            $middle = array_key_exists('middle_name', $validated) ? $validated['middle_name'] : $user->middle_name;
            $last = $validated['last_name'] ?? $user->last_name;
            $user->fill($validated);
            $user->name = trim(implode(' ', array_filter([$first, $middle, $last], fn ($part) => filled($part))));
            if ($password !== null) {
                $user->password = $password;
            }
            $user->save();
        });

        return response()->json([
            'message' => 'User account updated successfully.',
            'user' => $user->fresh()->load(['role', 'teacher']),
        ]);
    }

    public function destroy(Request $request, User $user): JsonResponse
    {
        $isSelf = $request->user()->is($user);
        if ($isSelf) {
            $validated = $request->validate(['current_password' => ['required', 'string']]);
            if (!Hash::check($validated['current_password'], $user->password)) {
                return response()->json([
                    'message' => 'Your current password is incorrect.',
                    'errors' => ['current_password' => ['Your current password is incorrect.']],
                ], 422);
            }
        }

        if (in_array($user->role?->slug, ['root-admin', 'super_admin', 'super-admin'], true)
            && User::whereHas('role', fn ($query) => $query->whereIn('slug', ['root-admin', 'super_admin', 'super-admin']))->count() <= 1) {
            return response()->json([
                'message' => 'The only Super Admin account cannot be deleted. Assign another Super Admin first.',
            ], 409);
        }

        if ($user->teacher && ($user->teacher->schedules()->exists() || $user->teacher->attendances()->exists())) {
            return response()->json([
                'message' => 'This account is linked to teacher schedules or attendance history. Reassign or archive those records before deleting the account.',
            ], 409);
        }

        DB::transaction(function () use ($user): void {
            $user->tokens()->delete();
            if ($user->teacher) {
                $user->teacher->delete();
            }
            $user->delete();
        });

        return response()->json([
            'message' => $isSelf ? 'Your account has been deleted successfully.' : 'User account deleted successfully.',
            'deleted_self' => $isSelf,
        ]);
    }

    public function updateRole(Request $request, User $user): JsonResponse
    {
        // Accept the newer display-oriented slug used by older deployments,
        // but store and authorize against the canonical root-admin slug.
        if (in_array($request->input('role'), ['super-admin', 'super_admin'], true)) {
            $request->merge(['role' => 'root-admin']);
        }

        $validated = $request->validate([
            'role' => ['sometimes', 'nullable', 'string', Rule::exists('roles', 'slug')],
            'role_id' => ['sometimes', 'nullable', 'integer', Rule::exists('roles', 'id')],
        ]);

        if (!array_key_exists('role', $validated) && !array_key_exists('role_id', $validated)) {
            return response()->json(['message' => 'Choose a role or send null to unassign it.'], 422);
        }

        $role = array_key_exists('role', $validated)
            ? (isset($validated['role']) ? Role::where('slug', $validated['role'])->first() : null)
            : (isset($validated['role_id']) ? Role::find($validated['role_id']) : null);

        $rootSlugs = ['root-admin', 'super_admin', 'super-admin'];
        $isLastSuperAdmin = in_array($user->role?->slug, $rootSlugs, true)
            && !in_array($role?->slug, $rootSlugs, true)
            && User::whereHas('role', fn ($query) => $query->whereIn('slug', $rootSlugs))->count() <= 1;

        if ($isLastSuperAdmin) {
            return response()->json([
                'message' => 'The last Super Admin cannot be unassigned or demoted. Assign another Super Admin first.',
            ], 409);
        }

        DB::transaction(function () use ($user, $role): void {
            $user->update(['role_id' => $role?->id]);
            if ($role?->slug === 'teacher') {
                Teacher::firstOrCreate(['user_id' => $user->id], ['employment_status' => 'Active']);
            }
        });

        return response()->json($user->fresh()->load(['role', 'teacher']));
    }
}
