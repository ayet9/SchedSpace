<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class RolePermissionController extends Controller
{
    private const MODULES = [
        'dashboard' => [
            'root-admin' => ['view_dashboard'],
            'admin' => ['view_dashboard'],
            'teacher' => ['view_dashboard'],
        ],
        'classrooms' => [
            'root-admin' => ['view_classrooms', 'manage_classrooms'],
            'admin' => ['view_classrooms', 'manage_classrooms'],
            'teacher' => ['view_classrooms'],
        ],
        'schedules' => [
            'root-admin' => ['view_schedules', 'manage_schedules'],
            'admin' => ['view_schedules', 'manage_schedules'],
            'teacher' => [],
        ],
        'teacher-schedule' => [
            'root-admin' => ['view_schedules', 'view_other_teacher_schedules'],
            'admin' => ['view_schedules', 'view_other_teacher_schedules'],
            'teacher' => ['view_own_schedule', 'view_other_teacher_schedules'],
        ],
        'student-subjects' => [
            'root-admin' => ['manage_students', 'manage_subjects', 'view_subjects'],
            'admin' => ['manage_students', 'manage_subjects', 'view_subjects'],
            'teacher' => ['view_assigned_student_lists', 'view_subjects'],
        ],
        'subjects' => [
            'root-admin' => ['view_subjects', 'manage_subjects'],
            'admin' => ['view_subjects', 'manage_subjects'],
            'teacher' => ['view_subjects'],
        ],
        'attendance' => [
            'root-admin' => ['view_attendance', 'record_attendance'],
            'admin' => ['view_attendance'],
            'teacher' => ['record_attendance'],
        ],
        'users' => [
            'root-admin' => ['manage_users'],
            'admin' => [],
            'teacher' => [],
        ],
        'permissions' => [
            'root-admin' => ['manage_roles_permissions'],
            'admin' => [],
            'teacher' => [],
        ],
    ];

    public function index(): JsonResponse
    {
        return response()->json(
            Role::with('permissions')->get()
        );
    }

    public function permissions(): JsonResponse
    {
        return response()->json(
            Permission::orderBy('name')->get()
        );
    }

    public function matrix(): JsonResponse
    {
        return response()->json($this->permissionMatrix());
    }

    public function updateMatrix(Request $request): JsonResponse
    {
        $rules = ['matrix' => ['required', 'array']];
        foreach (array_keys(self::MODULES) as $module) {
            foreach (['root-admin', 'admin', 'teacher'] as $slug) {
                $rules["matrix.{$module}.{$slug}"] = ['required', 'boolean'];
            }
        }
        $validated = $request->validate($rules);
        $matrix = $validated['matrix'];

        if ($matrix['dashboard']['root-admin'] !== true
            || $matrix['dashboard']['admin'] !== true
            || $matrix['dashboard']['teacher'] !== true
            || in_array(false, $matrix['dashboard'], true)) {
            throw ValidationException::withMessages([
                'matrix' => ['The dashboard and Super Admin access cannot be disabled.'],
            ]);
        }

        foreach (array_keys(self::MODULES) as $module) {
            if ($matrix[$module]['root-admin'] !== true) {
                throw ValidationException::withMessages([
                    'matrix' => ['Super Admin access cannot be disabled.'],
                ]);
            }
        }

        DB::transaction(function () use ($matrix): void {
            $roles = Role::with('permissions')->get()->keyBy('slug');
            $allPermissionIds = Permission::query()->pluck('id');
            $managedKeys = collect(self::MODULES)
                ->flatten(2)
                ->unique()
                ->values();

            foreach (['root-admin', 'admin', 'teacher'] as $slug) {
                $role = $roles->get($slug);
                if (!$role) {
                    continue;
                }

                if ($slug === 'root-admin') {
                    $role->permissions()->sync($allPermissionIds);
                    continue;
                }

                $preservedIds = $role->permissions
                    ->reject(fn (Permission $permission) => $managedKeys->contains($permission->key))
                    ->pluck('id');
                $selectedKeys = $managedKeys->filter(function (string $key) use ($matrix, $slug): bool {
                    foreach (self::MODULES as $module => $roleKeys) {
                        if (in_array($key, $roleKeys[$slug], true) && $matrix[$module][$slug]) {
                            return true;
                        }
                    }

                    return false;
                });
                $selectedIds = Permission::whereIn('key', $selectedKeys)->pluck('id');
                $role->permissions()->sync($preservedIds->merge($selectedIds)->unique()->values());
            }
        });

        return response()->json($this->permissionMatrix());
    }

    public function updateRolePermissions(Request $request, Role $role): JsonResponse
    {
        $validated = $request->validate([
            'permissions' => ['required', 'array'],
            'permissions.*' => ['required', 'integer', 'exists:permissions,id'],
        ]);

        if ($role->slug === 'root-admin') {
            $role->permissions()->sync(Permission::query()->pluck('id'));
        } else {
            $role->permissions()->sync($validated['permissions']);
        }

        return response()->json([
            'message' => 'Role permissions updated successfully.',
            'role' => $role->load('permissions'),
        ]);
    }

    public function updateUserPermissions(Request $request, User $user): JsonResponse
    {
        $validated = $request->validate([
            'permissions' => ['required', 'array'],
            'permissions.*' => ['required', 'integer', 'exists:permissions,id'],
        ]);

        $user->permissions()->sync($validated['permissions']);

        return response()->json([
            'message' => 'User permissions updated successfully.',
            'user' => $user->load('permissions'),
        ]);
    }

    private function permissionMatrix(): array
    {
        $roles = Role::with('permissions')->get()->keyBy('slug');
        $matrix = [];

        foreach (self::MODULES as $module => $moduleRoles) {
            foreach (['root-admin', 'admin', 'teacher'] as $slug) {
                if ($slug === 'root-admin') {
                    $matrix[$module][$slug] = true;
                    continue;
                }

                $granted = $roles->get($slug)?->permissions->pluck('key')->all() ?? [];
                $required = $moduleRoles[$slug];
                $matrix[$module][$slug] = $required !== []
                    && count(array_intersect($required, $granted)) === count($required);
            }
        }

        return $matrix;
    }
}
