<?php
namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequirePasswordChange
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if ($user && $user->must_change_password) {
            return response()->json([
                'code' => 'password_change_required',
                'message' => 'You must change your temporary password before continuing.',
            ], 403);
        }
        return $next($request);
    }
}
