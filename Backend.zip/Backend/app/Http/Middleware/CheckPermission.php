<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckPermission
{
    public function handle(
        Request $request,
        Closure $next,
        string $permission
    ): Response {
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'message' => 'Unauthenticated.',
            ], 401);
        }

        if ($user->must_change_password) {
            return response()->json([
                'code' => 'password_change_required',
                'message' => 'Change your temporary password before continuing.',
            ], 403);
        }

        if (in_array($user->role?->slug, ['root-admin', 'super_admin', 'super-admin'], true)) {
            return $next($request);
        }

        // Check permissions assigned directly to the user.
        $hasDirectPermission = $user->permissions()
            ->where('key', $permission)
            ->exists();

        // Check permissions inherited from the user's role.
        $hasRolePermission = $user->role()
            ->whereHas('permissions', function ($query) use ($permission) {
                $query->where('key', $permission);
            })
            ->exists();

        if (!$hasDirectPermission && !$hasRolePermission) {
            return response()->json([
                'message' => 'You do not have permission to perform this action.',
            ], 403);
        }

        return $next($request);
    }
}
