<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Attendance extends Model
{
    protected $fillable = [
        'teacher_id',
        'attendance_date',
        'time_in',
        'time_in_at',
        'photo_in_path',
        'time_out',
        'time_out_at',
        'photo_out_path',
        'verification_status',
        'status',
        'legacy_auto_timeout',
        'manual_correction_at',
        'manual_corrected_by',
        'manual_correction_reason',
    ];

    protected function casts(): array
    {
        return [
            'attendance_date' => 'date',
            'time_in_at' => 'datetime',
            'time_out_at' => 'datetime',
            'legacy_auto_timeout' => 'boolean',
            'manual_correction_at' => 'datetime',
        ];
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class);
    }
}