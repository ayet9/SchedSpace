<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Classroom extends Model
{
    protected $fillable = [
        'room_number',
        'layout_type_id',
        'layout_image_path',
        'building',
        'floor',
        'location_description',
        'layout_description',
        'capacity',
        'status',
        'features',
        'plan',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'features' => 'array',
            'plan' => 'array',
        ];
    }

    public function layoutType(): BelongsTo
    {
        return $this->belongsTo(ClassroomLayoutType::class, 'layout_type_id');
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(Schedule::class);
    }
}
