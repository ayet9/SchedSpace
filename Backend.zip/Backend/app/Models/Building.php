<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Building extends Model
{
    protected $fillable = ['name', 'floor_count', 'walkways', 'map_x', 'map_y'];

    protected function casts(): array
    {
        return [
            'floor_count' => 'integer',
            'walkways' => 'array',
            'map_x' => 'integer',
            'map_y' => 'integer',
        ];
    }
}
