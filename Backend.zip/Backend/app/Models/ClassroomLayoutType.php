<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ClassroomLayoutType extends Model
{
    protected $fillable = ['name', 'typical_capacity', 'min_capacity', 'max_capacity', 'description', 'features', 'image_path'];
    protected function casts(): array { return ['features' => 'array']; }
    public function classrooms(): HasMany { return $this->hasMany(Classroom::class, 'layout_type_id'); }
}
