<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AttendanceCaptureToken extends Model
{
    protected $fillable = ['teacher_id', 'token_hash', 'action', 'expires_at', 'used_at'];

    protected function casts(): array
    {
        return ['expires_at' => 'datetime', 'used_at' => 'datetime'];
    }

    public function teacher(): BelongsTo { return $this->belongsTo(Teacher::class); }
}
