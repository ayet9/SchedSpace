<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AttendanceIdempotencyKey extends Model
{
    protected $fillable = ['teacher_id', 'action', 'request_key', 'attendance_id'];
    public function teacher(): BelongsTo { return $this->belongsTo(Teacher::class); }
    public function attendance(): BelongsTo { return $this->belongsTo(Attendance::class); }
}
