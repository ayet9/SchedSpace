<?php

namespace App\Console\Commands;

use App\Models\Role;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class SetupSystemAccounts extends Command
{
    protected $signature = 'schedspace:setup-accounts {--super-email=} {--admin-email=}';
    protected $description = 'Create the single initial Super Admin and Admin accounts interactively.';

    public function handle(): int
    {
        $superRole = Role::where('slug', 'super_admin')->firstOrFail();
        $adminRole = Role::where('slug', 'admin')->firstOrFail();

        $super = $this->makeAccount('Super Admin', $superRole, $this->option('super-email'));
        $admin = $this->makeAccount('Admin', $adminRole, $this->option('admin-email'));

        $this->info("Super Admin: {$super->email}");
        $this->info("Admin: {$admin->email}");
        $this->warn('Credentials were entered interactively and are not stored in source code.');

        return self::SUCCESS;
    }

    private function makeAccount(string $label, Role $role, ?string $emailOption): User
    {
        if (User::where('role_id', $role->id)->where('is_active', true)->exists()) {
            return User::where('role_id', $role->id)->where('is_active', true)->firstOrFail();
        }

        $email = $emailOption ?: $this->ask("{$label} email");
        $username = $this->ask("{$label} username");
        $first = $this->ask("{$label} first name");
        $last = $this->ask("{$label} last name");
        $password = $this->secret("{$label} password (at least 10 characters with letters and numbers)");

        if (strlen($password) < 10 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $this->error('Password must contain at least 10 characters with letters and numbers.');
            return $this->makeAccount($label, $role, $email);
        }

        return User::create([
            'name' => trim("{$first} {$last}"),
            'first_name' => trim($first),
            'middle_name' => null,
            'last_name' => trim($last),
            'username' => trim($username),
            'email' => trim($email),
            'password' => Hash::make($password),
            'role_id' => $role->id,
            'is_active' => true,
            'must_change_password' => true,
        ]);
    }
}
