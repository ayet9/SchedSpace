<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class CheckIntegrity extends Command
{
    protected $signature = 'schedspace:check-integrity';
    protected $description = 'Check privileged-role duplicates, orphan relationships and open attendance duplicates.';

    public function handle(): int
    {
        $problems = [];
        foreach (['super_admin', 'admin'] as $slug) {
            $count = DB::table('users')->join('roles', 'roles.id', '=', 'users.role_id')->where('roles.slug', $slug)->where('users.is_active', true)->count();
            if ($count > 1) $problems[] = "{$slug}: {$count} active accounts";
        }
        $open = DB::table('attendances')->select('teacher_id', 'attendance_date')->whereNotNull('time_in_at')->whereNull('time_out_at')->groupBy('teacher_id', 'attendance_date')->havingRaw('COUNT(*) > 1')->get();
        foreach ($open as $row) $problems[] = "duplicate open attendance: teacher {$row->teacher_id} {$row->attendance_date}";
        foreach ([
            ['schedules','teacher_id','teachers'], ['schedules','classroom_id','classrooms'], ['schedules','subject_id','subjects'],
            ['attendances','teacher_id','teachers'], ['student_subjects','student_id','students'], ['student_subjects','subject_id','subjects'],
        ] as [$table,$column,$parent]) {
            $count = DB::table($table)->leftJoin($parent, "$parent.id", '=', "$table.$column")->whereNull("$parent.id")->count();
            if ($count) $problems[] = "{$table}.{$column}: {$count} orphan rows";
        }
        if ($problems) { foreach ($problems as $problem) $this->error($problem); return self::FAILURE; }
        $this->info('SchedSpace integrity check passed: zero problems found.');
        return self::SUCCESS;
    }
}
